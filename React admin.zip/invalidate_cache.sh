#!/bin/bash

# AWS CloudFront Distribution ID
# CLOUDFRONT_DISTRIBUTION_ID="E18SBA1UHVWWSU"

# Path or paths to invalidate (e.g., /index.html /assets/*)
INVALIDATION_PATH="/index.html /assets/*"
# INVALIDATION_PATH="/*"

# Execute cache invalidation
aws cloudfront create-invalidation \
  --distribution-id "$CLOUDFRONT_DISTRIBUTION_ID" \
  --paths $INVALIDATION_PATH
