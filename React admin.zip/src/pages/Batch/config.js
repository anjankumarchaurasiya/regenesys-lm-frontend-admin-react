export const fields = {
  batchNumber: {
    type: "string",
    label: "Batch Number",
    required: true,
    placeholder: "Batch No.",
  },
  courseId: {
    type: "asyncSelect",
    label: "course",
    displayLabels: ["title"],
    outputValue: "label",
    dataIndex: ["value", "title"],
    entity: "/course/filter/list",
    required: true,
    asyncOptions: null,
    responseInner: "course",
    placeholder: "Course",
  },
  startDate: {
    type: "date",
    label: "Start Date",
    required: true,
    reverseFormat: true,
  },
  endDate: {
    type: "date",
    label: "End Date",
    required: true,
    reverseFormat: true,
  },
  classMode: {
    type: "select",
    label: "Mode of Class",
    mode: "multiple",
    renderAsTag: true,
    required: true,
    placeholder: "Mode of Class",
    disabled: true,
    defaultValue: [],
    options: [
      { value: "WEEK_DAYS", label: "Week Days" },
      { value: "WEEK_ENDS", label: "Week Ends" },
    ],
  },
  feedbackId: {
    type: "selectForDynamicFetch",
    label: "Feedback Category",
    displayLabels: ["name"],
    outputValue: "label",
    dataIndex: ["value", "name"],
    entity: "/category/filter/list",
    required: true,
    asyncOptions: {
      type: "feedback",
    },
    responseInner: "category",
    placeholder: "Feedback category",
    dropdownFor: "batch",
  },
};

export const filterFields = {
  batchNumber: {
    type: "string",
    placeholder: "Batch No.",
  },
  courseId: {
    type: "asyncSelectWithChange",
    label: "course",
    displayLabels: ["title"],
    outputValue: "label",
    dataIndex: ["value", "title"],
    entity: "/course/filter/list",
    required: true,
    asyncOptions: null,
    responseInner: "course",
    placeholder: "Course",
  },
  createdAt: {
    type: "date",
    placeholder: "Select date",
  },
};

export const listFields = {
  batchNumber: {
    type: "string",
    label: "Batch No",
  },
  course: {
    type: "string",
    dataIndex: ["course", "title"],
    label: "Course",
  },
  classMode: {
    type: "string",
    label: "Class Mode",
  },
  startDate: {
    type: "date",
    label: "Start Date",
    reverseFormat: false,
  },
  endDate: {
    type: "date",
    label: "End Date",
    reverseFormat: false,
  },
  created_at: {
    type: "date",
    label: "Created On",
  },
};
