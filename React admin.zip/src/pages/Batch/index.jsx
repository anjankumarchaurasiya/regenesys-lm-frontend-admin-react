import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";

import useLanguage from "@/locale/useLanguage";
import { EditOutlined } from "@ant-design/icons";

export default function Batch() {
  const translate = useLanguage();

  const entities = {
    listEntity: "/batch/filter/list",
    createEntity: "/batch",
    updateEntity: "/batch",
  };
  const customizeConfigParameters = {
    responseInnerObj: "batch",
    params: "recordStatus=true",
  };

  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const deletedentity = {
    entityname: "batch",
    bulkentityname: "batchIds",
  };
  const Labels = {
    PANEL_TITLE: translate("Create Batch"),
    DATATABLE_TITLE: translate("batch"),
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("batch"),
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    fields,
    filterFields,
    listFields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    inTableCheckBox: false,
  };

  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
