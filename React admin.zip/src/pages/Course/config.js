export const fields = {
  title: {
    type: "string",
    required: true,
    maxLength: 100,
    minLength: 20,
    placeholder: "",
  },

  description: {
    type: "textarea",
    required: true,
    maxLength: 500,
    minLength: 50,
  },
  thumbnail: {
    type: "customImageUpload",
    required: true,
  },
  createdOn: {
    type: "date",
    disableForForm: true,
  },
  action: {
    type: "action",
    disableForForm: true,
  },
};

export const filterFields = {
  title: {
    type: "string",
    required: true,
    placeholder: "Title",
  },
  createdAt: {
    type: "date",
    placeholder: "Select date",
  },
  recordStatus: {
    type: "select",
    renderAsTag: true,
    defaultValue: true,
    className: "custome-filter-select",
    options: [
      { value: false, label: "Deactive" },
      { value: true, label: "Active" },
    ],
  },
};
export const listFields = {
  title: {
    type: "string",
    required: true,
  },

  description: {
    type: "textarea",
    required: true,
  },
  thumbnail: {
    type: "customImageUpload",
    required: true,
  },
  created_at: {
    type: "date",
    disableForForm: true,
    label: "Created On",
  },
  // action: {
  //   type: "action",
  //   disableForForm: true,
  // },
};
