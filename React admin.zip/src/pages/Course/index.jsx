import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";
import useLanguage from "@/locale/useLanguage";
import { EyeOutlined } from "@ant-design/icons";

export default function Course() {
  const translate = useLanguage();
  const entities = {
    listEntity: "/course/filter/list",
    createEntity: "/course",
    updateEntity: "/course",
  };
  const customizeConfigParameters = {
    responseInnerObj: "course",
    params: "recordStatus=true",
    fileEntityName: {
      fieldName: "thumbnail",
      isfileUpload: true,
      entityName: "COURSE",
      entityType: "THUMBNAIL",
    },
  };
  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const ViewItems = [
    {
      label: translate("View Course Tree"),
      key: "viewCourseTree",
      icon: <EyeOutlined />,
    },
    {
      type: "divider",
    },
    {
      label: translate("View Module"),
      key: "viewCourseModule",
      icon: <EyeOutlined />,
    },
  ];

  const deletedentity = {
    entityname: "course",
    bulkentityname: "courseIds",
  };

  const activateEntity = {
    entityname: "course",
    bulkentityname: "courseIds",
  };

  const Labels = {
    PANEL_TITLE: translate("course"),
    DATATABLE_TITLE: translate("course"),
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("course"),
  };
  const configPage = {
    entities,
    ...Labels,
    customizeConfigParameters,
  };
  const config = {
    ...configPage,
    fields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    activateEntity,
    filterFields,
    ViewItems,
    listFields,
  };

  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
