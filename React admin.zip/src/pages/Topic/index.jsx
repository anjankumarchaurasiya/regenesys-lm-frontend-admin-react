import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";
import { Switch, Tag } from "antd";
import { CloseOutlined, CheckOutlined } from "@ant-design/icons";
import useLanguage from "@/locale/useLanguage";
import dayjs from "dayjs";
import { useDate } from "@/settings";
import { EyeOutlined } from "@ant-design/icons";

export default function Topic() {
  const { dateFormat } = useDate();
  const translate = useLanguage();
  const entities = {
    listEntity: "/topic",
    createEntity: "/topic",
    updateEntity: "/topic",
    linkedentity: "module",
    linkedlistEntity: "/module/filter/list",
    tableHeaderDropdown: {
      type: "",
      entity: "module/filter/list",
      renderAsTag: true,
      displayLabels: ["title"],
      searchFields: "title",
      dataIndex: ["module/filter/list", "title"],
    },
  };
  const customizeConfigParameters = {
    responseInnerObj: "topic",
    params: "recordStatus=true",
    fileEntityName: {
      fieldName: "thumbnail",
      isfileUpload: true,
      entityName: "TOPIC",
      entityType: "THUMBNAIL",
    },
  };
  const customizeLinkedConfigParameters = {
    responseInnerObj: "module",
  };
  const deletedentity = {
    entityname: "topic",
    bulkentityname: "topicIds",
  };
  const activateEntity = {
    entityname: "topic",
    bulkentityname: "topicIds",
  };

  const ViewItems = [
    {
      label: translate("view_usages"),
      key: "viewtopicusages",
      icon: <EyeOutlined />,
    },
  ];

  const dataTableColumns = [
    { title: translate("Title"), dataIndex: "title" },
    { title: translate("Thumbnail"), dataIndex: "thumbnail" },
    {
      title: translate("Created On"),
      dataIndex: "created_at",
      render: (text, record) => {
        const date = dayjs(text).format(dateFormat);
        return <Tag bordered={false}>{date}</Tag>;
      },
    },
  ];
  const readColumns = [
    { title: translate("Title"), dataIndex: "title" },
    {
      title: translate("Thumbnail"),
      dataIndex: "thubmnail",
    },
  ];
  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };

  const deleteModalLabels = ["name"];

  const Labels = {
    PANEL_TITLE: translate("topic"),
    DATATABLE_TITLE: translate("topic"),
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("topic"),
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    customizeLinkedConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    filterFields,
    dataTableColumns,
    deletedentity,
    readColumns,
    searchConfig,
    deleteModalLabels,
    ViewItems,
    activateEntity,
    listFields,
    fields,
  };
  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
