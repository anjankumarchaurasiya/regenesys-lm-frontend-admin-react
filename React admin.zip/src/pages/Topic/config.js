export const fields = {
  title: {
    type: "string",
    required: true,
    maxLength: 100,
    minLength: 20,
  },
  thumbnail: {
    type: "customImageUpload",
    required: true,
  },
  resources: {
    type: "customButton",
    required: true,
  },
  createdOn: {
    type: "date",
    disableForForm: true,
  },
};

export const filterFields = {
  title: {
    type: "string",
    placeholder: "Title",
  },
  createdAt: {
    type: "date",
    placeholder: "Select date",
  },
  recordStatus: {
    type: "select",
    renderAsTag: true,
    defaultValue: true,
    className: "custome-filter-select",
    options: [
      { value: false, label: "Deactive" },
      { value: true, label: "Active" },
    ],
  },
};

export const listFields = {
  title: {
    type: "string",
    required: true,
  },
  thumbnail: {
    type: "imageupload",
    required: true,
  },
  created_at: {
    type: "date",
    disableForForm: true,
    label: "Created On",
  },
  // action: {
  //   type: "action",
  //   disableForForm: true,
  // },
};
