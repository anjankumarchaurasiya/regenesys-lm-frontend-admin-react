import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import useLanguage from "@/locale/useLanguage";
import { Form, Button, Typography, Modal } from "antd";
import { login } from "@/redux/auth/actions";
import { selectAuth } from "@/redux/auth/selectors";
import LoginForm from "@/forms/LoginForm";
import Loading from "@/components/Loading";
import AuthModule from "@/modules/AuthModule";
import VerifyOtpModal from "@/components/VeifyOtpModal";

const LoginPage = () => {
  const translate = useLanguage();
  const { isLoading, isSuccess } = useSelector(selectAuth);
  const [modalOpen, setModalOpen] = useState("false");
  const [email, setEmail] = useState("");
  const { Title, Text } = Typography;
  const dispatch = useDispatch();
  const onFinish = async (values) => {
    const response = await dispatch(login({ loginData: values }));
    if (response.success) {
      setModalOpen(false);
      setEmail(values);
    } else {
      setModalOpen(true);
    }
  };

  const FormContainer = () => {
    return (
      <Loading isLoading={isLoading}>
        <Title level={4}>
          {translate("Verify Your Email Address For Login")} :
        </Title>
        <Text>
          {translate(
            "We will send you a 6-digit Verification code on Email Address"
          )}
        </Text>
        <div className="space20"></div>
        <Form
          layout="vertical"
          name="normal_login"
          className="login-form"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
        >
          <LoginForm />
          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              className="login-form-button"
              loading={isLoading}
              size="large"
            >
              {translate("Log in")}
            </Button>
            {translate("Or")}{" "}
            <a href="/mobile-login">{translate("login with Mobile Number")}!</a>
          </Form.Item>
        </Form>
      </Loading>
    );
  };

  return (
    <>
      <AuthModule authContent={<FormContainer />} AUTH_TITLE="Log In" />;
      <VerifyOtpModal
        loginFormData={{ email: email.email, mobile: "", dialCode: "" }}
        openModal={modalOpen}
        close={() => setModalOpen(true)}
      />
    </>
  );
};

export default LoginPage;
