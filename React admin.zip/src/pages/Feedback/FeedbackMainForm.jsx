import {
  SettingOutlined,
  CreditCardOutlined,
  DollarOutlined,
  FileImageOutlined,
  TrophyOutlined,
  UserOutlined,
  AuditOutlined,
} from "@ant-design/icons";

import TabsContent from "@/components/TabsContent/TabsContent";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";
import { Tabs } from "antd";
import TabPane from "antd/es/tabs/TabPane";

import Session from "../Session";
import Final from "./Final";
import FeedbackSession from "./Session";

export default function FeedBackMainForm() {
  const translate = useLanguage();
  const { settingsKey } = useParams();
  const content = [
    {
      key: "session",
      label: translate("session"),
      children: <FeedbackSession />,
    },
    {
      key: "final",
      label: translate("final"),
      children: <Final />,
    },
  ];

  const pageTitle = translate("FeedBack");

  return (
    <>
      <TabsContent
        defaultActiveKey={settingsKey}
        content={content}
        pageTitle={pageTitle}
      />
    </>
  );
}
