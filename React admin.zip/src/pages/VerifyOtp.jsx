import React, { useEffect, useState } from "react";
import { Form, Button, Typography, Space } from "antd";
import VerifyOtpForm from "@/forms/VerifyOtpForm";
import { useDispatch, useSelector } from "react-redux";
import useLanguage from "@/locale/useLanguage";
import { useNavigate, useParams } from "react-router-dom";
import { verifyotp } from "@/redux/auth/actions";
import { selectAuth } from "@/redux/auth/selectors";
import Loading from "@/components/Loading";

const { Title, Text } = Typography;
const VerifyOtpPage = ({ loginFormData }) => {
  const translate = useLanguage();
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const { isLoading, isSuccess } = useSelector(selectAuth);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleOtpDigitChange = (index, value) => {
    const updatedOtpDigits = [...otpDigits];

    if (/^\d*$/.test(value)) {
      updatedOtpDigits[index] = value;
      setOtpDigits(updatedOtpDigits);
    }
  };
  const onFinish = (values) => {
    const otpValues = otpDigits.join("");
    let data;
    if (loginFormData.email) {
      data = { email: loginFormData.email, otp: otpValues };
    } else {
      data = {
        mobile: loginFormData.mobile,
        dialCode: loginFormData.dialCode,
        otp: otpValues,
      };
    }
    dispatch(verifyotp({ loginData: data }));
    // Dispatch your verifyotp action or perform other actions
  };
  return (
    <Loading isLoading={isLoading}>
      <Space>
        <Form
          layout="vertical"
          name="verify-otp-form"
          className="login-form"
          onFinish={onFinish}
        >
          <Title level={1}></Title>
          <Title level={4}>{translate("Enter OTP")}:</Title>
          <Text>
            {translate(
              "Complete verification by providing the code that you received by email and registered mobile"
            )}
          </Text>
          <VerifyOtpForm onOtpChange={handleOtpDigitChange} />
          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              className="login-form-button"
              size="large"
            >
              {translate("Verify now")}
            </Button>
          </Form.Item>
        </Form>
      </Space>
    </Loading>
  );
};

export default VerifyOtpPage;
