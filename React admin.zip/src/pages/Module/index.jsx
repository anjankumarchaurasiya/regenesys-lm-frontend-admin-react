import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";
import { EyeOutlined } from "@ant-design/icons";

import useLanguage from "@/locale/useLanguage";

export default function Module() {
  const translate = useLanguage();
  const entities = {
    listEntity: "/module/filter/list",
    createEntity: "/module",
    updateEntity: "/module",
    linkedentity: "course",
    linkedlistEntity: "/course/filter/list",
    tableHeaderDropdown: {
      type: "",
      entity: "course/filter/list",
      renderAsTag: true,
      displayLabels: ["title"],
      searchFields: "title",
      dataIndex: ["course/filter/list", "title"],
    },
  };

  const customizeConfigParameters = {
    responseInnerObj: "module",
    params: "recordStatus=true",
  };

  const customizeLinkedConfigParameters = {
    responseInnerObj: "course",
  };
  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const deletedentity = {
    entityname: "module",
    bulkentityname: "moduleIds",
  };

  const activateEntity = {
    entityname: "module",
    bulkentityname: "moduleIds",
  };

  const ViewItems = [
    {
      label: translate("View Topic"),
      key: "viewtopic",
      icon: <EyeOutlined />,
    },
    {
      type: "divider",
    },
    {
      label: translate("View Usages"),
      key: "viewmoduleusages",
      icon: <EyeOutlined />,
    },
  ];

  const Labels = {
    PANEL_TITLE: translate("module"),
    DATATABLE_TITLE: translate("module"),
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("module"),
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    customizeLinkedConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    fields,
    filterFields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    ViewItems,
    listFields,
    activateEntity,
  };
  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
