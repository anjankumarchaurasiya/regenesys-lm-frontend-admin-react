export const fields = {
  title: {
    type: "string",
    required: true,
    maxLength: 100,
    minLength: 20,
  },

  description: {
    type: "textarea",
    required: true,
    maxLength: 500,
    minLength: 50,
  },

  createdOn: {
    type: "date",
    disableForForm: true,
  },
};

export const filterFields = {
  title: {
    type: "string",
    placeholder: "Title",
  },
  description: {
    type: "string",
    placeholder: "Description",
  },
  createdAt: {
    type: "date",
    placeholder: "Select date",
  },
  recordStatus: {
    type: "select",
    renderAsTag: true,
    defaultValue: true,
    className: "custome-filter-select",
    options: [
      { value: false, label: "Deactive" },
      { value: true, label: "Active" },
    ],
  },
};

export const listFields = {
  title: {
    type: "string",
    required: true,
  },

  description: {
    type: "textarea",
    required: true,
  },

  created_at: {
    type: "date",
    disableForForm: true,
    label: "Created On",
  },
};
