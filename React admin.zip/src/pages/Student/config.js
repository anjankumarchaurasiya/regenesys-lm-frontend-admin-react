export const fields = {
  firstName: {
    type: "Namestring",
    required: true,
    placeholder: "First Name",
  },
  lastName: {
    type: "Namestring",
    required: true,
    placeholder: "Last Name",
  },
  email: {
    type: "email",
    placeholder: "Email",
  },
  dialCode: {
    label: "Dial Code",
    type: "dialCodeWithCountry",
    placeholder: "Dial Code",
  },

  timeZone: {
    type: "selectForDynamicTimeZoneOption",
    label: "Country",
    displayLabels: ["name"],
    outputValue: "label",
    dataIndex: ["value", "name"],
    entity: "/category/filter/list",
    required: true,
    asyncOptions: null,
    responseInner: "category",
    placeholder: "Select Country",
  },
  mobile: {
    type: "phone",
    placeholder: "Mobile No",
  },
  dregNo: {
    type: "string",
    required: true,
    placeholder: "DREG No",
  },
  roles: {
    type: "selectMultiple",
    mode: "multiple",
    renderAsTag: true,
    placeholder: "Role",
    disabled: true,
    defaultValue: ["STUDENT"],
    options: [{ value: "STUDENT", label: "Student" }],
  },
};

export const filterFields = {
  firstName: {
    type: "string",
    placeholder: "First Name",
  },
  lastName: {
    type: "string",
    placeholder: "Last Name",
  },
  email: {
    type: "email",
    placeholder: "Email",
  },
  mobile: {
    type: "phone",
    placeholder: "Mobile No",
  },
  dregNo: {
    type: "string",
    placeholder: "DREG No",
  },
  recordStatus: {
    type: "select",
    renderAsTag: true,
    defaultValue: true,
    className: "custome-filter-select",
    options: [
      { value: false, label: "Deactive" },
      { value: true, label: "Active" },
    ],
  },
};

export const listFields = {
  firstName: {
    type: "string",
  },
  lastName: {
    type: "string",
  },
  email: {
    type: "email",
  },
  mobile: {
    type: "phone",
  },
  dregNo: {
    type: "string",
  },
  created_at: {
    type: "date",
    label: "Created On",
  },
};
