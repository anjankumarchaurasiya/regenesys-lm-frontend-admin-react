import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import useLanguage from "@/locale/useLanguage";
import { Form, Button, Typography } from "antd";
import { login } from "@/redux/auth/actions";
import { selectAuth } from "@/redux/auth/selectors";
import Loading from "@/components/Loading";
import AuthModule from "@/modules/AuthModule";
import LoginWithMobile from "@/forms/LoginWithMobileForm";
import VerifyOtpModal from "@/components/VeifyOtpModal";

const LoginWithMobilePage = () => {
  const translate = useLanguage();
  const [mobileData, setMobileData] = useState("");
  const { isLoading, isSuccess } = useSelector(selectAuth);
  const [modalOpen, setModalOpen] = useState("false");
  const { Title, Text } = Typography;
  const dispatch = useDispatch();
  const onFinish = async (values) => {
    const response = await dispatch(login({ loginData: values }));
    if (response.success) {
      setModalOpen(false);
      setMobileData(values);
    } else {
      setModalOpen(true);
    }
  };

  const FormContainer = () => {
    return (
      <Loading isLoading={isLoading}>
        <Title level={4}>
          {translate("Verify Your Mobile Number For Login")} :
        </Title>
        <Text>
          {translate(
            "We will send you a 6-digit Verification code on Mobile Number"
          )}
        </Text>
        <Form
          layout="vertical"
          name="normal_login"
          className="login-form"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
        >
          <LoginWithMobile />
          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              className="login-form-button"
              loading={isLoading}
              size="large"
            >
              {translate("Log in")}
            </Button>
            {translate("Or")}{" "}
            <a href="/email-login">{translate("login with Email")}!</a>
          </Form.Item>
        </Form>
      </Loading>
    );
  };

  return (
    <>
      <AuthModule authContent={<FormContainer />} AUTH_TITLE="Log In" />;
      <VerifyOtpModal
        loginFormData={{
          email: "",
          mobile: mobileData.mobile,
          dialCode: mobileData.dialCode,
        }}
        openModal={modalOpen}
        close={() => setModalOpen(true)}
      />
    </>
  );
};

export default LoginWithMobilePage;
