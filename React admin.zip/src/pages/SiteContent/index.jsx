import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";

import useLanguage from "@/locale/useLanguage";
import { EditOutlined } from "@ant-design/icons";

export default function SiteContent() {
  const translate = useLanguage();

  const entities = {
    listEntity: "/site-content",
    createEntity: "/site-content",
    updateEntity: "/site-content",
  };
  const customizeConfigParameters = {
    responseInnerObj: "sitecontent",
    params: "recordStatus=true",
  };

  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const deletedentity = {
    entityname: "site-content",
  };
  const Labels = {
    PANEL_TITLE: "Create Site Content",
    DATATABLE_TITLE: "Site content",
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: "Site content",
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    fields,
    filterFields,
    listFields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    inTableCheckBox: false,
  };

  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
