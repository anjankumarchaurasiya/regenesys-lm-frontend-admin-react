export const fields = {
  name: {
    type: "string",
    label: "Name",
    required: true,
    placeholder: "Name",
  },
  title: {
    type: "string",
    label: "Title",
    required: true,
    placeholder: "Title",
  },
  url: {
    type: "url",
    label: "Url",
    placeholder: "Url",
  },
  siteContent: {
    type: "tinymce",
    label: "Content",
    placeholder: "Content",
  },
  type: {
    type: "select",
    label: "Page type",
    required: true,
    placeholder: "Page type",
    disabled: true,
    defaultValue: [],
    options: [
      { value: "PAGE_CONTENT", label: "PAGE CONTENT" },
      { value: "FOOTER_LINK", label: "FOOTER LINK" },
    ],
  },
};

export const filterFields = {
  name: {
    type: "string",
    placeholder: "Name",
  },
  title: {
    type: "string",
    placeholder: "Title",
  },
  type: {
    type: "select",
    label: "Page type",
    required: true,
    placeholder: "Page type",
    disabled: true,
    defaultValue: [],
    options: [
      { value: "PAGE_CONTENT", label: "PAGE CONTENT" },
      { value: "FOOTER_LINK", label: "FOOTER LINK" },
    ],
  },
  createdAt: {
    type: "date",
    placeholder: "Select date",
  },
};

export const listFields = {
  name: {
    type: "string",
    label: "Name",
  },
  title: {
    type: "string",
    label: "Title",
  },
  url: {
    type: "linkString",
    label: "Link",
  },
  type: {
    type: "string",
    label: "Type",
  },
  // content: {
  //   type: "string",
  //   label: "Content",
  // },
  created_at: {
    type: "date",
    label: "Created On",
  },
};
