export const fields = {
  title: {
    type: "string",
    label: " Session Title",
    required: true,
    placeholder: "Learning Session Title",
  },
  courseId: {
    type: "asyncSelect",
    label: "course",
    displayLabels: ["title"],
    outputValue: "label",
    dataIndex: ["value", "title"],
    entity: "/course/filter/list",
    required: true,
    asyncOptions: null,
    responseInner: "course",
    placeholder: "course",
  },
  batchId: {
    type: "asyncSelect",
    label: "batch",
    displayLabels: ["batchNumber"],
    outputValue: "label",
    dataIndex: ["value", "batchNumber"],
    entity: "/batch/filter/list",
    required: true,
    asyncOptions: null,
    responseInner: "batch",
    placeholder: "batch",
  },

  status: {
    type: "string",
    label: "Status",
    required: true,
    placeholder: "Learning Session Title",
  },
  batchNumber: {
    type: "string",
    label: "Batch No",
    required: true,
    placeholder: "batch No.",
  },

  startDate: {
    type: "date",
    label: "Start Date",
    required: true,
  },
  endDate: {
    type: "date",
    label: "End Date",
    required: true,
  },
  classMode: {
    type: "select",
    label: "Mode of Class",
    mode: "multiple",
    renderAsTag: true,
    required: true,
    placeholder: "Mode of classes",
    disabled: true,
    defaultValue: [],
    options: [
      { value: "WEEK_DAYS", label: "Week Days" },
      { value: "WEEK_ENDS", label: "Week Ends" },
    ],
  },
  feedbackCategoryId: {
    // type: "asyncSelect",
    // label: "feedback category",
    // displayLabels: ["name"],
    // dataIndex: ["label"],
    // entity: "/category/filter/list",
    // required: true,
    // asyncOptions: {
    //   type: "feedback",
    // },
    // responseInner: "category",
    // placeholder: "feedback category",
    // outputValue: "label",

    type: "string",
    label: "Feeback Category",
    required: true,
    placeholder: "Feeback Category",
  },
};

export const filterFields = {
  filterBy: {
    type: "select",
    renderAsTag: true,
    placeholder: "Filter Fields",
    // defaultValue: "session",
    options: [
      { value: "course", label: "Course" },
      { value: "batch", label: "Batch" },
      { value: "SRM", label: "SRM" },
      { value: "TEACHER", label: "Primary Faculty" },
      { value: "secodaryFaculty", label: "Secondary Faculty" },
      { value: "date", label: "Session Date" },
      { value: "createdAt", label: "Date of Creation" },
      { value: "status", label: "Status" },
      { value: "Active/Deactive", label: "Active/Deactive" },
      // { value: "deactive", label: "Deactive" },
    ],
  },
  filterValue: {
    type: "sessionSelect",
    renderAsTag: true,
    options: [],
  },
};

export const listFields = {
  title: {
    type: "string",
    label: "Session Title",
    dataIndex: ["title"],
  },
  course: {
    type: "string",
    label: "Course",
    dataIndex: ["course", "title"],
  },
  batch: {
    type: "string",
    dataIndex: ["batch", "batchNumber"],
    label: "Batch",
  },
  SRM: {
    type: "concatString",
    label: "SRM",
    dataIndex: ["SRM", "firstName"],
  },
  PrimaryFaculty: {
    type: "concatString",
    label: "Primary faculty",
    dataIndex: ["PrimaryFaculty", "firstName"],
  },
  SecondaryFaculty: {
    type: "concatString",
    label: "Secondry faculty",
    dataIndex: ["SecondaryFaculty", "firstName"],
  },
  date: {
    type: "date",
    label: "Session Date",
    dataIndex: ["date"],
  },
  startTime: {
    type: "time",
    label: "Start Time",
  },
  endTime: {
    type: "time",
    label: "End Time",
  },
  feedbacks: {
    type: "string",
    label: "Feedback Category",
    dataIndex: ["feedbacks", "0", "title"],
  },
  created_at: {
    type: "date",
    label: "Creation Date",
  },
  status: {
    type: "tag",
    label: "Status",
    color: "red",
  },
  meetingUrl: {
    type: "linkString",
    label: "Meeting Link",
  },
};
