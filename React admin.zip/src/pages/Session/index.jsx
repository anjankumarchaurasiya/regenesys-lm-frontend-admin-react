import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";

import useLanguage from "@/locale/useLanguage";

export default function Session() {
  const translate = useLanguage();

  const entities = {
    listEntity: "/learning-session/filter/list",
    createEntity: "/learning-session",
    updateEntity: "/learning-session",
  };
  const customizeConfigParameters = {
    responseInnerObj: "learningSession",
    // params: "roles=STUDENT",
    params: "recordStatus=true",
  };
  const activateEntity = {
    entityname: "learning-session",
    bulkentityname: "learningSessionIds",
  };
  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const deletedentity = {
    entityname: "learning-session",
    bulkentityname: "learningSessionIds",
  };

  const Labels = {
    PANEL_TITLE: translate("Create Session"),
    DATATABLE_TITLE: translate("session"),
    // ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("session"),
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    fields,
    filterFields,
    listFields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    activateEntity,
  };

  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
