import CrudModule from "@/modules/CrudModule/CrudModule";
import DynamicForm from "@/forms/DynamicForm";
import { fields, filterFields, listFields } from "./config";

import useLanguage from "@/locale/useLanguage";

export default function AdminUserList() {
  const translate = useLanguage();

  const entities = {
    listEntity: "/user/filter/list",
    createEntity: "/user",
    updateEntity: "/user",
    linkedentity: "batch",
    linkedlistEntity: "/batch/filter/list",
    tableHeaderDropdown: {
      type: "",
      entity: "batch/filter/list",
      renderAsTag: true,
      displayLabels: ["batchNumber"],
      searchFields: "batchNumber",
      dataIndex: ["label"],
    },
  };
  const customizeConfigParameters = {
    responseInnerObj: "user",
    params: "roles=ADMIN&recordStatus=true",
  };
  const searchConfig = {
    displayLabels: ["name"],
    searchFields: "name",
  };
  const deleteModalLabels = ["name"];

  const deletedentity = {
    entityname: "user",
    bulkentityname: "userIds",
  };

  const activateEntity = {
    entityname: "user",
    bulkentityname: "userIds",
  };

  const Labels = {
    PANEL_TITLE: translate("admin"),
    DATATABLE_TITLE: translate("admin_list"),
    ADD_NEW_ENTITY: translate("create"),
    ENTITY_NAME: translate("admin"),
  };
  const configPage = {
    entities,
    customizeConfigParameters,
    ...Labels,
  };
  const config = {
    ...configPage,
    fields,
    filterFields,
    listFields,
    searchConfig,
    deleteModalLabels,
    deletedentity,
    activateEntity,
    // inTableCheckBox: false,
  };
  return (
    <CrudModule
      createForm={<DynamicForm fields={fields} />}
      updateForm={<DynamicForm fields={fields} />}
      config={config}
    />
  );
}
