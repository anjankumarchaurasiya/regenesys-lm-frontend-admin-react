import {
  SettingOutlined,
  CreditCardOutlined,
  DollarOutlined,
  FileImageOutlined,
  TrophyOutlined,
  UserOutlined,
  AuditOutlined,
} from "@ant-design/icons";

import TabsContent from "@/components/TabsContent/TabsContent";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";
import { Tabs } from "antd";
import TabPane from "antd/es/tabs/TabPane";

import Quiz from "./Quiz";
import Exam from "./Exam";
import Capstone from "./Capstone";

export default function QuizMainForm() {
  const translate = useLanguage();
  const { settingsKey } = useParams();
  const content = [
    {
      key: "quiz",
      label: translate("quiz"),
      children: <Quiz />,
    },
    {
      key: "exam",
      label: translate("exam"),
      children: <Exam />,
    },
    {
      key: "capstone",
      label: translate("capstone"),
      children: <Capstone />,
    },
  ];

  const pageTitle = translate("Quiz");

  return (
    <>
      <TabsContent
        defaultActiveKey={settingsKey}
        content={content}
        pageTitle={pageTitle}
      />
    </>
  );
}
