import React from "react";
import { Form, Typography, Space } from "antd";
import { useSelector } from "react-redux";
import { selectAuth } from "@/redux/auth/selectors";
import Loading from "@/components/Loading";

const { Title, Text } = Typography;
const UsagesPage = ({ description }) => {
  const { isLoading, isSuccess } = useSelector(selectAuth);

  return (
    <Loading isLoading={isLoading}>
      <Space>
        <Form layout="vertical" name="verify-otp-form" className="login-form">
          <Title level={4}>{description.title}:</Title>
          <Text>{description.description}</Text>
        </Form>
      </Space>
    </Loading>
  );
};

export default UsagesPage;
