import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { Link } from "react-router-dom";
import { Avatar, Dropdown, Layout } from "antd";
import { selectReadItem } from "@/redux/crud/selectors";
import { crud } from "@/redux/crud/actions";

// import Notifications from '@/components/Notification';

import { SettingOutlined, LogoutOutlined } from "@ant-design/icons";

import { checkImage } from "@/request";

import { selectCurrentAdmin } from "@/redux/auth/selectors";

import { useNavigate } from "react-router-dom";

import { BASE_URL } from "@/config/serverApiConfig";

import useLanguage from "@/locale/useLanguage";
import SelectLanguage from "@/components/SelectLanguage";

import UpgradeButton from "./UpgradeButton";

export default function HeaderContent() {
  const currentAdmin = useSelector(selectCurrentAdmin);
  const { Header } = Layout;

  const translate = useLanguage();

  const [hasPhotoprofile, setHasPhotoprofile] = useState(false);
  const [profileData, setProfileData] = useState("");
  const dispatch = useDispatch();

  const {
    result: currentResult,
    isSuccess,
    isLoading = true,
  } = useSelector(selectReadItem);

  useEffect(() => {
    async function fetchData() {
      if (currentAdmin?.photo) {
        const result = await checkImage(BASE_URL + currentAdmin?.photo);
        setHasPhotoprofile(result);
      }
    }
    fetchData();
    if (currentResult != null) {
      setProfileData(currentResult);
    }
    return () => {
      return false;
    };
  }, [currentResult]);

  useEffect(() => {
    const listEntity = "user";
    const id = currentAdmin?.userId;
    dispatch(
      crud.read({
        listEntity,
        id,
      })
    );
  }, []);

  const ProfileDropdown = () => {
    const navigate = useNavigate();
    return (
      <div className="profileDropdown" onClick={() => navigate("/profile")}>
        <Avatar
          size="large"
          className="last"
          src={hasPhotoprofile ? BASE_URL + currentAdmin?.photo : null}
          style={{
            color: "#f56a00",
            backgroundColor: !hasPhotoprofile ? "#fde3cf" : "#f9fafc",
          }}
        >
          {profileData?.firstName?.charAt(0)?.toUpperCase()}
        </Avatar>
        <div className="profileDropdownInfo">
          <p>
            {profileData?.firstName} {profileData?.lastName}
          </p>
          <p>{profileData?.email}</p>
        </div>
      </div>
    );
  };

  const DropdownMenu = ({ text }) => {
    return <span style={{}}>{text}</span>;
  };

  const items = [
    {
      label: <ProfileDropdown className="headerDropDownMenu" />,
      key: "ProfileDropdown",
    },
    {
      type: "divider",
    },
    {
      icon: <SettingOutlined />,
      key: "settingProfile",
      label: (
        <Link to={"/profile"}>
          <DropdownMenu text={translate("profile_settings")} />
        </Link>
      ),
    },

    {
      type: "divider",
    },

    {
      icon: <LogoutOutlined />,
      key: "logout",
      label: <Link to={"/logout"}>{translate("logout")}</Link>,
    },
  ];
  return (
    <Header className="header-avatar">
      <Dropdown
        menu={{
          items,
        }}
        trigger={["click"]}
        placement="bottomRight"
        stye={{ width: "280px", float: "right" }}
      >
        {/* <Badge dot> */}
        <Avatar
          className="last"
          src={hasPhotoprofile ? BASE_URL + currentAdmin?.photo : null}
          style={{
            color: "#f56a00",
            backgroundColor: !hasPhotoprofile ? "#fde3cf" : "#f9fafc",
            float: "right",
            cursor: "pointer",
          }}
          size="large"
        >
          {profileData?.firstName?.charAt(0)?.toUpperCase()}
        </Avatar>
        {/* </Badge> */}
      </Dropdown>

      {/* <UpgradeButton /> */}
      <div className="admin-header-name">
        <p className="mb-0">
          {profileData?.firstName} {profileData?.lastName}
        </p>
      </div>
      {/* <SelectLanguage /> */}
    </Header>
  );
}
