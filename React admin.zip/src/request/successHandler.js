import { notification } from "antd";

import codeMessage from "./codeMessage";

const successHandler = (
  response,
  options = { notifyOnSuccess: false, notifyOnFailed: true }
) => {
  const { data, success } = response;
  if (data && data.success == true) {
    // const message = response.data && data.message;
    const successText = codeMessage[response.status];
    if (options.notifyOnSuccess && response?.message) {
      notification.config({
        duration: 2,
        maxCount: 2,
      });
      const successMessage = response?.message;
      notification.success({
        message: successMessage,
        description: successText,
      });
    }
    return response.data;
  } else {
    // const message = response.data && data.message;
    const errorText = codeMessage[response.status];
    const { status } = response;

    if (options.notifyOnFailed && response?.message) {
      notification.config({
        duration: 4,
        maxCount: 2,
      });
      const errorMessage = response?.message;
      notification.success({
        message: errorMessage,
        description: errorText,
      });
    }
    return response.data;
  }
};

export default successHandler;
