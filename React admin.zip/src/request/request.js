// import axios from "axios";
import { API_BASE_URL } from "@/config/serverApiConfig";
import axios from "./axiosConfig";
import errorHandler from "./errorHandler";
import successHandler from "./successHandler";
axios.defaults.baseURL = API_BASE_URL;

// axios.defaults.withCredentials = true;

const request = {
  create: async ({
    listEntity,
    createEntity,
    jsonData,
    customizeConfigParameters,
  }) => {
    try {
      if (
        customizeConfigParameters?.fileEntityName?.isfileUpload &&
        jsonData.file
      ) {
        // Upload file to S3
        const formData = {
          file: jsonData.file[0].originFileObj,
          entityName: customizeConfigParameters?.fileEntityName?.entityName,
          entityType: customizeConfigParameters?.fileEntityName?.entityType,
        };
        // Thumbnail upload api call
        const fileUploadResponse = await axios.post(
          "common/s3/file-upload",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        // Check if the file upload was successful
        if (!fileUploadResponse.success) {
          // Handle error for file upload failure
          throw new Error("File upload failed");
        }

        // Proceed with the second API call
        delete jsonData.file;
        const fieldName = customizeConfigParameters?.fileEntityName?.fieldName;
        // Check if the custom field name exists and is to be replaced
        if (fieldName && jsonData[fieldName] !== undefined) {
          delete jsonData[fieldName];
          jsonData[fieldName] = fileUploadResponse?.data?.Location;
        }
        // Second API call
        const response = await axios.post(createEntity + "/", jsonData);
        successHandler(response, {
          notifyOnSuccess: true,
          notifyOnFailed: true,
        });

        return response;
      } else {
        // If file upload is not needed, proceed with the second API call directly
        const response = await axios.post(createEntity + "/", jsonData);
        successHandler(response, {
          notifyOnSuccess: true,
          notifyOnFailed: true,
        });

        return response;
      }
    } catch (error) {
      // Handle errors for both file upload and second API call
      return errorHandler(error);
    }
  },
  createAndUpload: async ({ listEntity, jsonData }) => {
    try {
      let response = await axios.post(listEntity, jsonData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  read: async ({ listEntity, id }) => {
    try {
      const response = await axios.get(listEntity + "/" + id);
      successHandler(response, {
        notifyOnSuccess: false,
        notifyOnFailed: true,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  update: async ({
    customizeUrl,
    dataObject,
    listEntity,
    updateEntity,
    id,
    jsonData,
    customizeConfigParameters,
  }) => {
    try {
      let response;
      if (customizeUrl !== undefined) {
        response = await axios.patch(customizeUrl, dataObject);
      } else if (jsonData == undefined) {
        response = await axios.patch(updateEntity + "/" + id, dataObject);
      } else if (
        customizeConfigParameters?.fileEntityName?.isfileUpload &&
        jsonData.file
      ) {
        const formData = {
          file: jsonData.file[0].originFileObj,
          entityName: customizeConfigParameters?.fileEntityName?.entityName,
          entityType: customizeConfigParameters?.fileEntityName?.entityType,
        };
        const fileUploadResponse = await axios.post(
          "common/s3/file-upload",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        if (!fileUploadResponse.success) {
          // Handle error for file upload failure
          throw new Error("File upload failed");
        }
        delete jsonData.file;
        const fieldName = customizeConfigParameters?.fileEntityName?.fieldName;

        if (fieldName && jsonData[fieldName] !== undefined) {
          delete jsonData[fieldName];
          jsonData[fieldName] = fileUploadResponse?.data?.Location;
        }
        response = await axios.patch(updateEntity + "/" + id, jsonData);
        successHandler(response, {
          notifyOnSuccess: true,
          notifyOnFailed: true,
        });
        return response;
      } else {
        response = await axios.patch(updateEntity + "/" + id, jsonData);
      }
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  updateAndUpload: async ({ listEntity, id, jsonData }) => {
    try {
      const response = await axios.patch(
        listEntity + "/update/" + id,
        jsonData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },
  delete: async ({
    customizeUrl,
    listEntity,
    deleteEntityName,
    id,
    BulkData,
  }) => {
    try {
      let response;
      if (customizeUrl != undefined) {
        response = await axios.delete(customizeUrl);
      } else if (BulkData?.bulKIds.length > 1) {
        response = await axios.delete(deleteEntityName + "/bulk", {
          data: BulkData?.dataObject,
        });
      } else if (BulkData?.bulKIds.length == 1) {
        response = await axios.delete(
          deleteEntityName + "/" + BulkData?.bulKIds[0]
        );
      } else {
        response = await axios.delete(deleteEntityName + "/" + id);
      }
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  filter: async ({ listEntity, options = {} }) => {
    try {
      let filter = options.filter ? "filter=" + options.filter : "";
      let equal = options.equal ? "&equal=" + options.equal : "";
      let query = `?${filter}${equal}`;

      const response = await axios.get(listEntity + "/filter" + query);
      successHandler(response, {
        notifyOnSuccess: false,
        notifyOnFailed: false,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },
  search: async ({ entity, options = {} }) => {
    try {
      let query = "?";
      for (var key in options) {
        query += key + "=" + options[key] + "&";
      }
      query = query.slice(0, -1);
      // headersInstance.cancelToken = source.token;
      const response = await axios.get(entity + query);

      successHandler(response, {
        notifyOnSuccess: false,
        notifyOnFailed: false,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  list: async ({
    listEntity,
    customizeConfigParameters = {},
    options = {},
  }) => {
    try {
      let query = "?";
      for (var key in options) {
        query += key + "=" + options[key] + "&";
      }

      if (customizeConfigParameters) {
        query += customizeConfigParameters.params;
      }
      if (customizeConfigParameters.extraparams) {
        query += customizeConfigParameters.extraparams;
      }

      /** remove duplicate params */
      const params = new URLSearchParams(query);
      const seenParams = new Set();
      const filteredParams = new URLSearchParams();

      params.forEach((value, key) => {
        if (key === "categoryIds") {
          // For 'categoryIds', keep duplicate params
          filteredParams.append(key, value);
        } else {
          if (seenParams.has(key)) {
            filteredParams.delete(key);
          }
          seenParams.add(key);
          filteredParams.append(key, value);
        }
      });

      const updatedQueryString = filteredParams.toString()
        ? `?${filteredParams.toString()}`
        : "";
      /** remove duplicate params */
      const response = await axios.get(
        updatedQueryString == "" || updatedQueryString == "?undefined="
          ? listEntity
          : `${listEntity}${updatedQueryString}`
      );
      successHandler(response, {
        notifyOnSuccess: false,
        notifyOnFailed: false,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  listAll: async ({ listEntity }) => {
    try {
      const response = await axios.get(listEntity + "/listAll");

      successHandler(response, {
        notifyOnSuccess: false,
        notifyOnFailed: false,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },

  // post: async ({listEntity , jsonData }) => {
  //   try {
  //     const response = await axios.post(listEntity, jsonData);

  //     return response.data;
  //   } catch (error) {
  //     return errorHandler(error);
  //   }
  // },

  post: async ({ customizeUrl, listEntity, jsonData, dataObject }) => {
    try {
      let response;
      if (customizeUrl != "") {
        response = await axios.post(customizeUrl, dataObject);
      } else {
        response = await axios.post(listEntity, jsonData);
      }

      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },

  get: async ({ listEntity, customizeUrl, dataObject }) => {
    try {
      let response;
      if (customizeUrl != "") {
        response = await axios.get(customizeUrl, {
          params: dataObject,
        });
      } else {
        response = await axios.get(listEntity);
      }
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },
  // patch: async ({ listEntity, jsonData }) => {
  //   try {
  //     const response = await axios.patch(listEntity, jsonData);
  //     successHandler(response, {
  //       notifyOnSuccess: true,
  //       notifyOnFailed: true,
  //     });
  //     return response.data;
  //   } catch (error) {
  //     return errorHandler(error);
  //   }
  // },

  s3FileUpload: async ({ jsonData }) => {
    try {
      const response = await axios.post("common/s3/file-upload", jsonData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      return response;
    } catch (error) {
      return errorHandler(error);
    }
  },
  upload: async ({ entity, id, jsonData }) => {
    try {
      const response = await axios.patch(entity + "/upload/" + id, jsonData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },

  source: () => {
    const CancelToken = axios.CancelToken;
    const source = CancelToken.source();
    return source;
  },

  summary: async ({ listEntity }) => {
    // try {
    //   const response = await axios.get(listEntity + "/summary");
    //   successHandler(response, {
    //     notifyOnSuccess: false,
    //     notifyOnFailed: false,
    //   });
    //   return response.data;
    // } catch (error) {
    //   return errorHandler(error);
    // }
  },

  mail: async ({ entity, jsonData }) => {
    try {
      const response = await axios.post(entity + "/mail/", jsonData);
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },

  convert: async ({ entity, id }) => {
    try {
      const response = await axios.get(`${entity}/convert/${id}`);
      successHandler(response, {
        notifyOnSuccess: true,
        notifyOnFailed: true,
      });
      return response.data;
    } catch (error) {
      return errorHandler(error);
    }
  },
};
export default request;
