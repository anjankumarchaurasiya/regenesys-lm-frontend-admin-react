// axiosConfig.js
import axios from "axios";

const instance = axios.create();

// Function to dynamically set up the request interceptor with the latest token
const setupRequestInterceptor = (token) => {
  instance.interceptors.request.use(
    (config) => {
      try {
        // Retrieve auth data from localStorage
        const authData = window?.localStorage?.auth
          ? JSON.parse(window?.localStorage?.auth)
          : null;

        // Extract current token
        const currentToken = authData?.current?.accessToken;

        // Set Authorization header
        config.headers.Authorization = `Bearer ${currentToken}`;
      } catch (error) {
        console.error("Error setting up request interceptor", error);
      }

      return config;
    },
    (error) => {
      console.error("Request Interceptor Error for list function", error);
      return Promise.reject(error);
    }
  );
};

// Initial setup with the token from localStorage
const initializeInterceptor = () => {
  try {
    // Retrieve auth data from localStorage
    const authData = window?.localStorage?.auth
      ? JSON.parse(window?.localStorage?.auth)
      : null;

    // Extract current token
    const currentToken = authData?.current?.accessToken;

    // Set up request interceptor with initial token
    setupRequestInterceptor(currentToken);
  } catch (error) {
    console.error("Error initializing interceptor", error);
  }
};

// Initialize interceptor when the script runs
initializeInterceptor();

// Set up the storage event listener
window.addEventListener("storage", (event) => {
  if (event.key === "auth") {
    try {
      // Retrieve auth data from localStorage
      const authData = window?.localStorage?.auth
        ? JSON.parse(window?.localStorage?.auth)
        : null;

      // Extract new token
      const newToken = authData?.current?.accessToken;

      // Update request interceptor with the new token
      setupRequestInterceptor(newToken);
    } catch (error) {
      console.error("Error handling storage event", error);
    }
  }
});

// Response interceptor
instance.interceptors.response.use(
  (response) => {
    // Modify the response data before resolving the promise
    return response.data;
  },
  (error) => {
    // Handle response error
    if (error.response && error.response.status === 401) {
      // Redirect to login page if the status code is 401
      window.location.href = "/logout"; // You can use React Router's history.push('/login') if you are using React Router
    }
    return Promise.reject(error);
  }
);

export default instance;
