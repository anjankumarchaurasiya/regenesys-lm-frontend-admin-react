import dayjs from "dayjs";
import { Button, Switch, Tag } from "antd";
import { CloseOutlined, CheckOutlined, CopyOutlined } from "@ant-design/icons";
import { countryList } from "@/utils/countryList";
import { generate as uniqueId } from "shortid";
import color from "@/utils/color";
import { getFieldValue } from "./helpers";

export const dataForRead = ({
  fields,
  translate,
  filterFields,
  listFields,
}) => {
  let columns = [];

  Object.keys(listFields).forEach((key) => {
    let field = listFields[key];
    columns.push({
      title: field.label ? field.label : key,
      dataIndex: field.dataIndex ? field.dataIndex.join(".") : key,
      isDate: field.type === "date",
    });
  });

  return columns;
};

export function dataForTable({
  filterFields,
  translate,
  moneyFormatter,
  dateFormat,
  listFields,
}) {
  let columns = [];

  Object.keys(listFields).forEach((key) => {
    let field = listFields[key];

    const keyIndex = field.dataIndex ? field.dataIndex : [key];
    const endTime = field.endTime ? field.endTime : [key];
    const nested = field.nested ? field.nested : [key];
    const batches = field.batches ? field.batches : [key];

    const attendanceStatus = field.attendanceStatus
      ? field.attendanceStatus
      : [key];
    const component = {
      boolean: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        onCell: () => ({
          props: {
            style: {
              width: "60px",
            },
          },
        }),
        render: (_, record) => (
          <Switch
            checked={record[key]}
            checkedChildren={<CheckOutlined />}
            unCheckedChildren={<CloseOutlined />}
          />
        ),
      },
      date: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          const date = dayjs(record[key]).format(dateFormat);
          return (
            <Tag bordered={false} color={field.color}>
              {date}
            </Tag>
          );
        },
      },

      time: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          const parsedTime = dayjs(record[key], "HH:mm:ss");
          // const formattedTime = parsedTime.format("h:mm A");
          let displayTime;
          if (parsedTime.isValid()) {
            displayTime = parsedTime.format("h:mm A");
          } else {
            displayTime = dayjs().format("h:mm A");
          }
          return (
            <>
              <label className=" text-size-12 text-nowrap">{displayTime}</label>
            </>
          );
        },
      },
      sessionDate: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[key]?.date}`}{" "}
              </label>
            </>
          );
        },
      },

      attendanceStatus: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: attendanceStatus,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[attendanceStatus] == "" ? "Absent" : "Present"}`}
              </label>
            </>
          );
        },
      },
      sessionEndTime: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: endTime,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[endTime]?.endTime}`}
              </label>
            </>
          );
        },
      },

      batchNo: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${
                  record["batch_quizzes"] != ""
                    ? record?.batch_quizzes[0]?.batch?.batchNumber
                    : "-"
                }`}
              </label>
            </>
          );
        },
      },

      SessionbatchNo: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record?.learning_session?.batch?.batchNumber}`}
              </label>
            </>
          );
        },
      },

      SessionCourse: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record?.learning_session?.course?.title}`}
              </label>
            </>
          );
        },
      },

      FeedbackCourse: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record?.learning_session?.batch?.course?.title}`}
              </label>
            </>
          );
        },
      },
      FeedbackBatchCourse: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record?.course?.title}`}
              </label>
            </>
          );
        },
      },

      examDate: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${
                  record["batch_quizzes"] != ""
                    ? record?.batch_quizzes[0]?.examDate
                    : "-"
                }`}
              </label>
            </>
          );
        },
      },

      SessionstartTime: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${
                  record["batch_quizzes"] != ""
                    ? record?.batch_quizzes[0]?.startTime
                    : "-"
                }`}
              </label>
            </>
          );
        },
      },

      batchStartTime: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: batches,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${
                  record["batch_quizzes"] != ""
                    ? record?.batch_quizzes[0]?.startTime
                    : "-"
                }`}
              </label>
            </>
          );
        },
      },
      concatString: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[key]?.firstName} ${record[key]?.lastName}`}{" "}
              </label>
            </>
          );
        },
      },

      concatStringFaculty: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[key]?.PrimaryFaculty?.firstName} ${record[key]?.PrimaryFaculty?.lastName}`}{" "}
              </label>
            </>
          );
        },
      },
      nestedConcatString: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: nested,
        render: (_, record) => {
          return (
            <>
              <label className=" text-size-12 text-nowrap">
                {`${record[nested]?.SRM?.firstName} ${record[nested]?.SRM?.lastName}`}{" "}
              </label>
            </>
          );
        },
      },
      currency: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        onCell: () => {
          return {
            style: {
              textAlign: "right",
              whiteSpace: "nowrap",
            },
          };
        },
        render: (_, record) => moneyFormatter({ amount: record[key] }),
      },
      async: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (text, record) => {
          return (
            <Tag
              bordered={false}
              color={field.color || record[key]?.color || record.color}
            >
              {text}
            </Tag>
          );
        },
      },
      color: {
        title: field.label ? field.label : key,
        dataIndex: keyIndex,
        render: (text, record) => {
          return (
            <Tag bordered={false} color={text}>
              {color.find((x) => x.value === text)?.label}
            </Tag>
          );
        },
      },
      stringWithColor: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (text, record) => {
          return (
            <Tag bordered={false} color={record.color}>
              {text}
            </Tag>
          );
        },
      },
      linkString: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (text, record) => {
          const displayText =
            text.length > 50 ? `${text.substring(0, 50)}...` : text;
          return (
            <>
              <div className="d-flex align-items-center gap-2">
                <Button
                  type="ghost"
                  icon={<CopyOutlined />}
                  size="small"
                  onClick={() => navigator.clipboard.writeText(text)}
                >
                  Copy Link
                </Button>
              </div>
            </>
          );
        },
      },

      tag: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          const status =
            key === "status"
              ? getFieldValue(record, "status") === "COMPLETED"
                ? "Completed"
                : getFieldValue(record, "status") === "SCHEDULED"
                  ? "Scheduled"
                  : "Cancelled"
              : record[key];
          return (
            <Tag
              bordered={false}
              className="rounded-4 py-1 px-2"
              color={
                key === "status"
                  ? status === "Completed"
                    ? "green"
                    : status === "Scheduled"
                      ? "blue"
                      : "red"
                  : field.color
              }
            >
              {status && status}
            </Tag>
          );
        },
      },
      selectwithfeedback: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (text, record) => {
          if (field.renderAsTag) {
            const selectedOption = field.options.find(
              (x) => x.value === record[key]
            );

            return (
              <Tag bordered={false} color={selectedOption?.color}>
                {record[key] && translate(record[key])}
              </Tag>
            );
          } else return record[key] && translate(record[key]);
        },
      },
      select: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          if (field.renderAsTag) {
            const selectedOption = field.options.find(
              (x) => x.value === record[key]
            );

            return (
              <Tag bordered={false} color={selectedOption?.color}>
                {record[key] && record[key]}
              </Tag>
            );
          } else return record[key] && record[key];
        },
      },
      selectWithTranslation: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          if (field.renderAsTag) {
            const selectedOption = field.options.find(
              (x) => x.value === record[key]
            );

            return (
              <Tag bordered={false} color={selectedOption?.color}>
                {record[key] && translate(record[key])}
              </Tag>
            );
          } else return record[key] && translate(record[key]);
        },
      },
      array: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          return record[key].map((x) => (
            <Tag bordered={false} key={`${uniqueId()}`} color={field.colors[x]}>
              {x}
            </Tag>
          ));
        },
      },
      country: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => {
          const selectedCountry = countryList.find(
            (obj) => obj.value === record[key]
          );

          return (
            <Tag bordered={false} color={field.color || undefined}>
              {selectedCountry?.icon && selectedCountry?.icon + " "}
              {selectedCountry?.label && translate(selectedCountry.label)}
            </Tag>
          );
        },
      },
      button: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => (
          <Button className="table-data-button">{record[key]}</Button>
        ),
      },
      linkButton: {
        title: field.label ? translate(field.label) : translate(key),
        dataIndex: keyIndex,
        render: (_, record) => (
          <span className="link-button">{record[key]}</span>
        ),
      },
    };

    const defaultComponent = {
      title: field.label ? translate(field.label) : translate(key),
      dataIndex: keyIndex,
    };

    const type = field.type;

    if (!field.disableForTable) {
      Object.keys(component).includes(type)
        ? columns.push(component[type])
        : columns.push(defaultComponent);
    }
  });

  return columns;
}

function getRandomColor() {
  const colors = [
    "magenta",
    "red",
    "volcano",
    "orange",
    "gold",
    "lime",
    "green",
    "cyan",
    "blue",
    "geekblue",
    "purple",
  ];

  // Generate a random index between 0 and the length of the colors array
  const randomIndex = Math.floor(Math.random() * colors.length);

  // Return the color at the randomly generated index
  return colors[randomIndex];
}
