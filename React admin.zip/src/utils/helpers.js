import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
export function get(obj, key) {
  return key.split(".").reduce(function (o, x) {
    return o === undefined || o === null ? o : o[x];
  }, obj);
}

Object.byString = function (o, s) {
  s = s.replace(/\[(\w+)\]/g, ".$1"); // convert indexes to properties
  s = s.replace(/^\./, ""); // strip a leading dot
  let a = s.split(".");
  for (let i = 0, n = a.length; i < n; ++i) {
    let k = a[i];
    if (o !== null) {
      if (k in o) {
        o = o[k];
      } else {
        return;
      }
    } else {
      return;
    }
  }
  return o;
};

/* 
 To check only if a property exists, without getting its value. It similar get function.
*/
export function has(obj, key) {
  return key.split(".").every(function (x) {
    if (typeof obj !== "object" || obj === null || x in obj === false)
      /// !x in obj or  x in obj === true *** if you find any bug
      return false;
    obj = obj[x];
    return true;
  });
}

/* 
 convert indexes to properties
*/
export function valueByString(obj, string, devider) {
  if (devider === undefined) {
    devider = "|";
  }
  return string
    .split(devider)
    .map(function (key) {
      return get(obj, key);
    })
    .join(" ");
}

/*
 Submit multi-part form using ajax.
*/
export function toFormData(form) {
  let formData = new FormData();
  const elements = form.querySelectorAll("input, select, textarea");
  for (let i = 0; i < elements.length; ++i) {
    const element = elements[i];
    const name = element.name;

    if (name && element.dataset.disabled !== "true") {
      if (element.type === "file") {
        const file = element.files[0];
        formData.append(name, file);
      } else {
        const value = element.value;
        if (value && value.trim()) {
          formData.append(name, value);
        }
      }
    }
  }

  return formData;
}

/*
 Format Date to display admin
*/
export function formatDate(param) {
  const date = new Date(param);
  let day = date.getDate().toString();
  let month = (date.getMonth() + 1).toString();
  const year = date.getFullYear();
  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;
  const fullDate = `${day}/${month}/${year}`;
  return fullDate;
}

export const isDate = function ({ date, format = "YYYY-MM-DD" }) {
  if (typeof date == "boolean") return false;
  if (typeof date == "number") return false;
  if (dayjs(date, format).isValid()) return true;
  return false;
};
/*
 Format Datetime to display admin
*/
export function formatDatetime(param) {
  let time = new Date(param).toLocaleTimeString();
  return formatDate(param) + " " + time;
}

/*
  Regex to validate phone number format
*/
export const validatePhoneNumber = /^\d+$/;

/*
 Set object value in html
*/
// Date format in DD-MM-YYYY
export function convertDateFormat(dateString) {
  return dayjs(dateString).format("DD-MM-YYYY");
}

// Date format in DD-MM-YYYY
export function convertDateFormatReverse(dateString) {
  return dayjs(dateString).format("YYYY-MM-DD");
}

export function convertTimeFormat(timeString) {
  return dayjs(timeString).format("HH:mm:ss");
}

export function convertMinutesFormat(timeString) {
  return dayjs(timeString).format("mm");
}

export const disabledDate = (current) => {
  return current && current < dayjs().endOf("day");
};
export const disabledExamDate = (current) => {
  const currentTimestamp = dayjs(current).valueOf();
  const todayTimestamp = dayjs().startOf("day").valueOf();

  return currentTimestamp < todayTimestamp;
};
export const getDisplayLabels = (filterBy) => {
  if (filterBy === "course") {
    return ["title"];
  }
  if (filterBy === "category") {
    return ["name"];
  }
  if (filterBy === "learning-session") {
    return ["title"];
  }
  if (filterBy === "batch") {
    return ["batchNumber"];
  }
  if (
    filterBy === "SRM" ||
    filterBy === "secodaryFaculty" ||
    filterBy === "TEACHER" ||
    filterBy === "STUDENT"
  ) {
    return ["firstName", "lastName"];
  }
};
export const getOutpuValue = (filterBy) => {
  if (filterBy === "course") {
    return "id";
  }
  if (filterBy === "learning-session") {
    return "title";
  }
  if (filterBy === "batch") {
    return "id";
  }
  if (filterBy === "STUDENT") {
    return "firstName";
  }
  if (filterBy === "USER") {
    return "firstName";
  }
  if (
    filterBy === "SRM" ||
    filterBy === "secodaryFaculty" ||
    filterBy === "TEACHER" ||
    filterBy === "category"
  ) {
    return "id";
  }
};

export const getField = (filterBy, config) => {
  if (filterBy === "course") return "courseId";
  if (filterBy === "STUDENT" && config.ENTITY_NAME !== "Viewfeedback") {
    return "userName";
  }
  if (filterBy === "STUDENT" && config.ENTITY_NAME === "Viewfeedback")
    return "name";
  if (filterBy === "USER") return "reportedBy";
  if (filterBy === "batch") return "batchId";
  if (filterBy === "SRM") return "srmId";
  if (filterBy === "TEACHER") return "primaryFacultyId";
  if (filterBy === "secodaryFaculty") return "secondaryFacultyId";
  if (filterBy === "date") return "date";
  if (filterBy === "createdAt") return "createdAt";
  if (filterBy === "status") return "status";
  if (filterBy === "Active/Deactive") return "recordStatus";
  if (filterBy === "learning-session") return "title";
  if (filterBy === "category") return "feedbackCategoryId";
};

export const getStatus = (statusKey) => {
  if (statusKey === "CANCELLED") return "CANCELLED";
  if (statusKey === "SCHEDULED") return "SCHEDULED";
  if (statusKey === "COMPLETED") return "COMPLETED";
};

export const isActive = (key) => {
  if (key === "active") return true;
  else return false;
};

export const getFieldValue = (obj, objKey) => {
  for (let key in obj) {
    if (key === objKey) {
      return obj[key];
    } else if (typeof obj[key] === "object" && obj[key] !== null) {
      const status = getFieldValue(obj[key], objKey);
      if (status !== undefined) {
        return status;
      }
    }
  }
};
