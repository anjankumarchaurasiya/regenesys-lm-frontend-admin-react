import React, { useState, useEffect } from "react";
import { Form, Input, Button, Typography, Upload, message } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import useLanguage from "@/locale/useLanguage";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import {
  selectCreatedItem,
  selectUpdatedItem,
} from "@/redux/adavancedCrud/selectors";

import { useSelector, useDispatch } from "react-redux";

const { Title, Text } = Typography;

const UploadExcelPage = ({ onComplete, record, entityName }) => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();

  const translate = useLanguage();
  const { isLoading, isSuccess } = useSelector(selectCreatedItem);
  const { isSuccess: updateSuccess } = useSelector(selectUpdatedItem);
  const titleErrorMessage = translate("title_can_only_be_Aplha_Numeric");

  const descriptionErrorMessage = translate(
    "description_can_only_be_Aplha_Numeric"
  );
  const excelErrorMessage = translate("you_can_only_upload_excel_files");

  const [fileList, setFileList] = useState([]);
  const [content, setContent] = useState({});

  const [uploadType, setUploadType] = useState("upload");
  const onFinish = (values) => {
    // Handle form submission here

    const isNumericTitle = /^[0-9]+$/.test(values?.title);
    const isNumericDescription = /^[0-9]+$/.test(values?.description);

    if (isNumericTitle) {
      message.error(titleErrorMessage);
    }
    if (isNumericDescription) {
      message.error(descriptionErrorMessage);
    } else {
      const uploadedFileName =
        values.excel != undefined ? values.excel[0].name : values.excelUrl;
      const updatedTitleName = values?.title;
      const updatedDescription = values?.description;
      setContent({ uploadedFileName, updatedTitleName, updatedDescription });
      const formData = new FormData();
      const fields = {
        title: values.title,
        description: values.description,
        entityName: entityName === "QUIZQUESTION" ? entityName : "TOPIC",
        entityType: "EXCEL",
        type: "EXCEL",
        excelUrl: values.excelUrl,
      };

      Object.entries(fields).forEach(([key, value]) =>
        formData.append(key, value)
      );

      if (values.excelUrl === undefined) {
        const file = values.excel[0].originFileObj; // Get the file object
        formData.append("file", file); // Append the file object to the FormData
      }

      const listEntity = "content";
      const updateEntity = "content";

      if (record === null || record === undefined) {
        dispatch(
          advancedCrud.create({
            listEntity,
            jsonData: formData,
            withUpload: true,
          })
        );
        form.resetFields();
      } else {
        dispatch(
          advancedCrud.update({
            updateEntity,
            dataObject: formData,
            id: record.id,
            withUpload: false,
          })
        );
      }

      // if (!record) {
      //   onComplete(uploadedFileName);
      // } else {
      //   onComplete(updatedTitleName, updatedDescription, record);
      // }
    }
  };

  const onUploadChange = (info) => {
    if (info.file.status === "done") {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === "error") {
      message.error(`${info.file.name} file upload failed.`);
    }
  };

  const beforeUpload = (file) => {
    // Add custom validation logic for the Excel file type
    const isExcel =
      file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      file.name.endsWith(".xls"); // Check if the file extension is '.xls'

    if (!isExcel) {
      message.error(excelErrorMessage);
    }

    return false;
  };

  useEffect(() => {
    if (record) {
      form.setFieldsValue({
        title: record.title,
        description: record.description,
      });
    }
  }, [record, form]);

  useEffect(() => {
    if (isSuccess || updateSuccess) {
      if (!record) {
        onComplete(content.uploadedFileName);
        form.resetFields();
        dispatch(advancedCrud.resetAction({ actionType: "create" }));
      } else {
        onComplete(
          content.updatedTitleName,
          content.updatedDescription,
          record
        );
        form.resetFields();
        dispatch(advancedCrud.resetAction({ actionType: "update" }));
      }
    }
  }, [isSuccess, updateSuccess]);

  return (
    <div>
      {/* <Title level={3}>{translate("upload_excel_training_resources")}</Title> */}
      <Title level={3}>{translate("upload_excel")}</Title>
      <Text>{translate("fill_in_the_details_and_upload_a_excel_file")}</Text>
      <Form
        form={form}
        layout="vertical"
        name="upload-excel-form"
        onFinish={onFinish}
        style={{ marginTop: "20px" }}
      >
        <Form.Item
          label="Title"
          name="title"
          rules={[{ required: true, message: "Please enter the title!" }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Description"
          name="description"
          rules={[{ required: true, message: "Please enter the description!" }]}
        >
          <Input.TextArea />
        </Form.Item>

        <Form.Item
          label="Select Upload Type"
          name="uploadType"
          //   rules={[{ required: true, message: "Please select upload type!" }]}
        >
          <Input.Group compact>
            <Form.Item noStyle>
              <Button
                disabled={!!record}
                onClick={() => setUploadType("upload")}
                type={uploadType === "upload" ? "primary" : "default"}
              >
                {translate("upload_excel")}
              </Button>
            </Form.Item>
            <Form.Item noStyle>
              <Button
                disabled={!!record}
                onClick={() => setUploadType("url")}
                type={uploadType === "url" ? "primary" : "default"}
              >
                {translate("insert_excel_url")}
              </Button>
            </Form.Item>
          </Input.Group>
        </Form.Item>

        {uploadType === "upload" && (
          <Form.Item
            label="Upload Excel"
            name="excel"
            valuePropName="fileList"
            getValueFromEvent={(e) => e && e.fileList}
            rules={[
              { required: true, message: "Please upload an Excel file!" },
            ]}
          >
            <Upload
              beforeUpload={beforeUpload}
              onChange={onUploadChange}
              maxCount={1}
              accept=".xlsx, .xls"
              listType="picture"
              size="large"
              showUploadList={{
                showRemoveIcon: true,
              }}
            >
              <Button disabled={!!record} icon={<UploadOutlined />}>
                {translate("select_excel")}
              </Button>
            </Upload>
          </Form.Item>
        )}

        {uploadType === "url" && (
          <Form.Item
            label="Excel URL"
            name="excelUrl"
            rules={[
              {
                required: record ? false : true,
                message: "Please enter a valid Excel URL!",
                type: "url",
              },
            ]}
          >
            <Input placeholder="Enter Excel URL" />
          </Form.Item>
        )}

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isLoading}>
            {translate("Submit")}
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default UploadExcelPage;
