import { useState, useEffect, useRef } from "react";
import {
  DatePicker,
  Button,
  Input,
  Form,
  Upload,
  Select,
  InputNumber,
  Switch,
  Tag,
  message,
  TimePicker,
} from "antd";
import { useForm } from "antd/lib/form/Form"; // Importing the specific hook
import {
  CloseOutlined,
  CheckOutlined,
  UploadOutlined,
  PhoneOutlined,
  DownOutlined,
} from "@ant-design/icons";
import useLanguage from "@/locale/useLanguage";
import { useMoney, useDate } from "@/settings";
import AutoCompleteAsync from "@/components/AutoCompleteAsync";
import SelectAsync from "@/components/SelectAsync";
import { generate as uniqueId } from "shortid";
import { countryList } from "@/utils/countryList";
import UploadImg from "@/modules/ProfileModule/components/UploadImg";
import TrainingResourcesButton from "@/components/TrainingResourcesButton";
import { validatePhoneNumber, disabledDate } from "@/utils/helpers";
import SelectAsyncFetch from "@/components/SelectAsyncFetch";
import dayjs from "dayjs";
import QuestionContent from "@/components/QuizQuestionContent";
import SelectForDynamicFetchOption from "@/components/SelectForDynamicFetchOption";
import SelectForDynamicTimeZoneOption from "@/components/SelectForDynamicTimeZoneOption";
import MeetingModeField from "@/components/MeetingModeField";
import CapstoneQuestionContent from "@/components/CapstoneQuestionContent";
import FeedbackQuestionContent from "@/components/FeedbackQuestionContent";
import TinyMc from "@/components/TinyMc";

export default function DynamicForm({ fields, isUpdateForm = false }) {
  const [feedback, setFeedback] = useState();

  return (
    <>
      {Object.keys(fields).map((key) => {
        let field = fields[key];

        if (
          (isUpdateForm && !field.disableForUpdate) ||
          !field.disableForForm
        ) {
          field.name = key;
          if (!field.label) field.label = key;

          if (field.hasFeedback)
            return (
              <FormElement setFeedback={setFeedback} key={key} field={field} />
            );
          else if (feedback && field.feedback) {
            if (feedback == field.feedback)
              return <FormElement key={key} field={field} />;
          } else {
            return <FormElement key={key} field={field} />;
          }
        }
      })}
    </>
  );
}

function FormElement({ field, setFeedback }) {
  const translate = useLanguage();
  const money = useMoney();
  const { dateFormat, dateYearFormat } = useDate();
  const { TextArea } = Input;
  const validateCharacters = (_, value) => {
    // Regular expression to match only alphabets (a-z, A-Z)
    const regex = /^[A-Za-z]+$/;

    if (!regex.test(value)) {
      return Promise.reject("Please enter only characters");
    }

    return Promise.resolve();
  };

  const validateEmail = (_, value) => {
    const emailRegex =
      /^(?=[A-Za-z])([A-Za-z0-9._%+-]+)@(?=.*[A-Za-z])[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

    if (!emailRegex.test(value)) {
      return Promise.reject("Email is not all numbers");
    }

    return Promise.resolve();
  };
  const validateTitle = (_, value) => {
    const titleRegex = /^(?=.*[A-Za-z])[\w\s.,'-]+$/;

    if (!titleRegex.test(value)) {
      return Promise.reject("Not all numbers allowed");
    }

    return Promise.resolve();
  };

  const compunedComponent = {
    string: (
      <Form.Item
        name={field.name}
        rules={[
          {
            min: field.minLength,
            message: `Minimum ${field.minLength} characters`,
          },
          {
            max: field.maxLength,
            message: `Maximum ${field.maxLength} characters`,
          },
          {
            validator: validateTitle,
          },
        ]}
      >
        <Input autoComplete="off" placeholder={field.placeholder} />
      </Form.Item>
    ),
    Namestring: (
      <Form.Item
        name={field.name}
        rules={[
          {
            validator: validateCharacters,
          },
        ]}
      >
        <Input autoComplete="off" placeholder={field.placeholder} />
      </Form.Item>
    ),
    url: (
      <Input
        addonBefore="http://"
        autoComplete="off"
        placeholder="www.website.com"
      />
    ),
    textarea: (
      <Form.Item
        name={field.name}
        rules={[
          {
            min: field.minLength,
            message: `Minimum ${field.minLength} characters`,
          },
          {
            max: field.maxLength,
            message: `Maximum ${field.maxLength} characters`,
          },
          {
            validator: validateTitle,
          },
        ]}
      >
        <TextArea rows={4} />
      </Form.Item>
    ),
    // email: <Input autoComplete="off" placeholder="email@gmail.com" />,

    email: (
      <Form.Item
        name={field.name}
        rules={[
          {
            required: true,
            message: "Please input your email!",
          },
          {
            validator: validateEmail,
          },
        ]}
      >
        <Input autoComplete="off" placeholder="email@gmail.com" />
      </Form.Item>
    ),
    number: <InputNumber style={{ width: "100%" }} />,

    inpnumber: (
      <InputNumber min={1} max={100} type="number" style={{ width: "100%" }} />
    ),

    // phone: <Input style={{ width: "100%" }} placeholder="12345 67890" />,
    phone: (
      <Form.Item
        name="mobile"
        rules={[
          {
            required: true,
          },
          {
            type: "string",
          },
          {
            pattern: validatePhoneNumber,
            message: "Please enter a valid phone number",
          },
        ]}
      >
        <Input
          prefix={<PhoneOutlined className="site-form-item-icon" />}
          placeholder="9999988888"
          type="string"
          size="default"
        />
      </Form.Item>
    ),
    boolean: (
      <Switch
        checkedChildren={<CheckOutlined />}
        unCheckedChildren={<CloseOutlined />}
      />
    ),
    date: (
      <DatePicker
        className="date-picker"
        placeholder={translate("select_date")}
        format={dateFormat}
        size="default"
        disabledDate={disabledDate}
      />
    ),

    time: <TimePicker format="HH:mm" className="date-picker" size="default" />,
    imageupload: (
      <Upload>
        <Button icon={<UploadOutlined />}>
          {translate("upload_thumbnail")}
        </Button>
      </Upload>
    ),

    customImageUpload: <UploadImg fieldName={field} />,
    customButton: <TrainingResourcesButton fieldName={field} />,
    customquestionbutton: <QuestionContent fieldName={field} />,
    customcapstonequestionbutton: <CapstoneQuestionContent fieldName={field} />,
    feedbackquestionbutton: <FeedbackQuestionContent fieldName={field} />,
    meetingMode: <MeetingModeField fieldName={field} />,
    select: (
      <Select
        defaultValue={field.defaultValue}
        placeholder={field.placeholder}
        style={{
          width: "100%",
        }}
      >
        {field.options?.map((option) => {
          return (
            <Select.Option key={`${uniqueId()}`} value={option.value}>
              <Tag bordered={false}>{option.label}</Tag>
            </Select.Option>
          );
        })}
      </Select>
    ),
    selectMultiple: (
      <Select
        defaultValue={field.defaultValue}
        mode={field.mode}
        disabled={field.disabled}
        style={{
          width: "100%",
        }}
        size="default"
      >
        {field.options?.map((option) => {
          return (
            <Select.Option key={`${uniqueId()}`} value={option.value}>
              {option.label}
            </Select.Option>
          );
        })}
      </Select>
    ),
    initialInput: (
      <Input autoComplete="off" defaultValue={field.defaultValue} />
    ),
    selectWithTranslation: (
      <Select
        defaultValue={field.defaultValue}
        style={{
          width: "100%",
        }}
      >
        {field.options?.map((option) => {
          return (
            <Select.Option key={`${uniqueId()}`} value={option.value}>
              <Tag bordered={false} color={option.color}>
                {translate(option.label)}
              </Tag>
            </Select.Option>
          );
        })}
      </Select>
    ),
    selectwithfeedback: (
      <Select
        onChange={(value) => setFeedback(value)}
        defaultValue={field.defaultValue}
        style={{
          width: "100%",
        }}
        placeholder
      >
        {field.options?.map((option) => (
          <Select.Option key={`${uniqueId()}`} value={option.value}>
            {translate(option.label)}
          </Select.Option>
        ))}
      </Select>
    ),
    color: (
      <Select
        defaultValue={field.defaultValue}
        style={{
          width: "100%",
        }}
      >
        {field.options?.map((option) => {
          return (
            <Select.Option key={`${uniqueId()}`} value={option.value}>
              <Tag bordered={false} color={option.color}>
                {option.label}
              </Tag>
            </Select.Option>
          );
        })}
      </Select>
    ),
    minutes: (
      <TimePicker
        format="mm"
        placeholder="Select Minutes"
        showNow={false} // Optional: hide the "Now" button
        use12Hours={false} // Set to false to allow selecting only minutes
        style={{ width: "20%" }}
      />
    ),

    tag: (
      <Select
        defaultValue={field.defaultValue}
        style={{
          width: "100%",
        }}
      >
        {field.options?.map((option) => (
          <Select.Option key={`${uniqueId()}`} value={option.value}>
            <Tag bordered={false} color={option.color}>
              {translate(option.label)}
            </Tag>
          </Select.Option>
        ))}
      </Select>
    ),
    array: (
      <Select
        mode={"multiple"}
        defaultValue={field.defaultValue}
        style={{
          width: "100%",
        }}
      >
        {field.options?.map((option) => (
          <Select.Option key={`${uniqueId()}`} value={option.value}>
            {option.label}
          </Select.Option>
        ))}
      </Select>
    ),
    country: (
      <Select
        showSearch
        optionFilterProp="children"
        filterOption={(input, option) =>
          option.label.toLowerCase().includes(input.toLowerCase())
        }
        filterSort={(optionA, optionB) =>
          optionA.label.toLowerCase().localeCompare(optionB.label.toLowerCase())
        }
        style={{
          width: "100%",
        }}
      >
        {countryList.map((country) => (
          <Select.Option
            key={country.code}
            value={country.dial_code}
            label={country.name}
          >
            {country.flag && country.flag + " "}
            {country.name} ({country.dial_code})
          </Select.Option>
        ))}
      </Select>
    ),
    async: (
      <SelectAsync
        entity={field.entity}
        displayLabels={field.displayLabels}
        outputValue={field.outputValue}
        loadDefault={field.loadDefault}
        withRedirect={field.withRedirect}
        urlToRedirect={field.urlToRedirect}
        redirectLabel={field.redirectLabel}
        asyncOptions={field.asyncOptions}
      ></SelectAsync>
    ),
    asyncSelect: (
      <SelectAsyncFetch
        mode={field?.mode}
        entity={field.entity}
        displayLabels={field.displayLabels}
        outputValue={field.outputValue}
        loadDefault={field.loadDefault}
        withRedirect={field.withRedirect}
        urlToRedirect={field.urlToRedirect}
        redirectLabel={field.redirectLabel}
        asyncOptions={field.asyncOptions}
        responseInner={field.responseInner}
        placeholder={field.placeholder}
      ></SelectAsyncFetch>
    ),
    selectForDynamicFetch: (
      <SelectForDynamicFetchOption
        mode={field?.mode}
        entity={field.entity}
        displayLabels={field.displayLabels}
        outputValue={field.outputValue}
        loadDefault={field.loadDefault}
        withRedirect={field.withRedirect}
        urlToRedirect={field.urlToRedirect}
        redirectLabel={field.redirectLabel}
        asyncOptions={field.asyncOptions}
        responseInner={field.responseInner}
        placeholder={field.placeholder}
        dropdownFor={field.dropdownFor}
      ></SelectForDynamicFetchOption>
    ),
    selectForDynamicTimeZoneOption: (
      <SelectForDynamicTimeZoneOption
        mode={field?.mode}
        entity={field.entity}
        displayLabels={field.displayLabels}
        outputValue={field.outputValue}
        loadDefault={field.loadDefault}
        withRedirect={field.withRedirect}
        urlToRedirect={field.urlToRedirect}
        redirectLabel={field.redirectLabel}
        asyncOptions={field.asyncOptions}
        responseInner={field.responseInner}
        placeholder={field.placeholder}
        fieldName={field}
      ></SelectForDynamicTimeZoneOption>
    ),
    search: (
      <AutoCompleteAsync
        entity={field.entity}
        displayLabels={field.displayLabels}
        searchFields={field.searchFields}
        outputValue={field.outputValue}
      ></AutoCompleteAsync>
    ),
    currency: (
      <InputNumber
        className="moneyInput"
        min={0}
        controls={false}
        addonAfter={
          money.currency_position === "after"
            ? money.currency_symbol
            : undefined
        }
        addonBefore={
          money.currency_position === "before"
            ? money.currency_symbol
            : undefined
        }
      />
    ),

    dialCodeWithCountry: (
      <>
        <Select
          size="default"
          showSearch
          optionFilterProp="children"
          filterOption={(input, option) =>
            option.label.toLowerCase().includes(input.toLowerCase())
          }
          filterSort={(optionA, optionB) =>
            optionA.label
              .toLowerCase()
              .localeCompare(optionB.label.toLowerCase())
          }
          style={{
            width: "100%",
          }}
        >
          {countryList.map((country) => (
            <Select.Option
              key={country.code}
              value={country.dial_code}
              label={country.name}
            >
              {country.flag && country.flag + " "}( {country.name}{" "}
              {country.dial_code} )
            </Select.Option>
          ))}
        </Select>
      </>
    ),
    countryCode: (
      <>
        <Select
          size="default"
          showSearch
          optionFilterProp="children"
          filterOption={(input, option) =>
            option.label.toLowerCase().includes(input.toLowerCase())
          }
          filterSort={(optionA, optionB) =>
            optionA.label
              .toLowerCase()
              .localeCompare(optionB.label.toLowerCase())
          }
          style={{
            width: "100%",
          }}
        >
          {countryList.map((country) => (
            <Select.Option
              key={country.code}
              value={country.code}
              label={country.name}
            >
              {country.flag && country.flag + " "}( {country.name}{" "}
              {country.code} )
            </Select.Option>
          ))}
        </Select>
      </>
    ),
    tinymce: <TinyMc fieldName={field} />,
  };

  const filedType = {
    string: "string",
    textarea: "string",
    number: "number",
    phone: "string",
    array: "array",
    //boolean: 'boolean',
    // method: 'method',
    // regexp: 'regexp',
    // integer: 'integer',
    // float: 'float',
    // object: 'object',
    // enum: 'enum',
    // date: 'date',
    url: "url",
    website: "url",
    email: "email",
  };

  const renderComponent =
    compunedComponent[field.type] ?? compunedComponent["string"];
  return (
    <Form.Item
      label={translate(field.label)}
      name={field.name}
      rules={[
        {
          required: field.required || false,
          type: filedType[field.type] ?? "any",
        },
      ]}
      initialValue={field.defaultValue ? field.defaultValue : ""}
      valuePropName={field.type === "boolean" ? "checked" : "value"}
    >
      {renderComponent}
    </Form.Item>
  );
}
