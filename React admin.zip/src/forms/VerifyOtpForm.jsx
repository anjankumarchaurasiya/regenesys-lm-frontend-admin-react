import React, { useRef } from "react";
import { Form, Input, Row, Col, Space } from "antd";
import useLanguage from "@/locale/useLanguage";

const VerifyOtpForm = ({ onOtpChange }) => {
  const translate = useLanguage();
  const otpInputs = Array.from({ length: 6 }, () => useRef(null));

  const handleOtpChange = (index, value) => {
    if (/^\d*$/.test(value)) {
      onOtpChange(index, value);

      if (value !== "" && index < 5 && /^\d$/.test(value)) {
        otpInputs[index + 1].current.focus();
      }

      if (value === "" && index > 0) {
        otpInputs[index - 1].current.focus();
      }
    }
  };

  return (
    <Form.Item name="otp" className="verify-otp-form-item">
      <Row>
        <Col xs={24} sm={24} md={24} lg={24}>
          <Space style={{ display: "flex" }}>
            {otpInputs.map((inputRef, index) => (
              <Input
                key={index}
                ref={inputRef}
                id={`otpInput-${index}`}
                type="text"
                maxLength="1"
                placeholder="0"
                onChange={(e) => handleOtpChange(index, e.target.value)}
              />
            ))}
          </Space>
        </Col>
      </Row>
    </Form.Item>
  );
};

export default VerifyOtpForm;
