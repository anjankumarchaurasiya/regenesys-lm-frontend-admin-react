import { React, useState } from "react";
import { Form, Input, Checkbox, Select } from "antd";
import { PhoneOutlined } from "@ant-design/icons";
import { validatePhoneNumber } from "@/utils/helpers";
import useLanguage from "@/locale/useLanguage";
import { countryList } from "@/utils/countryList";

export default function LoginWithMobile() {
  const translate = useLanguage();
  const initialCountryCode = "+91";

  return (
    <>
      <Form.Item
        name="dialCode"
        label={translate("Country")}
        initialValue={initialCountryCode}
        rules={[
          {
            required: true,
            message: "Please select a country",
          },
        ]}
      >
        <Select
          size="large"
          showSearch
          optionFilterProp="children"
          filterOption={(input, option) =>
            option.label.toLowerCase().includes(input.toLowerCase())
          }
          filterSort={(optionA, optionB) =>
            optionA.label
              .toLowerCase()
              .localeCompare(optionB.label.toLowerCase())
          }
          style={{
            width: "100%",
          }}
        >
          {countryList.map((country) => (
            <Select.Option
              key={country.code}
              value={country.dial_code}
              label={country.name}
            >
              {country.flag && country.flag + " "}
              {country.name} ({country.dial_code})
            </Select.Option>
          ))}
        </Select>
      </Form.Item>
      <Form.Item
        label={translate("phone")}
        name="mobile"
        rules={[
          {
            required: true,
          },
          {
            type: "string",
          },
          {
            pattern: validatePhoneNumber,
            message: "Please enter a valid phone number",
          },
        ]}
      >
        <Input
          prefix={<PhoneOutlined className="site-form-item-icon" />}
          placeholder="12345 67890"
          type="string"
          size="large"
        />
      </Form.Item>
    </>
  );
}
