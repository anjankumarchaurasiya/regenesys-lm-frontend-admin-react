import React, { useState, useEffect } from "react";
import { Form, Input, Button, Typography, Upload, message } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import useLanguage from "@/locale/useLanguage";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import {
  selectCreatedItem,
  selectUpdatedItem,
} from "@/redux/adavancedCrud/selectors";

import { useSelector, useDispatch } from "react-redux";

const { Title, Text } = Typography;
const UploadPdfPage = ({ onComplete, record, entityName }) => {
  const dispatch = useDispatch();

  const translate = useLanguage();

  const { isLoading, isSuccess } = useSelector(selectCreatedItem);
  const { isSuccess: updateSuccess } = useSelector(selectUpdatedItem);

  const [uploadType, setUploadType] = useState("upload");
  const [fileList, setFileList] = useState([]);
  const [content, setContent] = useState({});
  const titleErrorMessage = translate("title_can_only_be_Aplha_Numeric");

  const descriptionErrorMessage = translate(
    "description_can_only_be_Aplha_Numeric"
  );
  const pdfErrorMessage = translate("you_can_only_upload_pdf_files");

  const [form] = Form.useForm();

  const onFinish = (values) => {
    // Handle form submission here
    const isNumericTitle = /^[0-9]+$/.test(values?.title);
    const isNumericDescription = /^[0-9]+$/.test(values?.description);

    if (isNumericTitle) {
      message.error(titleErrorMessage);
    }
    if (isNumericDescription) {
      message.error(descriptionErrorMessage);
    } else {
      const uploadedFileName =
        values?.pdf != undefined ? values.pdf[0].name : values.pdfUrl;
      const updatedTitleName = values?.title;
      const updatedDescription = values?.description;
      setContent({ uploadedFileName, updatedTitleName, updatedDescription });

      const formData = new FormData();
      const fields = {
        title: values.title,
        description: values.description,
        entityName: entityName === "QUIZQUESTION" ? entityName : "TOPIC",
        entityType: "PDF",
        type: "PDF",
        pdfUrl: values.pdfUrl,
      };

      Object.entries(fields).forEach(([key, value]) =>
        formData.append(key, value)
      );

      if (values.pdfUrl === undefined) {
        const file = values.pdf[0].originFileObj; // Get the file object
        formData.append("file", file); // Append the file object to the FormData
      }

      const listEntity = "content";
      const updateEntity = "content";

      if (record === null || record === undefined) {
        dispatch(
          advancedCrud.create({
            listEntity,
            jsonData: formData,
            withUpload: true,
          })
        );
      } else {
        dispatch(
          advancedCrud.update({
            updateEntity,
            dataObject: formData,
            id: record.id,
            withUpload: false,
          })
        );
      }
    }

    // if (!record) {
    //   onComplete(uploadedFileName);
    // } else {
    //   onComplete(updatedTitleName, updatedDescription, record);
    // }
    // form.resetFields();
  };

  const onUploadChange = (info) => {
    if (info.file.status === "done") {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === "error") {
      message.error(`${info.file.name} file upload failed.`);
    }
  };

  const beforeUpload = (file) => {
    // Add custom validation logic for the PDF file type
    const isPDF = file.type === "application/pdf";
    if (!isPDF) {
      message.error(pdfErrorMessage);
      return false;
    }

    // Update file list based on conditions
    setFileList([file]);
    // Prevent automatic upload
    return false;
  };

  const onRemove = () => {
    setFileList([]);
  };

  useEffect(() => {
    if (record) {
      form.setFieldsValue({
        title: record.title,
        description: record.description,
      });
    }
  }, [record, form]);

  useEffect(() => {
    if (isSuccess || updateSuccess) {
      if (!record) {
        onComplete(content.uploadedFileName);
        form.resetFields();
        dispatch(advancedCrud.resetAction({ actionType: "create" }));
      } else {
        onComplete(
          content.updatedTitleName,
          content.updatedDescription,
          record
        );
        form.resetFields();
        dispatch(advancedCrud.resetAction({ actionType: "update" }));
      }
    }
  }, [isSuccess, updateSuccess]);

  return (
    <div>
      {/* <Title level={3}>{translate("upload_pdf_training_resources")}</Title> */}
      <Title level={3}>{translate("upload_pdf")}</Title>
      <Text>{translate("fill_in_the_details_and_upload_a_pdf_file")}</Text>

      <Form
        form={form}
        layout="vertical"
        name="upload-pdf-form"
        onFinish={onFinish}
        style={{ marginTop: "20px" }}
      >
        <Form.Item
          label="Title"
          name="title"
          rules={[{ required: true, message: "Please enter the title!" }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Description"
          name="description"
          rules={[{ required: true, message: "Please enter the description!" }]}
        >
          <Input.TextArea />
        </Form.Item>

        <Form.Item
          label="Select Upload Type"
          name="uploadType"
          //   rules={[{ required: true, message: "Please select upload type!" }]}
        >
          <Input.Group compact>
            <Form.Item noStyle>
              <Button
                disabled={!!record}
                onClick={() => setUploadType("upload")}
                type={uploadType === "upload" ? "primary" : "default"}
              >
                {translate("upload_pdf")}
              </Button>
            </Form.Item>
            <Form.Item noStyle>
              <Button
                disabled={!!record}
                onClick={() => setUploadType("url")}
                type={uploadType === "url" ? "primary" : "default"}
              >
                {translate("insert_pdf_url")}
              </Button>
            </Form.Item>
          </Input.Group>
        </Form.Item>

        {uploadType === "upload" && (
          <Form.Item
            label="Upload PDF"
            name="pdf"
            valuePropName="fileList"
            getValueFromEvent={(e) => e && e.fileList}
            rules={[{ required: true, message: "Please upload a PDF file!" }]}
          >
            <Upload
              fileList={fileList}
              beforeUpload={beforeUpload}
              onChange={onUploadChange}
              onRemove={onRemove}
              maxCount={1}
              listType="picture"
              size="large"
              accept=".pdf"
              showUploadList={{
                showRemoveIcon: true,
              }}
            >
              <Button disabled={!!record} icon={<UploadOutlined />}>
                {translate("select_pdf")}
              </Button>
            </Upload>
          </Form.Item>
        )}
        {uploadType === "url" && (
          <Form.Item
            label="PDF URL"
            name="pdfUrl"
            rules={[
              {
                required: true,
                message: "Please enter a valid PDF URL!",
                type: "url",
              },
            ]}
          >
            <Input placeholder="Enter PDF URL" />
          </Form.Item>
        )}

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isLoading}>
            {translate("Submit")}
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default UploadPdfPage;
