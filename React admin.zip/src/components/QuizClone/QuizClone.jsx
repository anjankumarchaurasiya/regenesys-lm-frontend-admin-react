import React, { useEffect, useState } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  InputNumber,
  Row,
  Col,
  Card,
  Modal,
  Space,
  Tag,
  TimePicker,
} from "antd";
import { DeleteOutlined, EditOutlined, PlusOutlined } from "@ant-design/icons";
import QuestionContent from "../QuizQuestionContent/index";
import AddQuestionForm from "../QuizQuestionContent/AddQuestionForm";
import {
  selectCurrentItem,
  selectListItems,
  selectCurrentItem as currItem,
} from "@/redux/crud/selectors";
import { useDispatch, useSelector } from "react-redux";
import dayjs from "dayjs";
import { crud } from "@/redux/crud/actions";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import {
  selectListItems as categoryItem,
  selectCurrentItem as questionItem,
} from "@/redux/adavancedCrud/selectors";
import { convertMinutesFormat } from "@/utils/helpers";
const { Option } = Select;
const { TextArea } = Input;

const QuizClone = ({ handleSecondModalCancel }) => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [editQuestionIndex, setEditQuestionIndex] = useState(null);
  const [selectOptions, setOptions] = useState([]);
  const {
    result: { items },
    isSuccess: isCategorySuccess,
  } = useSelector(categoryItem);
  const [form] = Form.useForm();
  const dispatch = useDispatch();
  const {
    result: listResult,
    isLoading: listIsLoading,
    isSuccess,
  } = useSelector(selectListItems);
  const { result: questionsItem } = useSelector(questionItem);
  const showModal = (index = null) => {
    setIsModalVisible(true);
    setEditQuestionIndex(index);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setEditQuestionIndex(null);
  };

  const handleAddQuestion = (formData) => {
    if (editQuestionIndex !== null) {
      const updatedQuestions = [...questions];
      updatedQuestions[editQuestionIndex] = { ...formData.data };
      setQuestions(updatedQuestions);
    } else {
      setQuestions([...questions, formData.data]);
    }

    setIsModalVisible(false);
    setEditQuestionIndex(null);
  };

  const handleDeleteQuestion = (index) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    setQuestions(updatedQuestions);
  };

  const onFinish = (fieldsValue) => {
    // Handle test creation here
    if (fieldsValue.duration) {
      const minutes = convertMinutesFormat(fieldsValue["duration"]);
      fieldsValue["duration"] = minutes;
    }

    const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
      acc[key] =
        typeof fieldsValue[key] === "string"
          ? fieldsValue[key].trim()
          : fieldsValue[key];
      return acc;
    }, {});

    const data = {};
    data["quizData"] = trimmedValues;
    data["questionData"] = questions?.map((question) => {
      if (question?.content?.length > 0)
        return {
          question: question.question,
          categoryId: question["category"]
            ? question.category.id
            : question.categoryId,
          point: question.quiz_question
            ? question.quiz_question.points
            : question.point,
          question_type: question["question_type"]
            ? question["question_type"]
            : "MCQ",
          options: question.question_options.map((option, index) => ({
            option: option.option,
            isCorrectOption: option.isCorrectOption,
            description: option.isCorrectOption ? option?.description : "null",
            order: String.fromCharCode(65 + index),
          })),
          content: question.content,
        };
      return {
        question: question.question,
        categoryId: question["category"]
          ? question.category.id
          : question.categoryId,
        point: question.quiz_question
          ? question.quiz_question.points
          : question.point,
        question_type: question["question_type"]
          ? question["question_type"]
          : "MCQ",
        options: question.question_options.map((option, index) => ({
          option: option.option,
          isCorrectOption: option.isCorrectOption,
          description: option.isCorrectOption ? option?.description : "null",
          order: String.fromCharCode(65 + index),
        })),
      };
    });
    data["type"] = "EXAM";

    const entities = {
      listEntity: "/quiz/filter/list",
      createEntity: "/quiz",
    };

    const customizeConfigParameters = {
      responseInnerObj: "quiz",
      params: "recordStatus=true",
    };
    dispatch(
      crud.create({
        listEntity: entities.listEntity,
        createEntity: entities.createEntity,
        jsonData: data,
        withUpload: false,
        customizeConfigParameters,
      })
    ).then((response) => {
      handleSecondModalCancel();
    });
  };

  useEffect(() => {
    isCategorySuccess && setOptions(items);
  }, [isSuccess]);

  useEffect(() => {
    const listEntity = "/category/filter/list";
    const options = {
      type: "quiz",
    };
    const customizeConfigParameters = {
      responseInnerObj: "category",
      params: "recordStatus=true",
    };

    dispatch(
      advancedCrud.list({ listEntity, options, customizeConfigParameters })
    );
  }, []);

  useEffect(() => {
    if (isSuccess) {
      setQuestions(questionsItem.questions);
      delete questionsItem.questions;
      let newValues = { ...questionsItem };
      if (newValues.created) {
        newValues = {
          ...newValues,
          created: dayjs(newValues["created"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.updated) {
        newValues = {
          ...newValues,
          updated: dayjs(newValues["updated"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.duration) {
        newValues = {
          ...newValues,
          duration: dayjs(newValues["duration"], "mm"),
        };
      }
      form.resetFields();
      form.setFieldsValue(newValues);
    }
  }, [isSuccess]);
  // useEffect(() => {
  //   () => form.resetFields();
  // }, []);

  const handleSelectChange = (newValue) => {
    if (form && form.setFieldsValue) {
      form.setFieldsValue({ ["categoryId"]: newValue });
    }
  };

  return (
    <Form layout="vertical" form={form} onFinish={onFinish}>
      <h2>Create Test</h2>

      <Form.Item
        label="Select Category"
        name="categoryId"
        rules={[{ required: true, message: "Please select a category" }]}
      >
        <Select
          value={"fgyui"}
          onChange={handleSelectChange}
          disabled={questionsItem?.category?.name == "EXAM"}
        >
          {items.length > 0 &&
            items.map((item) => (
              <Option value={item.id} key={item.id}>
                {item.name}
              </Option>
            ))}
        </Select>
      </Form.Item>

      <Form.Item
        label="Quiz Title"
        name="title"
        rules={[{ required: true, message: "Please enter the quiz title" }]}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Quiz Description"
        name="description"
        rules={[
          { required: true, message: "Please enter the quiz description" },
        ]}
      >
        <TextArea />
      </Form.Item>

      <Form.Item
        label="Duration (minutes)"
        name="duration"
        rules={[{ required: true, message: "Please enter the duration" }]}
      >
        <TimePicker
          format="mm"
          placeholder="Select Minutes"
          showNow={false} // Optional: hide the "Now" button
          use12Hours={false} // Set to false to allow selecting only minutes
          style={{ width: "100%" }}
        />
        {/* <InputNumber min={1} /> */}
      </Form.Item>

      <Form.Item label="Questions">
        <Row gutter={16}>
          <Col span={12}>
            {questions?.length > 0 &&
              questions?.map((question, index) => (
                <Card key={index} className="small-card quiz-card" size="large">
                  <p>
                    {`Question - ${index + 1}: ${question.question}`}
                    <Space className="ml-5 p-1">
                      <DeleteOutlined
                        className="delete-icon"
                        onClick={() => handleDeleteQuestion(index)}
                      />
                      <EditOutlined onClick={() => showModal(index)} />
                    </Space>
                  </p>
                </Card>
              ))}
          </Col>
          <Col span={24}>
            <Button
              type="dashed"
              className="addquestion-button"
              icon={<PlusOutlined />}
              onClick={() => showModal()}
            >
              Add Question
            </Button>
          </Col>
        </Row>
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit">
          Save
        </Button>
      </Form.Item>

      <Modal
        title={editQuestionIndex !== null ? "Edit Question" : "Add Question"}
        visible={isModalVisible}
        onCancel={handleCancel}
        footer={null}
      >
        <AddQuestionForm
          onAddQuestion={handleAddQuestion}
          onCancel={handleCancel}
          editData={
            editQuestionIndex !== null ? questions[editQuestionIndex] : null
          }
          mediaEditFlag={false}
        />
      </Modal>
    </Form>
  );
};

export default QuizClone;
