import React, { useState } from "react";
import { Card, Row, Col, Button, Modal, Space } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import AddQuestionForm from "./AddQuestionForm";

import { crud } from "@/redux/crud/actions";

import { useDispatch } from "react-redux";

const FeedbackQuestionContent = ({ fieldName }) => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [editQuestionIndex, setEditQuestionIndex] = useState(null);
  const dispatch = useDispatch();

  const showModal = (index = null) => {
    setIsModalVisible(true);
    setEditQuestionIndex(index);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setEditQuestionIndex(null);
  };

  const handleAddQuestion = (formData) => {
    if (editQuestionIndex !== null) {
      // If editing an existing question, update the questions array
      const updatedQuestions = [...questions];
      updatedQuestions[editQuestionIndex] = { ...formData.data };
      setQuestions(updatedQuestions);
    } else {
      // If adding a new question, simply add it to the questions array
      setQuestions([...questions, { ...formData.data }]);
    }

    setIsModalVisible(false);
    setEditQuestionIndex(null);
  };

  const handleDeleteQuestion = (index) => {
    setQuestions((prevQuestions) => {
      const updatedQuestions = [...prevQuestions];
      updatedQuestions.splice(index, 1);
      dispatch(
        crud.currentItem({
          data: { questions: updatedQuestions }, // Pass the updated value to Redux action
        })
      );
      return updatedQuestions; // Return the updated value to update the state
    });
  };

  return (
    <>
      <Row gutter={16}>
        <Col span={12}>
          {questions.map((question, index) => (
            <Card key={index} className="small-card quiz-card " size="large">
              <p>
                {`Question - ${index + 1}: ${question.question}`}
                <Space className="ml-5 p-1">
                  <DeleteOutlined
                    className="delete-icon"
                    onClick={() => handleDeleteQuestion(index)}
                  />
                  <EditOutlined onClick={() => showModal(index)} />
                </Space>
              </p>
            </Card>
          ))}
        </Col>
        <Col span={24}>
          <Button
            type="primary"
            ghost
            className="addquestion-button"
            onClick={() => showModal()}
          >
            Add Question
          </Button>
        </Col>
      </Row>

      <Modal
        title={editQuestionIndex !== null ? "Edit Question" : "Add Question"}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={null} // Remove footer to customize buttons within the form
      >
        <AddQuestionForm
          onAddQuestion={handleAddQuestion}
          onCancel={handleCancel}
          editData={
            editQuestionIndex !== null ? questions[editQuestionIndex] : null
          }
          editQuestionIndex={
            editQuestionIndex !== null ? editQuestionIndex : null
          }
        />
      </Modal>
    </>
  );
};

export default FeedbackQuestionContent;
