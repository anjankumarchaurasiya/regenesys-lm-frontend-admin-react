import React, { useState, useEffect } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  InputNumber,
  message,
  Space,
  Tooltip,
  Radio,
} from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import TrainingResourcesButton from "../TrainingResourcesButton";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import {
  selectListItems as listItem,
  selectReadItem,
} from "@/redux/crud/selectors";
import { selectCreatedItem as itemsResource } from "@/redux/adavancedCrud/selectors";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import SelectAsyncFetch from "@/components/SelectAsyncFetch";
import { erp } from "@/redux/erp/actions";
import { selectListItems } from "@/redux/erp/selectors";
import useLanguage from "@/locale/useLanguage";

const { Option } = Select;
const { TextArea } = Input;

const AddQuestionForm = ({
  onAddQuestion,
  onCancel,
  editData,
  mediaEditFlag,
  editQuestionIndex,
}) => {
  const [options, setOptions] = useState([
    { label: "Option 1", value: "", order: "0" },
  ]);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [tempArray, setTempArray] = useState([]);
  const [contentArray, setContentArray] = useState([]);
  const translate = useLanguage();

  const dispatch = useDispatch();
  const handleUploadComplete = (fileName) => {
    setUploadedFiles([...uploadedFiles, fileName]);
  };
  const [form] = Form.useForm();
  const {
    result: { items },
  } = useSelector(selectListItems);

  const [questionData, setQuestionData] = useState({
    questionType: "Rating",
    question: "",
    createAnswer: options.map((option) => ({ ...option, correct: false })),
    comment: "",
  });
  const { result: resourceContent } = useSelector(itemsResource);
  const { current, isLoading: isLoadingValue } = useSelector(selectReadItem);
  const questionErrorMessage = translate("question_can_only_be_Aplha_Numeric");
  const questionSuccessMessage = translate("question_added_successfully");

  const [questionType, setQuestionType] = useState("Rating");

  useEffect(() => {
    if (
      current &&
      typeof current === "object" &&
      current.hasOwnProperty("index")
    ) {
      setTempArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
      setContentArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
    }
  }, [current]);

  useEffect(() => {
    if (editData) {
      const options = editData.question_options.map((option, index) => ({
        label: `Option ${index + 1}`,
        value: option.option,
        correct: option.isCorrectOption,
      }));
      setOptions(options);

      const correctOption = editData.question_options.find(
        (option) => option.isCorrectOption
      );

      setQuestionType(editData.questionType);

      form.setFieldsValue({
        questionType: editData.question_type,
        question: editData.question ?? "",
        points: editData?.quiz_question?.points
          ? editData?.quiz_question?.points
          : editData.point,
        attachMedia: editData?.attachMedia ?? "",
        createAnswer: editData.question_options,
        topic: editData.topic ?? "",
        comment: editData?.comment,
      });
    }
  }, [editData, form]);

  useEffect(() => {
    if (!!editData) {
      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: options.map((option) => ({ ...option, correct: false })),
        question: editData?.question ?? "",
        comment: editData?.comment,
      }));
    }
  }, [editData]);

  useEffect(() => {
    if (options.length > 0 && !!editData) {
      const updatedContentArray = [...contentArray];
      const updatedTempArray = [...tempArray];

      updatedContentArray.push(/* newly uploaded media */);
      updatedTempArray.push(/* corresponding ID */);

      setContentArray(updatedContentArray);
      setTempArray(updatedTempArray);
    }
  }, [options]);

  const onFinish = () => {
    const isNumericQuestion = /^[0-9]+$/.test(questionData.question);
    if (isNumericQuestion) {
      message.error(questionErrorMessage);
    } else {
      message.success(questionSuccessMessage);

      if (onAddQuestion) {
        onAddQuestion({
          data: {
            question: questionData.question,
            questionCategoryId: items.filter(
              (item) => item.name === "FEEDBACK"
            )[0]?.id,
            question_options: questionData.createAnswer.map((item, index) => ({
              option: item.value,
              order: index,
            })),
            questionType: questionType,
            wordLimit: questionData?.comment ? questionData?.comment : "0",
            comment: questionData?.comment,
          },
        });

        dispatch(
          crud.currentItem({
            data: {
              question: questionData.question,

              questionCategoryId: items.filter(
                (item) => item.name === "FEEDBACK"
              )[0]?.id,

              options: questionData.createAnswer.map((item, index) => ({
                option: item.value,
                order: index,
              })),
              wordLimit: questionData?.comment
                ? questionData?.comment?.length
                : "0",
              comment: questionData?.comment,

              questionType: questionType,
              editQuestionIndex:
                editQuestionIndex != null ? editQuestionIndex : -1,
            },
          })
        );
      }

      if (onCancel) {
        onCancel();
      }

      setOptions([{ label: "Option 1", value: "", order: "0" }]);
      setTempArray([]);
      setContentArray([]);
      dispatch(advancedCrud.resetAction({ actionType: "create" }));
      setQuestionType("Rating");
      form.resetFields();
    }
  };

  useEffect(() => {
    if (!editData) {
      form.resetFields();
      setQuestionType("Rating");
      setOptions([{ label: "Option 1", value: "", order: "0" }]);
    }
  }, [editData]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    setQuestionType(value);

    setQuestionData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  useEffect(() => {
    const listEntity = "/category/filter/list";
    const options = {
      type: "question",
    };
    const customizeConfigParameters = {
      responseInnerObj: "category",
      params: "recordStatus=true",
    };

    dispatch(erp.list({ listEntity, options, customizeConfigParameters }));
  }, []);

  return (
    <Form
      form={form}
      layout="vertical"
      name="add-question-form"
      onFinish={onFinish}
    >
      <Form.Item
        label="Question Type"
        name="questionType"
        rules={[{ required: false, message: "Please select a question type" }]}
      >
        <Select
          onChange={(value) =>
            handleInputChange({ target: { name: "questionType", value } })
          }
          defaultValue="Rating"
        >
          <Option value="Rating">Rating</Option>
          <Option value="Text">Text</Option>
        </Select>
      </Form.Item>

      <Form.Item
        label="Question"
        name="question"
        rules={[{ required: true, message: "Please enter a question" }]}
      >
        <TextArea
          onChange={(e) =>
            setQuestionData((prevData) => ({
              ...prevData,
              question: e.target.value,
            }))
          }
        />
      </Form.Item>

      {questionType === "Rating" ? (
        // Existing code...

        <Form.Item
          name="createRating"
          rules={[{ required: false, message: "Answer is Necessary" }]}
        >
          <p>
            <span className="required_mark">* </span>Create Rating
          </p>
          {options.map((option, index) => (
            <div key={index}>
              {" "}
              {/* Wrap each option within a <div> */}
              <Space className="mb-2">
                <div className="option-label">
                  {String.fromCharCode(65 + index)} -
                </div>
                <Input
                  className="ratingInput"
                  size="large"
                  placeholder={`Rating ${index + 1}`}
                  value={option.value}
                  type="number"
                  min={1}
                  max={5}
                  onChange={(e) => {
                    const inputValue = parseInt(e.target.value, 10);
                    if (
                      !isNaN(inputValue) &&
                      inputValue >= 1 &&
                      inputValue <= 5
                    ) {
                      const updatedOptions = [...options];
                      updatedOptions[index].value = inputValue.toString(); // Convert back to string
                      setOptions(updatedOptions);
                      setQuestionData((prevData) => ({
                        ...prevData,
                        createAnswer: updatedOptions.map((opt) =>
                          opt.order === option.order
                            ? { ...opt, value: inputValue.toString() }
                            : opt
                        ),
                      }));
                    }
                  }}
                />
                <DeleteOutlined
                  className="delete-icon"
                  onClick={() => {
                    if (options.length > 1) {
                      const newOptions = options.filter((_, i) => i !== index);
                      setOptions(newOptions);
                      setQuestionData((prevData) => ({
                        ...prevData,
                        createAnswer: newOptions.map((opt) =>
                          opt.order === option.order
                            ? { ...opt, value: "" }
                            : opt
                        ),
                      }));
                    }
                  }}
                />
              </Space>
            </div>
          ))}
          <div>
            <Button
              disabled={options.length >= 5}
              type="dashed"
              onClick={() => {
                if (options.length < 5) {
                  setOptions([
                    ...options,
                    {
                      label: `Option ${options.length + 1}`,
                      value: "",
                      order: options.length,
                    },
                  ]);
                  setQuestionData((prevData) => ({
                    ...prevData,
                    createAnswer: [
                      ...prevData.createAnswer,
                      {
                        label: `Option ${options.length + 1}`,
                        value: "",
                        order: options.length,
                        correct: false,
                      },
                    ],
                  }));
                }
              }}
              icon={<PlusOutlined />}
            >
              More Options
            </Button>
          </div>
        </Form.Item>
      ) : (
        <Form.Item
          label="Limit Comment Character"
          name="comment"
          rules={[{ required: true, message: "Please enter a comment" }]}
        >
          <Input
            onChange={(e) =>
              setQuestionData((prevData) => ({
                ...prevData,
                comment: e.target.value,
              }))
            }
          />
        </Form.Item>
      )}

      <Form.Item>
        <Button type="primary" htmlType="submit">
          Save
        </Button>
      </Form.Item>
    </Form>
  );
};

export default AddQuestionForm;
