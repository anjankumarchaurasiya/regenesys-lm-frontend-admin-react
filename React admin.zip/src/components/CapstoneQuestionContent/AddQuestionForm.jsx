import React, { useState, useEffect } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  InputNumber,
  message,
  Space,
  Tooltip,
  Radio,
} from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import TrainingResourcesButton from "../TrainingResourcesButton";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import {
  selectListItems as listItem,
  selectReadItem,
} from "@/redux/crud/selectors";
import { selectCreatedItem as itemsResource } from "@/redux/adavancedCrud/selectors";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import SelectAsyncFetch from "@/components/SelectAsyncFetch";
import { erp } from "@/redux/erp/actions";
import { selectListItems } from "@/redux/erp/selectors";
import useLanguage from "@/locale/useLanguage";

const { Option } = Select;
const { TextArea } = Input;

const AddQuestionForm = ({
  onAddQuestion,
  onCancel,
  editData,
  mediaEditFlag,
  editQuestionIndex,
}) => {
  const [options, setOptions] = useState([
    { label: "Option 1", value: "", correct: false },
  ]);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [tempArray, setTempArray] = useState([]);
  const [contentArray, setContentArray] = useState([]);
  const translate = useLanguage();

  const questionErrorMessage = translate("question_can_only_be_Aplha_Numeric");
  const questionSuccessMessage = translate("question_added_successfully");

  const dispatch = useDispatch();
  const handleUploadComplete = (fileName) => {
    setUploadedFiles([...uploadedFiles, fileName]);
  };
  const [form] = Form.useForm();
  const {
    result: { items },
  } = useSelector(selectListItems);

  const [questionData, setQuestionData] = useState({
    questionType: "",
    question: "",
    points: 1,
    attachMedia: "",
    createAnswer: options,
    topic: "",
    description: "",
  });
  const { result: resourceContent } = useSelector(itemsResource);
  const { current, isLoading: isLoadingValue } = useSelector(selectReadItem);
  useEffect(() => {
    if (resourceContent?.id) {
      setTempArray((prevTemArray) => [...prevTemArray, resourceContent?.id]);
      setContentArray([...contentArray, resourceContent]);
    }
  }, [resourceContent]);

  useEffect(() => {
    if (
      current &&
      typeof current === "object" &&
      current.hasOwnProperty("index")
    ) {
      setTempArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
      setContentArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
    }
  }, [current]);

  useEffect(() => {
    if (editData) {
      form.setFieldsValue({
        questionType: "MCQ",
        question: editData.question ?? "",
        points: editData?.quiz_question?.points
          ? editData?.quiz_question?.points
          : editData.point,
        attachMedia: editData?.attachMedia ?? "",
        createAnswer: editData.question_options,
        topic: editData.topic ?? "",
      });
    }
  }, [editData, form]);

  useEffect(() => {
    if (!!editData) {
      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: options,
        question: editData?.question ?? "",
        points: editData?.quiz_question?.points
          ? editData?.quiz_question?.points
          : editData.point,
        attachMedia: editData?.attachMedia ?? "",
        topic: editData?.topic ?? "",
      }));
      const contents = editData?.question_content
        ? editData?.question_content
        : editData?.question_contents.map((content) => content.content);
      const contentsIds = editData.content
        ? editData.content
        : editData.question_contents.map((content) => content.content.id);

      setContentArray(contents);
      setTempArray(contentsIds);
    }
  }, [editData]);

  useEffect(() => {
    if (options.length > 0 && !!editData) {
      const updatedContentArray = [...contentArray];
      const updatedTempArray = [...tempArray];

      updatedContentArray.push(/* newly uploaded media */);
      updatedTempArray.push(/* corresponding ID */);

      setContentArray(updatedContentArray);
      setTempArray(updatedTempArray);
    }
  }, [options]);

  const onFinish = () => {
    const isNumericQuestion = /^[0-9]+$/.test(questionData.question);
    if (isNumericQuestion) {
      message.error(questionErrorMessage);
    } else {
      message.success(questionSuccessMessage);

      if (onAddQuestion) {
        onAddQuestion({
          data: {
            question: questionData.question,
            categoryId: items.filter((item) => item.name === "QUIZ_QUESTION")[0]
              ?.id,
            point: questionData.points,

            question_type: questionData.questionType,
            content: tempArray,
            question_content: contentArray,
          },
        });
        dispatch(
          crud.currentItem({
            data: {
              question: questionData.question,

              categoryId: items.filter(
                (item) => item.name === "QUIZ_QUESTION"
              )[0]?.id,
              point: questionData.points,

              question_type: questionData.questionType,
              content: tempArray,
              question_content: contentArray,
              editQuestionIndex:
                editQuestionIndex != null ? editQuestionIndex : -1,
            },
          })
        );
      }

      if (onCancel) {
        onCancel();
      }

      setOptions([{ label: "Option 1", value: "", correct: false }]);
      setTempArray([]);
      setContentArray([]);
      dispatch(advancedCrud.resetAction({ actionType: "create" }));
      form.resetFields();
    }
  };

  useEffect(() => {
    if (!editData) {
      form.resetFields();
    }
  }, [editData]);

  const handleCancel = () => {
    if (editData?.length > 0) {
      if (onCancel) {
        setOptions([{ label: "Option 1", value: "", correct: false }]);
        setTempArray([]);
        setContentArray([]);
        dispatch(advancedCrud.resetAction({ actionType: "create" }));
        form.resetFields();
        onCancel();
      }
    }
  };

  const addOption = () => {
    if (options.length < 6) {
      const order = String.fromCharCode(65 + options.length); // Convert index to alphabetical letter
      setOptions([
        ...options,
        {
          label: `Option ${options.length + 1}`,
          value: "",
          correct: false,
          order: order,
        },
      ]);

      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: [
          ...prevData.createAnswer,
          {
            label: `Option ${options.length + 1}`,
            value: `Option ${options.length + 1}`,
            correct: false,
            order: order,
          },
        ],
      }));
    }
  };

  const deleteOption = (index) => {
    if (options.length > 1) {
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);

      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: newOptions,
      }));
    }
  };

  const handleRadioChange = (index) => {
    const updatedOptions = options.map((opt, i) => ({
      ...opt,
      correct: i === index,
    }));
    setOptions(updatedOptions);

    setQuestionData((prevData) => ({
      ...prevData,
      createAnswer: updatedOptions,
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setQuestionData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handlePointsChange = (value) => {
    if (!isNaN(value)) {
      // Check if value is a number
      setQuestionData((prevData) => ({
        ...prevData,
        points: value,
      }));
    }
  };

  useEffect(() => {
    // Disable the "More Options" button when the number of options is 6
    if (options.length >= 6) {
      form.setFieldsValue({ moreOptionsDisabled: true });
    }
  }, [options, form]);

  useEffect(() => {
    const listEntity = "/category/filter/list";
    const options = {
      type: "question",
    };
    const customizeConfigParameters = {
      responseInnerObj: "category",
      params: "recordStatus=true",
    };

    dispatch(erp.list({ listEntity, options, customizeConfigParameters }));
  }, []);

  return (
    <Form
      form={form}
      layout="vertical"
      name="add-question-form"
      onFinish={onFinish}
    >
      <Form.Item
        label="Question"
        name="question"
        rules={[{ required: true, message: "Please enter a question" }]}
      >
        <TextArea
          onChange={(e) =>
            handleInputChange({
              target: { name: "question", value: e.target.value },
            })
          }
        />
      </Form.Item>

      <Form.Item
        label="Points"
        name="points"
        rules={[
          { required: true },
          ({ getFieldValue }) => ({
            validator(_, value) {
              if (value >= 1 && value <= 100) {
                return Promise.resolve();
              }
              // Return undefined to suppress the default error message
              return Promise.reject();
            },
          }),
        ]}
      >
        <Input
          className="col-3"
          type="number"
          min="1"
          max="100"
          pattern="[0-9]*" // Only allows numeric input
          onChange={(e) => handlePointsChange(e.target.value)}
        />
      </Form.Item>

      <Form.Item className="ml-5" label="Attach Media" name="attachMedia">
        <TrainingResourcesButton
          onComplete={handleUploadComplete}
          entityName={"QUIZQUESTION"}
          uploadedData={contentArray}
          editData={editData}
          mediaEditFlag={mediaEditFlag}
        />
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit">
          Save
        </Button>
      </Form.Item>
    </Form>
  );
};

export default AddQuestionForm;
