import { useEffect, useState } from "react";
import dayjs from "dayjs";

import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { selectUpdatedItem } from "@/redux/crud/selectors";
import {
  DownOutlined,
  DeleteOutlined,
  VideoCameraOutlined,
  FilePdfOutlined,
  FileExcelOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { selectCreatedItem as items } from "@/redux/adavancedCrud/selectors";

import UploadPdfPage from "@/forms/UploadPdfForm";
import UploadVideoPage from "@/forms/UploadVideoForm";
import UploadExcelPage from "@/forms/UploadExcelForm";

import useLanguage from "@/locale/useLanguage";

import { Button, Form, List, Card, Modal } from "antd";
import Loading from "@/components/Loading";

export default function TopicUpdateForm({
  config,
  formElements,
  withUpload = false,
}) {
  let { customizeConfigParameters } = config;
  let { listEntity, updateEntity } = config.entities;
  const translate = useLanguage();
  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);
  const [tempArray, setTempArray] = useState([]);
  const [tempArrayId, setTempArrayId] = useState([]);
  const [tempUpdatedId, setTempUpdatedId] = useState([]);
  const [removeResources, setRemoveResources] = useState([]);
  const [isEditMode, setIsEditMode] = useState(false);
  const { result } = useSelector(items);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [formComponent, setFormComponent] = useState(null);
  const [form] = Form.useForm();

  const { state, crudContextAction } = useCrudContext();
  /////

  const { panel, collapsedBox, readBox } = crudContextAction;

  const showCurrentRecord = () => {
    readBox.open();
  };

  const showModal = (option) => {
    setIsModalVisible(true);
  };

  /////

  const handleUploadComplete = (updatedTitle, updatedDescription, record) => {
    // Use map to update the matching record in tempArray
    const updatedTempArray = tempArray.map((item) => {
      // Check if the record ID matches the current item's content ID
      if (item.content.id === record.id) {
        // If there is a match, update the title and description
        return {
          ...item,
          content: {
            ...item.content,
            title: updatedTitle,
            description: updatedDescription,
          },
        };
      }
      return item;
    });

    setTempArray(updatedTempArray);
    setIsModalVisible(false);
  };

  useEffect(() => {
    const ids = tempArray.map((item) => item.content.id);
    setTempArrayId(ids);
    if (result) {
      setTempUpdatedId((prevResources) => [...prevResources, result.id]);
    }
  }, [tempArray, result]);

  const onSubmit = (fieldsValue) => {
    if (isEditMode) {
      return;
    }

    event.preventDefault();
    const id = current.id;
    if (fieldsValue.file && withUpload) {
      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }

    const changedFields = Object.keys(fieldsValue).filter(
      (key) => fieldsValue[key] !== current[key]
    );

    const jsonData = changedFields.reduce((acc, key) => {
      acc[key] =
        typeof fieldsValue[key] === "string"
          ? fieldsValue[key].trim()
          : fieldsValue[key];

      return acc;
    }, {});

    const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
      acc[key] =
        typeof fieldsValue[key] === "string"
          ? fieldsValue[key].trim()
          : fieldsValue[key];
      if (key === "resources") {
        (acc["addResources"] = tempUpdatedId),
          (acc["removeResources"] = removeResources);
      }
      return acc;
    }, {});

    dispatch(
      crud.update({
        listEntity,
        updateEntity,
        id,
        jsonData: current.thumbnail ? trimmedValues : jsonData,
        withUpload,
        customizeConfigParameters,
      })
    );
  };

  useEffect(() => {
    if (current) {
      setTempArray(current?.topic_contents);
      let newValues = { ...current };

      if (newValues.birthday) {
        newValues = {
          ...newValues,
          birthday: dayjs(newValues["birthday"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.date) {
        newValues = {
          ...newValues,
          date: dayjs(newValues["date"]).format("YYYY-MM-DDTHH:mm:ss.SSSZ"),
        };
      }
      if (newValues.expiredDate) {
        newValues = {
          ...newValues,
          expiredDate: dayjs(newValues["expiredDate"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.created) {
        newValues = {
          ...newValues,
          created: dayjs(newValues["created"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.updated) {
        newValues = {
          ...newValues,
          updated: dayjs(newValues["updated"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      form.resetFields();
      form.setFieldsValue(newValues);
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      // readBox.open();
      setIsEditMode(true);
      collapsedBox.open();
      {
        isEditMode == false ? panel.close() : "";
      }
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
  }, [isSuccess]);

  const { isEditBoxOpen } = state;

  const handleEdit = (record) => {
    setIsEditMode(true);
    setIsModalVisible(true);
    if (record?.type === "PDF") {
      // Show UploadPdfPage for PDF type
      setFormComponent(
        <UploadPdfPage record={record} onComplete={handleUploadComplete} />
      );
    } else if (record?.type === "VIDEO") {
      // Show UploadVideoPage for VIDEO type
      setFormComponent(
        <UploadVideoPage record={record} onComplete={handleUploadComplete} />
      );
    } else if (record?.type === "EXCEL") {
      // Show UploadExcelPage for EXCEL type
      setFormComponent(
        <UploadExcelPage record={record} onComplete={handleUploadComplete} />
      );
    } else {
      // Handle other types or provide a default form component
      setFormComponent(null);
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    // form.resetFields();
  };

  const handleDelete = (index) => {
    // Create a copy of the tempArray
    const updatedTempArray = [...tempArray];
    // Remove the item at the specified index
    const removedItem = updatedTempArray.splice(index, 1)[0];
    // Update the state with the modified tempArray
    setTempArray(updatedTempArray);

    // Update removeResources array with the id from the content
    setRemoveResources((prevRemoveResources) => [
      ...prevRemoveResources,
      removedItem.content.id,
    ]);
  };

  const handleSave = () => {
    setIsEditMode(false);
  };

  const show = isEditBoxOpen
    ? { display: "block", opacity: 1 }
    : { display: "none", opacity: 0 };
  return (
    <div style={show}>
      <Loading isLoading={isLoading}>
        <Form
          form={form}
          layout="vertical"
          onFinish={(fieldsValue, event) => onSubmit(fieldsValue)}
        >
          {formElements}
          {tempArray.length > 0 && (
            <Card className="mb-2 mt-2 p-2" title="Previously Uploaded Files">
              <List
                size="small"
                className="resources-list-item"
                bordered
                dataSource={tempArray.map((item) => item.content)}
                renderItem={(item, index) => (
                  <List.Item>
                    {item?.type == "VIDEO" && (
                      <VideoCameraOutlined style={{ marginRight: "4%" }} />
                    )}
                    {item?.type == "PDF" && (
                      <FilePdfOutlined style={{ marginRight: "4%" }} />
                    )}
                    {item?.type == "EXCEL" && (
                      <FileExcelOutlined style={{ marginRight: "4%" }} />
                    )}

                    <span
                      className="list-item"
                      onClick={() => {
                        window.open(
                          item.url,
                          "_blank" // <- opens the link in a new tab or window.
                        );
                      }}
                    >
                      {`${index + 1}- ${
                        item?.title.length > 22
                          ? `${item?.title.slice(0, 22)}...`
                          : item?.title
                      }`}
                    </span>
                    <Button
                      type="text"
                      icon={<DeleteOutlined />}
                      onClick={() => handleDelete(index)}
                      className="text-danger "
                    />
                    <Button
                      onClick={() => handleEdit(item)}
                      type="text"
                      htmlType="submit"
                      icon={<EditOutlined />}
                    ></Button>
                  </List.Item>
                )}
              />
            </Card>
          )}
          <Form.Item
            style={{
              display: "inline-block",
              paddingRight: "5px",
            }}
          >
            <Button onClick={handleSave} type="primary" htmlType="submit">
              {translate("Save")}
            </Button>
          </Form.Item>
        </Form>
      </Loading>

      <Modal visible={isModalVisible} onCancel={handleCancel} footer={null}>
        {formComponent}
      </Modal>
    </div>
  );
}
