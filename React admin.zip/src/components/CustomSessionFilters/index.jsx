import React, { useState, useEffect } from "react";
import { request } from "@/request";
import { Input, Button, Space, Select, Form } from "antd";
import { DatePicker } from "antd";
import dayjs from "dayjs";
import useLanguage from "@/locale/useLanguage";
import {
  getDisplayLabels,
  getField,
  getOutpuValue,
  getStatus,
  isActive,
} from "@/utils/helpers";
import { getOptionsList } from "./CustomSessionUtils";
export const CustomSessionFilters = ({
  onSearch,
  filterFields,
  customizeConfigParameters,
  onRecordStatusChange,
  config,
  filterRef, // Add filterRef prop
}) => {
  const translate = useLanguage();
  const [searchTerms, setSearchTerms] = useState({
    filterBy: "",
    title: "",
    courseId: "",
    batchId: "",
    srmId: "",
    reportedBy: "",
    primaryFacultyId: "",
    secondaryFacultyId: "",
    date: "",
    createdAt: "",
    sessionDate: "",
    userName: "",
    recordStatus: "",
    status: "",
  });
  const [form] = Form.useForm(); // Initialize the form

  const [customizeConfigParameter, setCustomizeConfigParameter] = useState({
    params: customizeConfigParameters ? customizeConfigParameters : "",
  });
  const [filterOptions, setFilterOptions] = useState([]);
  const [datePickerValue, setDatePickerValue] = useState(null);
  const asyncList = async () => {
    let options = {};
    if (
      searchTerms.filterBy === "SRM" ||
      searchTerms.filterBy === "TEACHER" ||
      searchTerms.filterBy === "secodaryFaculty" ||
      searchTerms.filterBy === "STUDENT" ||
      searchTerms.filterBy === "reportedBy"
    ) {
      options.roles = `${
        searchTerms.filterBy === "secodaryFaculty"
          ? "TEACHER"
          : searchTerms.filterBy
      }`;
      const resp = await request.list({
        listEntity: `/user/filter/list`,
        options: options,
      });
      return await resp;
    } else {
      const resp = await request.list({
        listEntity: `/${searchTerms.filterBy}/filter/list`,
      });
      return await resp;
    }
    return null;
  };

  useEffect(() => {
    const fetchList = async () => {
      if (searchTerms.filterBy) {
        try {
          const resp = await asyncList();
          if (
            resp &&
            resp.data[searchTerms.filterBy] &&
            searchTerms.filterBy !== "learning-session"
          ) {
            setFilterOptions(resp.data[searchTerms.filterBy]);
          } else if (searchTerms.filterBy === "learning-session") {
            setFilterOptions(resp.data["learningSession"]);
          } else {
            setFilterOptions(resp.data["user"]);
          }
        } catch (error) {
          console.error("Error fetching list:", error);
        }
      }
    };

    fetchList();
  }, [searchTerms]);
  const optionList = getOptionsList(filterOptions, searchTerms);
  const handleInputChange = (fieldName, value) => {
    if (
      filterFields[fieldName].type === "select" ||
      fieldName === "filterValue"
    ) {
      // Call the onLinkStatusChange callback when the Select value changes
      if (onRecordStatusChange) {
        onRecordStatusChange(isActive(value));
      }
    }

    if (filterFields[fieldName].type === "date") {
      const formattedDate = value
        ? dayjs(value, "DD/MM/YYYY").format("DD/MM/YYYY")
        : null;
      setSearchTerms((prevSearchTerms) => ({
        ...prevSearchTerms,
        [fieldName]: formattedDate,
      }));

      setDatePickerValue(formattedDate);
    } else {
      if (fieldName === "filterBy") {
        setSearchTerms((prevSearchTerms) => ({
          [fieldName]: value,
        }));
      } else {
        const defaultTerms = {
          filterBy: "",
          title: "",
          courseId: "",
          batchId: "",
          srmId: "",
          primaryFacultyId: "",
          secondaryFacultyId: "",
          date: "",
          createdAt: "",
          sessionDate: "",
          userName: "",
          reportedBy: "",
          recordStatus: "",
          status: "",
        };
        setSearchTerms((prevSearchTerms) => ({
          ...defaultTerms,
          filterBy: prevSearchTerms.filterBy,
          [getField(prevSearchTerms.filterBy, config)]:
            getField(prevSearchTerms.filterBy, config) === "createdAt"
              ? dayjs(value, "DD/MM/YYYY").format("DD/MM/YYYY")
              : getField(prevSearchTerms.filterBy, config) === "date"
                ? dayjs(value, "DD/MM/YYYY").format("YYYY-MM-DD")
                : getField(prevSearchTerms.filterBy, config) === "status"
                  ? getStatus(value)
                  : getField(prevSearchTerms.filterBy, config) ===
                      "recordStatus"
                    ? isActive(value)
                    : value,
        }));
      }
    }
  };

  const handleSearch = () => {
    setCustomizeConfigParameter({
      params: Object.entries(searchTerms)
        .map(([key, value]) => `${key}=${value}`)
        .join("&"),
    });

    const { filterBy, ...paramsTerms } = searchTerms;
    onSearch(paramsTerms);
  };

  const handleReset = () => {
    form.resetFields(); // Reset the form
    setSearchTerms({
      filterBy: "",
      title: "",
      courseId: "",
      batchId: "",
      srmId: "",
      reportedBy: "",
      primaryFacultyId: "",
      secondaryFacultyId: "",
      date: "",
      createdAt: "",
      sessionDate: "",
      userName: "",
      recordStatus: "",
      status: "",
    });
    setDatePickerValue(null); // Reset date picker value if needed
  };
  useEffect(() => {
    // Assign the reset function to filterRef.current
    filterRef.current = {
      reset: handleReset,
    };
  }, [filterRef]);

  return (
    <Form form={form} initialValues={{}} className="custome-filter-form">
      <Space style={{ marginBottom: 16 }}>
        {Object.keys(filterFields).map((fieldName) => {
          const fieldConfig = filterFields[fieldName];
          if (
            fieldConfig.type === "string" ||
            fieldConfig.type === "email" ||
            fieldConfig.type === "phone"
          ) {
            return (
              <Input
                key={fieldName}
                size="default"
                placeholder={fieldConfig?.placeholder}
                onChange={(e) => handleInputChange(fieldName, e.target.value)}
                value={searchTerms[fieldName] || ""}
              />
            );
          } else if (
            fieldConfig.type === "sessionSelect" &&
            (searchTerms.filterBy === "date" ||
              searchTerms.filterBy === "createdAt")
          ) {
            return (
              <DatePicker
                size="default"
                key={fieldName}
                format={"DD/MM/YYYY"}
                onChange={(date, dateString) =>
                  handleInputChange(fieldName, dateString)
                }
                value={
                  datePickerValue
                    ? dayjs(datePickerValue, "DD/MM/YYYY")
                    : undefined
                }
              />
            );
          } else if (
            fieldConfig.type === "sessionSelect" &&
            searchTerms.filterBy === "status"
          ) {
            return (
              <Select
                key={searchTerms.filterBy}
                size="default"
                className={"sessionFilterSelect"}
                placeholder={translate(searchTerms.filterBy)}
                onChange={(value) => handleInputChange(fieldName, value)}
                value={searchTerms[fieldName] || undefined}
                defaultValue={fieldConfig.defaultValue}
              >
                <Select.Option value="CANCELLED">CANCELLED</Select.Option>
                <Select.Option value="SCHEDULED">SCHEDULED</Select.Option>
                <Select.Option value="COMPLETED">COMPLETED</Select.Option>
              </Select>
            );
          } else if (
            fieldConfig.type === "sessionSelect" &&
            searchTerms.filterBy === "Active/Deactive"
          ) {
            return (
              <Select
                key={searchTerms.filterBy}
                size="default"
                className={"sessionFilterSelect"}
                placeholder={translate(searchTerms.filterBy)}
                onChange={(value) => handleInputChange(fieldName, value)}
                value={searchTerms[fieldName] || undefined}
                defaultValue={fieldConfig.defaultValue}
              >
                <Select.Option value="active">Active</Select.Option>
                <Select.Option value="deactive">Deactive</Select.Option>
              </Select>
            );
          } else if (fieldConfig.type === "select") {
            return (
              <Select
                key={fieldName}
                size="default"
                className={"sessionFilterSelect"}
                placeholder={fieldConfig?.placeholder}
                onChange={(value) => handleInputChange(fieldName, value)}
                value={searchTerms[fieldName] || undefined}
                defaultValue={fieldConfig.defaultValue}
              >
                {fieldConfig.options.map((option) => (
                  <Select.Option key={option.value} value={option.value}>
                    {option.label}
                  </Select.Option>
                ))}
              </Select>
            );
          } else if (
            fieldConfig.type === "sessionSelect" &&
            searchTerms.filterBy
          ) {
            return (
              <>
                <Select
                  key={searchTerms.filterBy}
                  size="default"
                  className={"sessionFilterSelect"}
                  placeholder={translate(searchTerms.filterBy)}
                  onChange={(value) => handleInputChange(fieldName, value)}
                  value={
                    searchTerms[getField(searchTerms.filterBy, config)] ||
                    undefined
                  }
                  defaultValue={fieldConfig.defaultValue}
                >
                  {optionList?.map((option) => (
                    <Select.Option key={option.value} value={option.value}>
                      {option.label}
                    </Select.Option>
                  ))}
                </Select>
              </>
            );
          }
          return null;
        })}
        <Button type="primary" size="default" onClick={handleSearch}>
          {translate("Search")}
        </Button>
      </Space>
    </Form>
  );
};
