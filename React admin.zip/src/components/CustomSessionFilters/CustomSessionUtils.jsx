import { getDisplayLabels, getOutpuValue } from "@/utils/helpers";

const labels = (optionField, searchTerms) => {
  return getDisplayLabels(searchTerms?.filterBy)
    ?.map((x) => optionField[x])
    .join(" ");
};
export const getOptionsList = (filterOptions, searchTerms) => {
  const list = [];
  filterOptions?.map((optionField) => {
    const value =
      optionField[getOutpuValue(searchTerms?.filterBy)] ?? optionField;
    const label = labels(optionField, searchTerms);
    list.push({ value, label });
  });
  return list;
};
