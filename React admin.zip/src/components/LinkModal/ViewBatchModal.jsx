import { useEffect } from "react";
import { Col, Modal } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { selectUpdatedItem } from "@/redux/crud/selectors";
import useLanguage from "@/locale/useLanguage";

export default function ViewBatchModal({ config }) {
  const translate = useLanguage();
  let { listEntity } = config.entities;
  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);

  const { state, crudContextAction } = useCrudContext();
  const { panel, readBox } = crudContextAction;
  const { isViewBatchModalOpen } = state;
  const { viewBatchModal } = crudContextAction;

  useEffect(() => {
    if (isSuccess) {
      viewBatchModal.close();
      // dispatch(crud.list({ listEntity }));
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    readBox.close();
    viewBatchModal.close();
    panel.close();
  };

  const handleCancel = () => {
    if (!isLoading) viewBatchModal.close();
  };

  return (
    <>
      <Modal
        title={"View Batch Detail"}
        open={isViewBatchModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={isLoading}
        footer={null}
      >
        <Col sm="3">
          <div>
            <span className="text-secondary">{translate("Batch Number")}:</span>
            <span className="text-success m-3">
              {current?.batch?.batchNumber}
            </span>
          </div>
        </Col>
        <Col sm="3">
          <div>
            <span className="text-secondary">{translate("Course Name")}:</span>
            <span className="text-success m-3">{current?.course?.title}</span>
          </div>
        </Col>
        <Col sm="3">
          <span className="text-secondary">{translate("Start Date")}:</span>
          <span className="text-success m-3">{current?.batch?.startDate}</span>
        </Col>
        <Col sm="3">
          <span className="text-secondary">{translate("End Date")}:</span>
          <span className="text-success m-3">{current?.batch?.endDate}</span>
        </Col>
        <Col sm="3">
          <span className="text-secondary">
            {translate("Mode Of Classes")}:
          </span>
          <span className="text-success m-3">{current?.batch?.classMode}</span>
        </Col>
      </Modal>
    </>
  );
}
