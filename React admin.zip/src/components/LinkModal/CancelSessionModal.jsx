import { useEffect, useState } from "react";
import { Modal } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { selectUpdatedItem } from "@/redux/crud/selectors";
import useLanguage from "@/locale/useLanguage";
import TextArea from "antd/es/input/TextArea";
import { selectCurrentAdmin } from "@/redux/auth/selectors";

export default function CancelSessionModal({ config }) {
  const translate = useLanguage();
  const [isSecondModalVisible, setIsSecondModalVisible] = useState(false);
  const [isFirstModalOkClicked, setIsFirstModalOkClicked] = useState(false);
  const [value, setValue] = useState("");

  let { cancelMessage = translate("are_you_sure_you_want_to_cancel_session") } =
    config;
  let { listEntity, updateEntity } = config.entities;

  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);
  const currentAdmin = useSelector(selectCurrentAdmin);

  const { state, crudContextAction } = useCrudContext();
  const { panel, readBox } = crudContextAction;
  const { isCancelSessionModalOpen } = state;
  const { cancelSessionModal } = crudContextAction;
  const [displayItem, setDisplayItem] = useState("");

  useEffect(() => {
    if (isSuccess) {
      cancelSessionModal.close();
      // dispatch(crud.list({ listEntity }));
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    readBox.close();
    cancelSessionModal.close();
    panel.close();

    setIsFirstModalOkClicked(true);
  };
  const userId = currentAdmin?.userId;
  const handleSecondModalOk = () => {
    let dataObject;
    console.log("config.ENTITY_NAME ==>", config.ENTITY_NAME);
    if (
      config?.ENTITY_NAME == "Batchsession" ||
      config?.ENTITY_NAME == "Session"
    ) {
      const id = current?.id;
      const quizes = {
        reason: value,
        cancelledBy: userId,
        status: "CANCELLED",
      };
      dataObject = { ...quizes };
      dispatch(
        crud.update({
          listEntity,
          updateEntity,
          id,
          dataObject,
          withUpload: false,
        })
      );
    }
    setIsSecondModalVisible(false);
  };

  const handleSecondModalCancel = () => {
    setIsSecondModalVisible(false);
  };

  useEffect(() => {
    if (isFirstModalOkClicked) {
      setIsSecondModalVisible(true);
    }
  }, [isFirstModalOkClicked]);

  const handleCancel = () => {
    if (!isLoading) cancelSessionModal.close();
  };
  let title;

  return (
    <>
      <Modal
        title={title}
        open={isCancelSessionModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={isLoading}
      >
        <p>
          {config?.ENTITY_NAME === "Batchsession" ||
          config?.ENTITY_NAME == "Session"
            ? cancelMessage
            : ""}
          {displayItem}
        </p>
      </Modal>

      {isSecondModalVisible && (
        <Modal
          title="Reason For Cancellation"
          open={isSecondModalVisible}
          onOk={handleSecondModalOk}
          onCancel={handleSecondModalCancel}
        >
          <TextArea
            placeholder="reasons"
            onChange={(e) => {
              setValue(e.target.value);
            }}
          />
        </Modal>
      )}
    </>
  );
}
