import { useEffect, useState } from "react";
import { Modal } from "antd";

import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { useAppContext } from "@/context/appContext";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { selectDeletedItem as items } from "@/redux/adavancedCrud/selectors";

import { valueByString } from "@/utils/helpers";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";
import QuizClone from "../QuizClone/QuizClone";
import CapstoneClone from "../CapstoneClone/CapstoneClone";

export default function ConfirmationModal({ config, editedOrders }) {
  const translate = useLanguage();
  let {
    deletedentity,
    entity,
    entities,
    deleteModalLabels,
    cloneMessage = translate("are_you_sure_you_want_to_clone"),
    cloneTitle = translate("clone_confirmation"),
    modalUnLinkTitle = translate("Unlink_confirmation"),
  } = config;
  let { listEntity } = config.entities;
  const { id } = useParams();

  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);
  const {
    current: itemsCurrent,
    isLoading: itemsIsLoading,
    isSuccess: itemsIsSuccess,
  } = useSelector(items);

  const { state, crudContextAction } = useCrudContext();
  const { appContextAction } = useAppContext();
  const { panel, readBox } = crudContextAction;
  const { navMenu } = appContextAction;
  const { isConfirmationModalOpen } = state;
  const { confirmationModal } = crudContextAction;
  const [currentData, SetcurrentData] = useState(current);
  const [displayItem, setDisplayItem] = useState("");
  const [isQuizCloneVisible, Setisquizclonevisible] = useState(false);
  const EntityName = deletedentity?.entityname;

  const handleSecondModalOk = () => {};

  const handleSecondModalCancel = () => {
    Setisquizclonevisible(false);
    if (!isLoading) confirmationModal.close();
  };

  useEffect(() => {
    if (isSuccess) {
      confirmationModal.close();

      // dispatch(crud.list({ listEntity }));
    }
    if (current) {
      let labels = deleteModalLabels
        .map((x) => valueByString(current, x))
        .join(" ");

      setDisplayItem(labels);
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    Setisquizclonevisible(true);
  };
  const handleCancel = () => {
    if (!isLoading) confirmationModal.close();
  };

  return (
    <>
      {" "}
      <Modal
        title={cloneTitle}
        open={isConfirmationModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={isLoading}
      >
        <p>
          {cloneMessage}
          {displayItem}
        </p>
      </Modal>
      {isQuizCloneVisible && (
        <Modal
          // title="Reason For Cancellation"
          open={isQuizCloneVisible}
          onOk={handleSecondModalOk}
          onCancel={handleSecondModalCancel}
          footer={null}
        >
          {config?.ENTITY_NAME == "Quiz" || config?.ENTITY_NAME == "Exam" ? (
            <QuizClone handleSecondModalCancel={handleSecondModalCancel} />
          ) : (
            <CapstoneClone handleSecondModalCancel={handleSecondModalCancel} />
          )}
        </Modal>
      )}
    </>
  );
}
