import { useEffect, useState } from "react";
import {
  Modal,
  Form,
  Select,
  DatePicker,
  TimePicker,
  Button,
  Row,
  Col,
} from "antd";
import moment from "moment";

import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { useAppContext } from "@/context/appContext";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { selectDeletedItem as items } from "@/redux/adavancedCrud/selectors";
import { selectListItems } from "@/redux/erp/selectors";

import { valueByString } from "@/utils/helpers";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";
import { erp } from "@/redux/erp/actions";

export default function AddToBatchModal({ config, editedOrders }) {
  const translate = useLanguage();
  let {
    deletedentity,
    entity,
    entities,
    deleteModalLabels,
    linkMessage = translate("are_you_sure_you_want_to_link"),
    unlinkMessage = translate("are_you_sure_you_want_to_unlink"),
    modalLinkTitle = translate("link_confirmation"),
    modalUnLinkTitle = translate("Unlink_confirmation"),
  } = config;
  let { listEntity } = config.entities;
  const { id } = useParams();

  const { result: listResult, isLoading: listIsLoading } =
    useSelector(selectListItems);

  const dispatch = useDispatch();
  const [form] = Form.useForm();

  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);

  const { state, crudContextAction } = useCrudContext();
  const { appContextAction } = useAppContext();
  const { panel, readBox } = crudContextAction;
  const { navMenu } = appContextAction;
  const { isAddToBatchModalOpen } = state;
  const { addToBatchModal } = crudContextAction;
  const [displayItem, setDisplayItem] = useState("");

  const EntityName = deletedentity?.entityname;
  let title = "Add To Batch";

  useEffect(() => {
    if (config?.ENTITY_NAME === "Exam" || config?.ENTITY_NAME === "Capstone") {
      const listEntity = "/batch/filter/list";
      const customizeConfigParameters = {
        responseInnerObj: "batch",
        params: "recordStatus=true",
      };

      dispatch(erp.list({ listEntity, customizeConfigParameters }));
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      addToBatchModal.close();
    }
    if (current) {
      let labels = deleteModalLabels
        .map((x) => valueByString(current, x))
        .join(" ");

      setDisplayItem(labels);
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    readBox.close();
    addToBatchModal.close();
    panel.close();
  };
  const handleCancel = () => {
    if (!isLoading) addToBatchModal.close();
  };

  const handleSubmit = (values) => {
    // Transform the values before dispatching the action

    let transformedValues;

    if (current?.category?.name !== "CAPSTONE") {
      transformedValues = {
        examDate: values.examDate.format("YYYY-MM-DD"),
        startTime: values.startTime.format("HH:mm:ss"), // Keep it as a moment object
        categoryId: current?.categoryId,
      };
    } else {
      transformedValues = {
        categoryId: current?.categoryId,
      };
    }

    // Dispatch the action with the transformed values
    const batchId = values?.batch;
    const quizId = current?.id;

    const customizeUrl = "batch/" + batchId + "/" + "quiz/" + quizId;
    const dataObject = transformedValues;
    dispatch(crud.post({ customizeUrl, dataObject }));
    form.resetFields();
    const listEntity = config?.entities?.listEntity;
    const customizeConfigParameters = config?.customizeConfigParameters;
    setTimeout(() => {
      dispatch(
        crud.list({
          listEntity,
          customizeConfigParameters,
        })
      );
    }, 100);

    if (!isLoading) addToBatchModal.close();
  };

  return (
    <Modal
      title={title}
      open={isAddToBatchModalOpen}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={isLoading}
      footer={false}
    >
      <Form
        layout="vertical"
        name="add-question-form"
        form={form} // Pass the form instance to the Form component
        onFinish={(values) => {
          // Handle form submission here
          handleSubmit(values);
          // Perform additional actions as needed
        }}
      >
        {/* Existing form items */}
        <Form.Item
          label="Batch"
          name="batch"
          rules={[{ required: true, message: "Please select a batch" }]}
        >
          <Select>
            {listResult.items.map((batch) => (
              <Option key={batch.id} value={batch.id}>
                {batch.batchNumber}
              </Option>
            ))}
          </Select>
        </Form.Item>

        {/* Add Date and Time Picker */}
        {current?.category?.name !== "CAPSTONE" && (
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label="Exam Date"
                name="examDate"
                rules={[{ required: true, message: "Please select a date" }]}
              >
                <DatePicker />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label="Start Time"
                name="startTime"
                rules={[{ required: true, message: "Please select a time" }]}
              >
                <TimePicker
                  format="HH:mm"
                  // defaultValue={moment("00:00", "HH:mm")}
                />
              </Form.Item>
            </Col>
          </Row>
        )}

        {/* Save Button */}
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  );
}
