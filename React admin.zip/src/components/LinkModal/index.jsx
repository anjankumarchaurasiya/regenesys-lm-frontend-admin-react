import { useEffect, useState } from "react";
import { Modal } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { useAppContext } from "@/context/appContext";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { selectDeletedItem as items } from "@/redux/adavancedCrud/selectors";
import { valueByString } from "@/utils/helpers";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";

export default function LinkModal({ config, editedOrders }) {
  const translate = useLanguage();
  let {
    deletedentity,
    entity,
    entities,
    deleteModalLabels,
    linkMessage = translate("are_you_sure_you_want_to_link"),
    orderMessage = translate("are_you_sure_you_want_to_change_order"),
    unlinkMessage = translate("are_you_sure_you_want_to_unlink"),
    modalLinkTitle = translate("link_confirmation"),
    modalUnLinkTitle = translate("Unlink_confirmation"),
    orderTitle = translate("Order_confirmation"),
  } = config;
  let { listEntity } = config.entities;
  const { id } = useParams();

  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);
  const {
    current: itemsCurrent,
    isLoading: itemsIsLoading,
    isSuccess: itemsIsSuccess,
  } = useSelector(items);

  const { state, crudContextAction } = useCrudContext();
  const { appContextAction } = useAppContext();
  const { panel, readBox } = crudContextAction;
  const { navMenu } = appContextAction;
  const { isLinkModalOpen } = state;
  const { linkmodal } = crudContextAction;
  const [currentData, SetcurrentData] = useState(current);
  const [displayItem, setDisplayItem] = useState("");
  const EntityName = deletedentity?.entityname;

  useEffect(() => {
    if (isSuccess) {
      linkmodal.close();

      // dispatch(crud.list({ listEntity }));

      // dispatch(crud.list({ entity }));
      // dispatch(crud.resetAction({actionType:"delete"})); // check here maybe it wrong
    }
    if (current) {
      let labels = deleteModalLabels
        .map((x) => valueByString(current, x))
        .join(" ");

      setDisplayItem(labels);
    }
  }, [isSuccess, current]);
  const handleOk = () => {
    let customizeUrl;
    let dataObject;
    if (config?.ENTITY_NAME === "Studentbatch" && current?.linkStatus) {
      const batchId = current?.unselectedRecords[0]?.batch_id;
      const unLinked = current.users;
      const linkedentity = entities?.linkedEntity;
      const linkData = { linkedentity, batchId, EntityName };
      customizeUrl = entities?.listEntity;
      dataObject = { unLinked };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "batch",
        params: `linked=true`,
      };
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 200);
    }
    if (
      config?.ENTITY_NAME === "Studentbatch" &&
      current?.linkStatus == false
    ) {
      const batchId = current?.selectedrecord[0]?.batch_id;
      const linked = current.users;
      const linkedentity = entities?.linkedEntity;
      const linkData = { linkedentity, batchId, EntityName };
      customizeUrl = entities?.listEntity;
      dataObject = { linked };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "batch",
        params: `linked=false`,
      };
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 200);
    }
    if (config?.ENTITY_NAME === "Student") {
      const linked = current.users;
      const batchId = localStorage.getItem("batchId");
      customizeUrl = `/batch/${batchId}/user`;
      dataObject = { linked };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
    }
    if (config?.ENTITY_NAME == "Module") {
      const courseid = current?.record.id;
      const modules = current.modules;
      const linkedentity = entities?.linkedentity;
      const linkData = { linkedentity, courseid, EntityName };
      customizeUrl =
        linkData?.linkedentity +
        "/" +
        linkData?.courseid +
        "/" +
        linkData?.EntityName;

      dataObject = { modules };
      dispatch(crud.post({ customizeUrl, dataObject }));
    }
    if (config?.ENTITY_NAME == "Topic") {
      const moduleid = current?.record.id;
      const topics = current.topics;
      const linkedentity = entities?.linkedentity;
      const linkData = { linkedentity, moduleid, EntityName };
      customizeUrl =
        linkData?.linkedentity +
        "/" +
        linkData?.moduleid +
        "/" +
        linkData?.EntityName;
      dataObject = { topics };
      dispatch(crud.post({ customizeUrl, dataObject }));
    }

    if (config?.ENTITY_NAME == "Viewmodule" && current?.linkStatus) {
      const courseid = id;
      const unLinked = current.modules;
      const order = current.order;

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, courseid, EntityName };
      customizeUrl =
        linkData?.unlinkEntity + "/" + linkData?.courseid + "/" + "module";

      dataObject = { unLinked, order };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "module",
        params: `courseId=${id}&linked=true`,
      };
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    if (config?.ENTITY_NAME == "Viewmodule" && current?.linkStatus == false) {
      const courseid = id;
      const unLinked = current.modules;

      const order = current.order.map((order) => ({
        ...order,
        order: 0, // Set order value to 0 for each object
      }));

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, courseid, EntityName };
      customizeUrl =
        linkData?.unlinkEntity + "/" + linkData?.courseid + "/" + "module";

      dataObject = { unLinked, order };

      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "module",
        params: `courseId=${id}&linked=true`,
      };
      // setTimeout(() => {
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
      // }, 100);
    }

    if (config?.ENTITY_NAME == "Viewtopic" && current?.linkStatus) {
      const moduleid = id;
      const unLinked = current.topics;
      const order = current.order;

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, moduleid, EntityName };
      customizeUrl =
        linkData?.unlinkEntity + "/" + linkData?.moduleid + "/" + "topic";

      dataObject = { unLinked, order };
      dispatch(crud.resetState());

      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "topic",
        params: `moduleId=${id}&linked=true`,
      };
      // setTimeout(() => {
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
      // }, 100);
    }

    if (config?.ENTITY_NAME == "Viewtopic" && current?.linkStatus == false) {
      const moduleid = id;
      const unLinked = current.topics;
      const order = current.order.map((order) => ({
        ...order,
        order: 0, // Set order value to 0 for each object
      }));

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, moduleid, EntityName };
      customizeUrl =
        linkData?.unlinkEntity + "/" + linkData?.moduleid + "/" + "topic";

      dataObject = { unLinked, order };
      dispatch(crud.resetState());
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "topic",
        params: `moduleId=${id}&linked=false`,
      };
      // setTimeout(() => {
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
      // window.location.reload();
      // }, 100);
    }
    readBox.close();
    linkmodal.close();
    panel.close();
  };
  const handleCancel = () => {
    if (!isLoading) linkmodal.close();
  };
  let title;
  if (
    config?.ENTITY_NAME === "Topic" ||
    config?.ENTITY_NAME === "Module" ||
    config?.ENTITY_NAME == "Student" ||
    current?.linkStatus == false
  ) {
    title = modalLinkTitle;
  } else if (
    (config?.ENTITY_NAME === "Studentbatch" && current?.linkStatus) ||
    (config?.ENTITY_NAME === "Viewtopic" && current?.linkStatus)
  ) {
    title = modalUnLinkTitle;
  } else if (config?.ENTITY_NAME === "Viewmodule") {
    if (current?.linkStatus && current?.orderChanged) {
      title = orderTitle;
    } else if (current?.linkStatus) {
      title = modalUnLinkTitle;
    } else {
      title = modalLinkTitle;
    }
  } else {
    title = orderMessage;
  }
  return (
    <Modal
      title={title}
      open={isLinkModalOpen}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={isLoading}
    >
      <p>
        {config?.ENTITY_NAME === "Topic" ||
        config?.ENTITY_NAME === "Module" ||
        config?.ENTITY_NAME === "Student"
          ? linkMessage
          : config.ENTITY_NAME === "Viewmodule" &&
              current?.linkStatus &&
              current?.orderChanged
            ? orderMessage
            : current?.linkStatus
              ? unlinkMessage
              : linkMessage}
        {displayItem}
      </p>
    </Modal>
  );
}
