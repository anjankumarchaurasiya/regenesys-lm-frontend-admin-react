import { useEffect, useState } from "react";
import { Modal } from "antd";

import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { useAppContext } from "@/context/appContext";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { selectDeletedItem as items } from "@/redux/adavancedCrud/selectors";

import { valueByString } from "@/utils/helpers";

import useLanguage from "@/locale/useLanguage";
import { useParams } from "react-router-dom";

export default function QuizLinkModal({ config, editedOrders }) {
  const translate = useLanguage();
  let {
    deletedentity,
    entity,
    entities,
    deleteModalLabels,
    linkMessage = translate("are_you_sure_you_want_to_link"),
    unlinkMessage = translate("are_you_sure_you_want_to_unlink"),
    modalLinkTitle = translate("link_confirmation"),
    modalUnLinkTitle = translate("Unlink_confirmation"),
  } = config;
  let { listEntity } = config.entities;
  const { id } = useParams();

  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);
  const {
    current: itemsCurrent,
    isLoading: itemsIsLoading,
    isSuccess: itemsIsSuccess,
  } = useSelector(items);

  const { state, crudContextAction } = useCrudContext();
  const { appContextAction } = useAppContext();
  const { panel, readBox } = crudContextAction;
  const { navMenu } = appContextAction;
  const { isQuizLinkModalOpen } = state;
  const { quizlinkmodal } = crudContextAction;
  const [currentData, SetcurrentData] = useState(current);
  const [displayItem, setDisplayItem] = useState("");
  const EntityName = deletedentity?.entityname;

  useEffect(() => {
    if (isSuccess) {
      quizlinkmodal.close();

      // dispatch(crud.list({ listEntity }));
      // dispatch(crud.list({ entity }));
      // dispatch(crud.resetAction({actionType:"delete"})); // check here maybe it wrong
    }
    if (current) {
      let labels = deleteModalLabels
        .map((x) => valueByString(current, x))
        .join(" ");

      setDisplayItem(labels);
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    let customizeUrl;
    let dataObject;
    if (config?.ENTITY_NAME == "Quiz") {
      const courseid = current?.record.id;
      const quizes = current.quizes;
      const linkedentity = entities?.linkedentity;
      const linkData = { linkedentity, courseid, EntityName };
      customizeUrl =
        "learning-session" +
        "/" +
        linkData?.courseid +
        "/" +
        linkData?.EntityName;

      dataObject = { quizes };
      dispatch(crud.post({ customizeUrl, dataObject }));
    }

    if (config?.ENTITY_NAME == "View Session" && current?.recordStatusValue) {
      const sessionid = id;
      const unLinked = current.quizes;

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, sessionid, EntityName };
      customizeUrl =
        "quiz" + "/" + linkData?.sessionid + "/" + "learning-session";

      dataObject = { unLinked };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "quizLearningSession",
        params: "recordStatus=true",
      };
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    if (
      config?.ENTITY_NAME == "View Session" &&
      current?.recordStatusValue == false
    ) {
      const sessionid = id;
      const linked = current.quizes;
      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, sessionid, EntityName };
      customizeUrl =
        "quiz" + "/" + linkData?.sessionid + "/" + "learning-session";

      dataObject = { linked };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));
      const customizeConfigParameters = {
        responseInnerObj: "quizLearningSession",
        params: "recordStatus=false",
      };
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    if (config?.ENTITY_NAME == "ViewFeedbackSession" && current?.linkStatus) {
      const sessionid = id;
      const transformedData = {
        isLinked: true,
        sessions: current.quizes,
      };

      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, sessionid, EntityName };
      customizeUrl = "feedback" + "/" + linkData?.sessionid + "/" + "session";

      dataObject = { isLinked: false, sessions: current.quizes };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));

      const customizeConfigParameters = {
        responseInnerObj: "learningSessionfeedback",
        params: "linked=true&viewSessions=true",
      };

      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 200);
    }

    if (
      config?.ENTITY_NAME == "ViewFeedbackSession" &&
      current?.linkStatus == false
    ) {
      const sessionid = id;
      const unlinkEntity = entities?.unlinkEntity;
      const linkData = { unlinkEntity, sessionid, EntityName };
      customizeUrl = "feedback" + "/" + linkData?.sessionid + "/" + "session";

      dataObject = { isLinked: true, sessions: current.quizes };
      dispatch(crud.update({ customizeUrl, dataObject, withUpload: false }));

      const customizeConfigParameters = {
        responseInnerObj: "learningSessionfeedback",
        params: "linked=false&viewSessions=true",
      };

      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 200);
    }

    readBox.close();
    quizlinkmodal.close();
    panel.close();
    // navMenu.collapse();
    // dispatch(crud.list({ listEntity }));

    // dispatch(crud.list({ entity }));
  };
  const handleCancel = () => {
    if (!isLoading) quizlinkmodal.close();
  };
  let title;
  if (
    config?.ENTITY_NAME === "Quiz" ||
    current?.recordStatusValue == false ||
    (config?.ENTITY_NAME === "ViewFeedbackSession" && !current?.linkStatus)
  ) {
    title = modalLinkTitle;
  } else if (
    config?.ENTITY_NAME === "View Session" ||
    config?.ENTITY_NAME === "ViewFeedbackSession" ||
    (config?.ENTITY_NAME === "Viewtopic" && current?.linkStatus)
  ) {
    title = modalUnLinkTitle;
  }
  return (
    <Modal
      title={title}
      open={isQuizLinkModalOpen}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={isLoading}
    >
      <p>
        {config?.ENTITY_NAME === "Quiz" ||
        (config?.ENTITY_NAME === "View Session" &&
          current?.recordStatusValue == false) ||
        (config?.ENTITY_NAME === "ViewFeedbackSession" &&
          current?.linkStatus == false)
          ? linkMessage
          : unlinkMessage}
        {displayItem}
      </p>
    </Modal>
  );
}
