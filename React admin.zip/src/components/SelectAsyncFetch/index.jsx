import { useState, useEffect } from "react";
import { request } from "@/request";
import useFetch from "@/hooks/useFetch";
import { Select, Tag } from "antd";
import { useNavigate } from "react-router-dom";
import color from "@/utils/color";

const SelectAsyncFetch = ({
  entity,
  displayLabels = ["name"],
  outputValue = "name",
  redirectLabel = "",
  withRedirect = false,
  urlToRedirect = "/",
  value,
  onChange,
  asyncOptions = {},
  responseInner = "",
  placeholder = "",
  mode,
  topicentity,
}) => {
  const [selectOptions, setOptions] = useState([]);
  const [currentValue, setCurrentValue] = useState(undefined);
  const navigate = useNavigate();
  const asyncList = () => {
    const resp = request.list({ listEntity: entity, options: asyncOptions });
    return resp;
  };
  const {
    result,
    isLoading: fetchIsLoading,
    isSuccess,
  } = useFetch(asyncList, responseInner || "", entity);

  useEffect(() => {
    isSuccess && setOptions(result);
  }, [isSuccess, result]);

  const labels = (optionField) => {
    return displayLabels.map((x) => optionField[x]).join(" ");
  };

  useEffect(() => {
    if (value) {
      const val = value[outputValue] ?? value;
      setCurrentValue(val);
      onChange(val);
    }
  }, [value]);

  const handleSelectChange = (newValue) => {
    const val = newValue[outputValue] ?? newValue;
    setCurrentValue(newValue);
    onChange(val);
  };

  const optionsList = () => {
    const list = [];

    selectOptions?.map((optionField) => {
      const value = optionField[outputValue] ?? optionField;
      const label = labels(optionField);
      const currentColor =
        optionField[outputValue]?.color ?? optionField?.color;
      const labelColor = color.find((x) => x.color === currentColor);
      list.push({ value, label, color: labelColor?.color });
    });

    if (asyncOptions?.type === "quiz") {
      const filteredList = list.filter(
        (item) => !["EXAM", "CAPSTONE"].includes(item.label)
      );
      return filteredList;
    } else if (asyncOptions?.type === "feedback") {
      const filteredList = list.filter(
        (item) => !["FINAL"].includes(item.label)
      );
      return filteredList;
    } else {
      return list;
    }
  };

  return (
    <Select
      loading={fetchIsLoading}
      disabled={fetchIsLoading}
      value={currentValue}
      onChange={handleSelectChange}
      placeholder={placeholder}
      mode={mode ? mode : ""}
      showSearch={false}
      filterOption={(input, option) =>
        option && option?.key?.toLowerCase().indexOf(input.toLowerCase()) >= 0
      } // Case-insensitive search
    >
      {optionsList()?.map((option) => {
        return (
          <Select.Option
            key={option.label} // Ensure unique keys
            value={topicentity ? option.value.name : option.value.id}
          >
            <Tag bordered={false}>{option.label}</Tag>
          </Select.Option>
        );
      })}
    </Select>
  );
};

export default SelectAsyncFetch;
