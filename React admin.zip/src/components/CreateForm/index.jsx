import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { selectCreatedItem } from "@/redux/crud/selectors";
import { selectReadItem } from "@/redux/crud/selectors";
import { selectReadItem as readItems } from "@/redux/adavancedCrud/selectors";
import { selectDeletedItem } from "@/redux/adavancedCrud/selectors";
import { selectListItems as listItem } from "@/redux/adavancedCrud/selectors";

import useLanguage from "@/locale/useLanguage";
import { Button, Form, message } from "antd";
import Loading from "@/components/Loading";
import { selectCreatedItem as items } from "@/redux/adavancedCrud/selectors";
import {
  convertDateFormat,
  convertDateFormatReverse,
  convertMinutesFormat,
  convertTimeFormat,
} from "@/utils/helpers";
import { selectCurrentItem as currItem } from "@/redux/crud/selectors";
import { fields } from "@/pages/Company/config";
import isMobilePhone from "@/utils/isMobilePhone";

export default function CreateForm({
  config,
  formElements,
  withUpload = false,
  onUpdateFormValues,
}) {
  let { customizeConfigParameters } = config;
  let { listEntity, createEntity, updateEntity } = config.entities;
  const dispatch = useDispatch();
  const { isLoading, isSuccess } = useSelector(selectCreatedItem);
  const { result } = useSelector(items);
  const { current, isLoading: isLoadingValue } = useSelector(selectReadItem);
  const { result: questionResult } = useSelector(currItem);
  const { current: meetResult } = useSelector(readItems);
  const { current: selectedMode } = useSelector(selectDeletedItem);
  const { result: lis } = useSelector(listItem);

  const [tempArray, setTempArray] = useState([]);
  const [tempContentArray, setTempContentArray] = useState([]);
  const [questionArray, setQuestionArray] = useState([]);

  const { crudContextAction } = useCrudContext();
  const { panel, collapsedBox, readBox } = crudContextAction;
  const [form] = Form.useForm();
  const translate = useLanguage();
  const [formValues, setFormValues] = useState({});
  const titleErrorMessage = translate("title_can_only_be_Aplha_Numeric");
  const facultyErrorMessage = translate(
    "primary_faculty_and_secondary_faculty_must_be_different"
  );
  const questionDataErrorMessage = translate(
    "questions_data_should_not_be_empty"
  );
  const descriptionErrorMessage = translate(
    "description_can_only_be_Aplha_Numeric"
  );

  const phoneNumberInvalidMessage = translate("phone_number_is_invalid");

  const onFormValuesChange = (changedValues, allValues) => {
    // Update the form values state whenever form values change
    setFormValues(allValues);

    // Call the callback function to pass form values up to the parent component
    onUpdateFormValues(allValues);
  };

  const onSubmit = (fieldsValue) => {
    // Manually trim values before submission

    for (let field in config.fields) {
      if (
        config.fields[field].type === "date" &&
        config.fields[field].reverseFormat === true
      ) {
        const date = convertDateFormatReverse(fieldsValue[field]);

        fieldsValue[field] = date;
      }
      if (
        config.fields[field].type === "date" &&
        config.fields[field].reverseFormat === false
      ) {
        const date = convertDateFormat(fieldsValue[field]);

        fieldsValue[field] = date;
      }

      if (field == "startTime" && config.fields["startTime"].type === "time") {
        const time = convertTimeFormat(fieldsValue[field]);
        fieldsValue[field] = time;
      }

      if (field == "endTime" && config.fields["endTime"].type === "time") {
        const time = convertTimeFormat(fieldsValue[field]);
        fieldsValue[field] = time;
      }
      if (
        field == "minutesField" &&
        config.fields["minutesField"].type === "minutes"
      ) {
        const minutes = convertMinutesFormat(fieldsValue[field]);
        fieldsValue[field] = minutes;
      }
    }

    if (fieldsValue.file && withUpload) {
      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }

    //for session meeting url
    else if (config.fields?.meetingMode?.name == "meetingMode") {
      const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
        acc[key] = fieldsValue[key];

        const stringResult = Object.values(selectedMode).join("");

        if (key === "meetingMode") {
          // Check if the meetingMode field exists and its value is "meetingMode"
          // Append questionResult values
          acc.meetingStartUrl = meetResult.meetingStartUrl;
          acc.meetingUrl = meetResult.meetingUrl;
          acc.meetingPlatform = stringResult.toLowerCase();
          acc.status = "SCHEDULED";
        }
        acc[key] =
          typeof fieldsValue[key] === "string"
            ? fieldsValue[key].trim()
            : fieldsValue[key];
        if (key === "content") {
          acc[key] = tempContentArray;
        }

        return acc;
      }, {});

      dispatch(
        crud.create({
          listEntity,
          createEntity,
          jsonData: trimmedValues,
          withUpload,
          customizeConfigParameters,
        })
      );
    }

    //for content creation
    else if (
      config?.fields?.content?.name == "content" &&
      config?.fields?.resources?.name != "resources"
    ) {
      const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
        acc[key] =
          typeof fieldsValue[key] === "string"
            ? fieldsValue[key].trim()
            : fieldsValue[key];
        if (key === "content") {
          acc[key] = tempContentArray;
        }
        return acc;
      }, {});

      if (trimmedValues.primaryFacultyId !== trimmedValues.secondaryFacultyId) {
        dispatch(
          crud.create({
            listEntity,
            createEntity,
            jsonData: trimmedValues,
            withUpload,
            customizeConfigParameters,
          })
        );
      } else {
        message.error(facultyErrorMessage);
      }
    }
    //for resources creation
    else if (
      config?.fields?.resources?.name == "resources" &&
      config?.fields?.content?.name != "content"
    ) {
      const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
        acc[key] =
          typeof fieldsValue[key] === "string"
            ? fieldsValue[key].trim()
            : fieldsValue[key];
        if (key === "resources") {
          acc[key] = tempArray;
        }
        return acc;
      }, {});
      const isNumericTitle = /^[0-9]+$/.test(trimmedValues.title);

      if (isNumericTitle) {
        message.error(titleErrorMessage);
      } else {
        dispatch(
          crud.create({
            listEntity,
            createEntity,
            jsonData: trimmedValues,
            withUpload,
            customizeConfigParameters,
          })
        );
      }
    } else if (
      config?.fields?.resources?.name != "resources" &&
      config?.fields?.content?.name != "content"
    ) {
      const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
        acc[key] =
          typeof fieldsValue[key] === "string"
            ? fieldsValue[key].trim()
            : fieldsValue[key];
        if (key === "Questions") {
          delete acc.Questions;
          acc["questionData"] = questionArray;
        }
        return acc;
      }, {});
      if (createEntity === "/quiz" && updateEntity !== "/capstone") {
        if (
          config?.ENTITY_NAME == "Exam" &&
          trimmedValues?.questionData.length == 0
        ) {
          message.error(questionDataErrorMessage);
        }
        const isNumericTitle = /^[0-9]+$/.test(trimmedValues.title);
        const isNumericDescription = /^[0-9]+$/.test(trimmedValues.description);

        if (isNumericTitle) {
          message.error(titleErrorMessage);
        }
        if (isNumericDescription) {
          message.error(descriptionErrorMessage);
        } else {
          const filteredItem = lis?.items.find(
            (item) => item.id === trimmedValues.categoryId
          );
          trimmedValues["type"] = filteredItem.name;
          trimmedValues["quizData"] = {
            title: trimmedValues.title,
            duration: trimmedValues.minutesField,
            description: trimmedValues.description,
            categoryId: trimmedValues.categoryId,
            passingPercentage: trimmedValues.passingPercentage,
          };
          delete trimmedValues.title;
          delete trimmedValues.minutesField;
          delete trimmedValues.description;
          delete trimmedValues.createdOn;
          delete trimmedValues.categoryId;
          delete trimmedValues.passingPercentage,
            dispatch(
              crud.create({
                listEntity,
                createEntity,
                jsonData: trimmedValues,
                withUpload,
                customizeConfigParameters,
              })
            );
        }
      }
      if (updateEntity === "/capstone") {
        if (
          config?.ENTITY_NAME == "Capstone" &&
          trimmedValues?.questionData.length == 0
        ) {
          message.error(questionDataErrorMessage);
        }
        const isNumericTitle = /^[0-9]+$/.test(trimmedValues.title);
        const isNumericDescription = /^[0-9]+$/.test(trimmedValues.description);

        if (isNumericTitle) {
          message.error(titleErrorMessage);
        } else {
          const filteredItem = lis?.items.find(
            (item) => item.id === trimmedValues.categoryId
          );
          trimmedValues["type"] = filteredItem.name;

          trimmedValues["quizData"] = {
            title: trimmedValues.title,
            duration: trimmedValues.minutesField,
            description: trimmedValues.description,
            categoryId: trimmedValues.categoryId,
            totalMarks: trimmedValues.totalMarks,
            totalNumberOfAttempts: trimmedValues.totalNumberOfAttempts,
            totalNumberOfQuestions: trimmedValues.totalNumberOfQuestions,
            passingPercentage: trimmedValues.passingPercentage,
          };
          delete trimmedValues.title;
          delete trimmedValues.minutesField;
          delete trimmedValues.description;
          delete trimmedValues.createdOn;
          delete trimmedValues.categoryId;
          delete trimmedValues.totalMarks,
            delete trimmedValues.totalNumberOfAttempts,
            delete trimmedValues.totalNumberOfQuestions,
            delete trimmedValues.passingPercentage,
            dispatch(
              crud.create({
                listEntity,
                createEntity,
                jsonData: trimmedValues,
                withUpload,
                customizeConfigParameters,
              })
            );
        }
      }
      if (createEntity === "/feedback") {
        const updatedQuestionDataToAddOrder = trimmedValues?.questionData.map(
          (question, index) => ({
            ...question,
            order: index,
          })
        );
        const updatedQuestionDataToFilterText =
          updatedQuestionDataToAddOrder.map((item) => {
            if (item.questionType === "Text") {
              return { ...item, options: [] };
            }
            return item;
          });

        trimmedValues["questionData"] = updatedQuestionDataToFilterText;
        trimmedValues["feedbackData"] = {
          title: trimmedValues.title,
          duration: trimmedValues.minutesField,
          description: trimmedValues.description,
          categoryId: trimmedValues.categoryId,
        };

        delete trimmedValues.title;
        delete trimmedValues.minutesField;
        delete trimmedValues.description;
        delete trimmedValues.createdOn;
        delete trimmedValues.categoryId;

        dispatch(
          crud.create({
            listEntity,
            createEntity,
            jsonData: trimmedValues,
            withUpload,
            customizeConfigParameters,
          })
        );
      } else if (
        (trimmedValues.title !== undefined ||
          trimmedValues.description !== undefined) &&
        createEntity !== "/quiz" &&
        updateEntity !== "/capstone"
      ) {
        const isNumericTitle = /^[0-9]+$/.test(trimmedValues.title);
        const isNumericDescription = /^[0-9]+$/.test(trimmedValues.description);

        if (isNumericTitle) {
          message.error(titleErrorMessage);
        }
        if (isNumericDescription) {
          message.error(descriptionErrorMessage);
        } else {
          dispatch(
            crud.create({
              listEntity,
              createEntity,
              jsonData: trimmedValues,
              withUpload,
              customizeConfigParameters,
            })
          );
        }
      } else if (
        ((config?.ENTITY_NAME == "Teacher" ||
          config?.ENTITY_NAME == "Srmuserlist" ||
          config?.ENTITY_NAME == "Admin" ||
          config?.ENTITY_NAME == "Student") &&
          trimmedValues["timezone"] != "") ||
        trimmedValues["timezone"] != undefined
      ) {
        trimmedValues["timezone"] = trimmedValues["timeZone"];
        delete trimmedValues["timeZone"];
        const mobileNumberWithDialCode =
          trimmedValues?.dialCode + trimmedValues?.mobile;
        const isPhoneNumberCorrect = isMobilePhone(mobileNumberWithDialCode);
        if (!isPhoneNumberCorrect) {
          message.error(phoneNumberInvalidMessage);
        } else {
          dispatch(
            crud.create({
              listEntity,
              createEntity,
              jsonData: trimmedValues,
              withUpload,
              customizeConfigParameters,
            })
          );
        }
      } else if (createEntity != "/quiz" && updateEntity !== "/capstone") {
        dispatch(
          crud.create({
            listEntity,
            createEntity,
            jsonData: trimmedValues,
            withUpload,
            customizeConfigParameters,
          })
        );
      }
    } else {
      dispatch(
        crud.create({
          listEntity,
          createEntity,
          jsonData: trimmedValues,
          withUpload,
          customizeConfigParameters,
        })
      );
    }
  };

  useEffect(() => {
    if (result?.id) {
      setTempArray((prevResources) => [...prevResources, result.id]);
      setTempContentArray((prevResources) => [
        ...prevResources,

        { contentType: "PRE_SESSION", contentIds: [result.id] },
      ]);
    }
  }, [result]);

  useEffect(() => {
    // Ensure `current` is an object and has the `index` property
    if (
      current &&
      typeof current === "object" &&
      current.hasOwnProperty("index")
    ) {
      // Remove the resource at the specified index
      setTempArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
      setTempContentArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      // readBox.open();
      if (config?.fields?.resources?.name == "resources") {
        setTempArray([]);
      } else if (config?.fields?.content?.name == "content") {
        setTempContentArray([]);
      }
      setQuestionArray([]);
      readBox.close();
      collapsedBox.close();
      // collapsedBox.open();
      panel.close();
      // panel.open();
      form.resetFields();
      dispatch(crud.resetAction({ actionType: "create" }));
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
  }, [isSuccess]);

  useEffect(() => {
    if (questionResult != null && questionResult.questions?.length == 0) {
      setQuestionArray([]);
    } else if (
      questionResult != null &&
      questionResult.questions?.length >= 1
    ) {
      const updatedArray = [...questionResult?.questions];
      setQuestionArray(updatedArray);
    } else if (
      questionResult?.categoryId &&
      questionResult.editQuestionIndex != -1
    ) {
      questionArray.splice(questionResult.editQuestionIndex, 1, questionResult);
      setQuestionArray(questionArray);
    } else {
      if (config?.PANEL_TITLE === "Feedback") {
        if (questionResult?.questionCategoryId) {
          setQuestionArray((prevQuestion) => [...prevQuestion, questionResult]);
        }
      } else {
        if (questionResult?.categoryId) {
          setQuestionArray((prevQuestion) => [...prevQuestion, questionResult]);
        }
      }
    }
  }, [questionResult]);
  return (
    <Loading isLoading={isLoading}>
      <Form
        form={form}
        onValuesChange={onFormValuesChange} // Add onValuesChange prop
        layout="vertical"
        onFinish={onSubmit}
      >
        {formElements}

        <Form.Item>
          <Button type="primary" htmlType="submit">
            {translate("Submit")}
          </Button>
        </Form.Item>
      </Form>
    </Loading>
  );
}
