import React, { useState, useEffect } from "react";
import { request } from "@/request";
import useFetch from "@/hooks/useFetch";
import { Form, Select, Tag } from "antd";
import { useNavigate } from "react-router-dom";
import { generate as uniqueId } from "shortid";
import color from "@/utils/color";
import { countryList } from "@/utils/countryList";
import moment from "moment-timezone"; // Import timezone library
import useLanguage from "@/locale/useLanguage";
import ct from "countries-and-timezones";

const SelectForDynamicTimeZoneOption = (fieldName) => {
  const {
    entity,
    displayLabels = ["name"],
    outputValue = "name",
    redirectLabel = "",
    withRedirect = false,
    urlToRedirect = "/",
    onChange,
    asyncOptions = {},
    responseInner = "",
    mode,
  } = fieldName;
  const { value } = fieldName.value;
  const { placeholder } = fieldName.placeholder;

  const [selectOptions, setOptions] = useState([]);
  const [newSelectOptions, setNewSelectOptions] = useState([]);
  const [currentValue, setCurrentValue] = useState(undefined);
  const [newVlaue, setNewValue] = useState(undefined);
  const [showAdditionalDropdown, setShowAdditionalDropdown] = useState(false);
  const navigate = useNavigate();
  const asyncList = () => {
    const resp = request.list({ listEntity: entity, options: asyncOptions });
    return resp;
  };
  const translate = useLanguage();
  const countryCode = moment.tz(fieldName.value).zoneAbbr();
  const timezoneInfo = ct.getTimezone(fieldName.value);
  const countryCodeNew = timezoneInfo?.countries[0];

  useEffect(() => {
    if (fieldName?.value != "") {
      setShowAdditionalDropdown(true);
    }
  }, []);

  useEffect(() => {
    if (value) {
      const val = value[fieldName?.outputValue] ?? value;
      setCurrentValue(val);
      onChange(val);
    }
  }, [value]);

  const handleSelectChange = (newValue) => {
    setCurrentValue(newValue);
    setShowAdditionalDropdown(true);
  };

  const handleForNewValueChange = (selectedNewValue) => {
    const val = selectedNewValue[fieldName?.outputValue] ?? selectedNewValue;
    setNewValue(selectedNewValue);
    onChange(val);
  };

  const optionsList = () => {
    const list = selectOptions?.map((optionField) => {
      const value = optionField[outputValue] ?? optionField;
      const label = displayLabels.map((x) => optionField[x]).join(" ");
      const currentColor =
        optionField[outputValue]?.color ?? optionField?.color;
      const labelColor = color.find((x) => x.color === currentColor);
      return { value, label, color: labelColor?.color };
    });
    return list;
  };

  const newOptionList = () => {
    const list =
      newSelectOptions &&
      newSelectOptions?.map((optionField) => {
        const value = optionField[outputValue] ?? optionField;
        const label = displayLabels.map((x) => optionField[x]).join(" ");
        const currentColor =
          optionField[outputValue]?.color ?? optionField?.color;
        const labelColor = color.find((x) => x.color === currentColor);
        return { value, label, color: labelColor?.color };
      });
    return list;
  };

  const handleCountrySelect = (countryCode) => {
    // Fetch timezones for the selected country
    const timezones = moment.tz.zonesForCountry(countryCode);
    setNewSelectOptions(timezones.map((tz) => ({ id: tz, title: tz })));
  };
  return (
    <div>
      <Select
        defaultValue={countryCodeNew}
        onChange={handleSelectChange}
        placeholder={fieldName?.placeholder}
        onSelect={handleCountrySelect}
        showSearch
        optionFilterProp="children"
        filterOption={(input, option) =>
          option.label?.toLowerCase().includes(input.toLowerCase())
        }
        filterSort={(optionA, optionB) =>
          optionA.label
            ?.toLowerCase()
            ?.localeCompare(optionB.label.toLowerCase())
        }
        style={{ width: "100%" }} // Adjust width as needed
      >
        {/* Render country list options */}
        {countryList.map((country) => (
          <Select.Option
            key={country.code}
            value={country.code}
            label={`${country.flag ?? ""} ${country.name} ${country.code}`}
          >
            {country.flag && country.flag + " "}( {country.name}{" "}
            {country.dial_code} )
          </Select.Option>
        ))}
        {/* Render other options */}
        {optionsList()?.map((option) => (
          <Select.Option key={`${uniqueId()}`} value={option.value.id}>
            <Tag bordered={false}>{option.label}</Tag>
          </Select.Option>
        ))}
      </Select>
      {showAdditionalDropdown && (
        <Form.Item label="Timezone" style={{ marginTop: 16 }} required>
          <Select
            defaultValue={fieldName?.value}
            value={newVlaue}
            placeholder={translate("Select timezone")}
            onChange={handleForNewValueChange}
            mode={fieldName?.mode ? fieldName.mode : ""}
            style={{ width: "100%" }} // Adjust width as needed
          >
            {newSelectOptions.map((option) => (
              <Select.Option key={option.id} value={option.id}>
                {option.title}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
      )}
    </div>
  );
};

export default SelectForDynamicTimeZoneOption;
