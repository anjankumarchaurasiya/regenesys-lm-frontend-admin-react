import React, { useEffect, useState } from "react";
import { Tabs, Row, Col } from "antd";

const { TabPane } = Tabs;

const SettingsLayout = ({ children, isStyled, tabKey, onTabSelected }) => {
  useEffect(() => {
    if (onTabSelected) {
      onTabSelected(tabKey);
    }
  }, [onTabSelected, tabKey]);
  return (
    <>
      {tabKey !== "session" &&
        tabKey !== "students" &&
        tabKey !== "quiz" &&
        tabKey !== "exam" &&
        tabKey !== "capstone" &&
        tabKey !== "session" &&
        tabKey !== "final" && (
          <Col className="gutter-row" order={0}>
            <div
              className={`whiteBox  mrgt30 shadow ${
                isStyled ? "styledLayout" : ""
              }`}
              style={{ minHeight: "480px" }}
            >
              <div className="pad40">{children}</div>
            </div>
          </Col>
        )}

      {(tabKey === "session" ||
        tabKey === "students" ||
        tabKey === "quiz" ||
        tabKey === "exam" ||
        tabKey === "session" ||
        tabKey === "final" ||
        tabKey === "capstone") && <div>{children}</div>}
    </>
  );
};

export default function TabsContent({ content, defaultActiveKey, pageTitle }) {
  const [activeKey, setActiveKey] = useState(defaultActiveKey);
  const [tabData, setTabData] = useState({});

  const handleTabSelected = (key) => {
    // Fetch data or perform actions for the selected tab
    // Set the data for the tab
    // Example: setTabData({ ...tabData, [key]: newData });
  };

  const onTabChange = (key) => {
    setActiveKey(key);

    handleTabSelected(key);

    const searchParams = new URLSearchParams();
    searchParams.append("tab", key);

    // window.history.replaceState(null, null, `?${searchParams.toString()}`);
  };

  const items = content.map((item, index) => {
    return {
      key: item.key ? item.key : index + "_" + item.label.replace(/ /g, "_"),
      label: (
        <div className="d-flex align-items-center tab-content-wrapper">
          {item.icon} <span>{item.label}</span>
        </div>
      ),
      children: (
        <SettingsLayout
          isStyled={item.key !== "session"}
          tabKey={item.key}
          key={item.key}
          onTabSelected={handleTabSelected}
        >
          {React.cloneElement(item.children, { tabData: tabData[item.key] })}
        </SettingsLayout>
      ),
    };
  });

  return (
    <Row className="tabContent">
      <Col span={24}>
        <Tabs
          destroyInactiveTabPane={true}
          tabPosition="top"
          onChange={onTabChange}
          activeKey={activeKey}
          hideAdd={true}
          items={items}
          className="ant-tabs-ink-bar"
        />
      </Col>
    </Row>
  );
}
