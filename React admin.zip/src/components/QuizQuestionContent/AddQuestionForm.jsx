import React, { useState, useEffect } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  InputNumber,
  message,
  Space,
  Tooltip,
  Radio,
} from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import TrainingResourcesButton from "../TrainingResourcesButton";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import {
  selectListItems as listItem,
  selectReadItem,
} from "@/redux/crud/selectors";
import { selectCreatedItem as itemsResource } from "@/redux/adavancedCrud/selectors";
import { advancedCrud } from "@/redux/adavancedCrud/actions";
import SelectAsyncFetch from "@/components/SelectAsyncFetch";
import { erp } from "@/redux/erp/actions";
import { selectListItems } from "@/redux/erp/selectors";

const { Option } = Select;
const { TextArea } = Input;

const AddQuestionForm = ({
  onAddQuestion,
  onCancel,
  editData,
  mediaEditFlag,
  editQuestionIndex,
}) => {
  const [options, setOptions] = useState([
    { label: "Option 1", value: "", correct: false, order: "A" },
  ]);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [tempArray, setTempArray] = useState([]);
  const [contentArray, setContentArray] = useState([]);

  const dispatch = useDispatch();
  const handleUploadComplete = (fileName) => {
    setUploadedFiles([...uploadedFiles, fileName]);
  };
  const [form] = Form.useForm();
  const {
    result: { items },
  } = useSelector(selectListItems);

  const [questionData, setQuestionData] = useState({
    questionType: "",
    question: "",
    points: 1,
    attachMedia: "",
    createAnswer: options,
    topic: "",
    description: "",
  });
  const { result: resourceContent } = useSelector(itemsResource);
  const { current, isLoading: isLoadingValue } = useSelector(selectReadItem);
  useEffect(() => {
    if (resourceContent?.id) {
      setTempArray((prevTemArray) => [...prevTemArray, resourceContent?.id]);
      setContentArray([...contentArray, resourceContent]);
    }
  }, [resourceContent]);

  useEffect(() => {
    if (
      current &&
      typeof current === "object" &&
      current.hasOwnProperty("index")
    ) {
      setTempArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
      setContentArray((prevResources) =>
        prevResources.filter((_, index) => index !== current.index)
      );
    }
  }, [current]);

  useEffect(() => {
    if (editData) {
      const options = editData.question_options.map((option, index) => ({
        label: `Option ${index + 1}`,
        value: option.option,
        correct: option.isCorrectOption,
      }));
      setOptions(options);

      const correctOption = editData.question_options.find(
        (option) => option.isCorrectOption
      );

      form.setFieldsValue({
        questionType: "MCQ",
        question: editData.question ?? "",
        points: editData?.quiz_question?.points
          ? editData?.quiz_question?.points
          : editData.point,
        attachMedia: editData?.attachMedia ?? "",
        createAnswer: editData.question_options,
        topic: editData.topic ?? "",
        description: correctOption?.description ?? "",
      });
    }
  }, [editData, form]);

  useEffect(() => {
    if (!!editData) {
      const correctOption = editData.question_options.find(
        (option) => option.isCorrectOption
      );
      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: options,
        question: editData?.question ?? "",
        points: editData?.quiz_question?.points
          ? editData?.quiz_question?.points
          : editData.point,
        attachMedia: editData?.attachMedia ?? "",
        topic: editData?.topic ?? "",
        description: correctOption?.description ?? "",
      }));
      const contents = editData?.question_content
        ? editData?.question_content
        : editData?.question_contents.map((content) => content.content);
      const contentsIds = editData.content
        ? editData.content
        : editData.question_contents.map((content) => content.content.id);

      setContentArray(contents);
      setTempArray(contentsIds);
    }
  }, [editData]);

  useEffect(() => {
    if (options.length > 0 && !!editData) {
      const updatedContentArray = [...contentArray];
      const updatedTempArray = [...tempArray];

      updatedContentArray.push(/* newly uploaded media */);
      updatedTempArray.push(/* corresponding ID */);

      setContentArray(updatedContentArray);
      setTempArray(updatedTempArray);
    }
  }, [options]);

  const onFinish = () => {
    const isNumericQuestion = /^[0-9]+$/.test(questionData.question);
    if (isNumericQuestion) {
      message.error("Question can only be Aplha-Numeric");
    } else {
      message.success("Question added successfully");

      if (onAddQuestion) {
        onAddQuestion({
          data: {
            question: questionData.question,
            categoryId: items.filter((item) => item.name === "QUIZ_QUESTION")[0]
              ?.id,
            point: questionData.points,
            question_options: questionData.createAnswer.map((item, index) => ({
              option: item.value,
              isCorrectOption: item.correct,
              description: item.correct ? questionData.description : "null",
              order: String.fromCharCode(65 + index),
            })),
            question_type: questionData.questionType,
            content: tempArray,
            question_content: contentArray,
          },
        });
        dispatch(
          crud.currentItem({
            data: {
              question: questionData.question,

              categoryId: items.filter(
                (item) => item.name === "QUIZ_QUESTION"
              )[0]?.id,
              point: questionData.points,
              options: questionData.createAnswer.map((item, index) => ({
                option: item.value,
                isCorrectOption: item.correct,
                description: item.correct ? questionData.description : "null",
                order: String.fromCharCode(65 + index),
              })),
              question_type: questionData.questionType,
              content: tempArray,
              question_content: contentArray,
              editQuestionIndex:
                editQuestionIndex != null ? editQuestionIndex : -1,
            },
          })
        );
      }

      if (onCancel) {
        onCancel();
      }

      setOptions([
        { label: "Option 1", value: "", correct: false, order: "A" },
      ]);
      setTempArray([]);
      setContentArray([]);
      dispatch(advancedCrud.resetAction({ actionType: "create" }));
      form.resetFields();
    }
  };

  useEffect(() => {
    if (!editData) {
      form.resetFields();
      setOptions([{ label: "Option 1", value: "", order: "0" }]);
    }
  }, [editData]);

  const handleCancel = () => {
    if (editData?.length > 0) {
      if (onCancel) {
        setOptions([
          { label: "Option 1", value: "", correct: false, order: "A" },
        ]);
        setTempArray([]);
        setContentArray([]);
        dispatch(advancedCrud.resetAction({ actionType: "create" }));
        form.resetFields();
        onCancel();
      }
    }
  };

  const addOption = () => {
    if (options.length < 6) {
      const order = String.fromCharCode(65 + options.length); // Convert index to alphabetical letter
      setOptions([
        ...options,
        {
          label: `Option ${options.length + 1}`,
          value: "",
          correct: false,
          order: order,
        },
      ]);

      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: [
          ...prevData.createAnswer,
          {
            label: `Option ${options.length + 1}`,
            value: `Option ${options.length + 1}`,
            correct: false,
            order: order,
          },
        ],
      }));
    }
  };

  const deleteOption = (index) => {
    if (options.length > 1) {
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);

      setQuestionData((prevData) => ({
        ...prevData,
        createAnswer: newOptions,
      }));
    }
  };

  const handleRadioChange = (index) => {
    const updatedOptions = options.map((opt, i) => ({
      ...opt,
      correct: i === index,
    }));
    setOptions(updatedOptions);

    setQuestionData((prevData) => ({
      ...prevData,
      createAnswer: updatedOptions,
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setQuestionData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handlePointsChange = (value) => {
    if (!isNaN(value)) {
      // Check if value is a number
      setQuestionData((prevData) => ({
        ...prevData,
        points: value,
      }));
    }
  };

  useEffect(() => {
    // Disable the "More Options" button when the number of options is 6
    if (options.length >= 6) {
      form.setFieldsValue({ moreOptionsDisabled: true });
    }
  }, [options, form]);

  useEffect(() => {
    const listEntity = "/category/filter/list";
    const options = {
      type: "question",
    };
    const customizeConfigParameters = {
      responseInnerObj: "category",
      params: "recordStatus=true",
    };

    dispatch(erp.list({ listEntity, options, customizeConfigParameters }));
  }, []);

  return (
    <Form
      form={form}
      layout="vertical"
      name="add-question-form"
      onFinish={onFinish}
    >
      <Form.Item
        label="Question Type"
        name="questionType"
        rules={[{ required: true, message: "Please select a question type" }]}
      >
        <Select
          onChange={(value) =>
            handleInputChange({ target: { name: "questionType", value } })
          }
        >
          <Option value="MCQ">MCQ</Option>
        </Select>
      </Form.Item>

      <Form.Item
        label="Question"
        name="question"
        rules={[{ required: true, message: "Please enter a question" }]}
      >
        <TextArea
          onChange={(e) =>
            handleInputChange({
              target: { name: "question", value: e.target.value },
            })
          }
        />
      </Form.Item>

      <Form.Item
        label="Points"
        name="points"
        rules={[
          { required: true },
          ({ getFieldValue }) => ({
            validator(_, value) {
              if (value >= 1 && value <= 100) {
                return Promise.resolve();
              }
              // Return undefined to suppress the default error message
              return Promise.reject();
            },
          }),
        ]}
      >
        <Input
          className="col-3"
          type="number"
          min="1"
          max="100"
          pattern="[0-9]*" // Only allows numeric input
          onChange={(e) => handlePointsChange(e.target.value)}
        />
      </Form.Item>

      <Form.Item className="ml-5" label="Attach Media" name="attachMedia">
        <TrainingResourcesButton
          onComplete={handleUploadComplete}
          entityName={"QUIZQUESTION"}
          uploadedData={contentArray}
          editData={editData}
          mediaEditFlag={mediaEditFlag}
        />
      </Form.Item>

      <Form.Item
        name="createAnswer"
        rules={[{ required: false, message: "Answer is Necessary" }]}
      >
        <p>
          <span className="required_mark">* </span>Create Answer
        </p>
        {/* {options.map((option, index) => (
          <Space className="mb-2" key={index}>
            <DeleteOutlined
              className="delete-icon"
              onClick={() => deleteOption(index)}
            />
            <Input
              required="true"
              placeholder={`Option ${index + 1}`}
              value={option.value}
              onChange={(e) => {
                const updatedOptions = [...options];
                updatedOptions[index].value = e.target.value;
                setOptions(updatedOptions);

                setQuestionData((prevData) => ({
                  ...prevData,
                  createAnswer: updatedOptions,
                }));
              }}
            />

            <Form.Item
              name="Correct Answer"
              rules={[
                {
                  required: false,
                  message: "Please choose one Correct Answer",
                },
              ]}
            >
              <div className="mt-2 ">
                <Radio
                  value={index}
                  checked={option.correct}
                  onChange={() => handleRadioChange(index)}
                >
                  Correct
                </Radio>
              </div>
            </Form.Item>
          </Space>
        ))} */}
        {options.map((option, index) => (
          <Space className="mb-2" key={index}>
            <div className="option-label">
              {String.fromCharCode(65 + index)} -
            </div>{" "}
            {/* Display alphabet letter */}
            <Input
              required="true"
              placeholder={`Option ${index + 1}`} // Placeholder remains the same
              value={option.value}
              onChange={(e) => {
                const updatedOptions = [...options];
                updatedOptions[index].value = e.target.value;
                setOptions(updatedOptions);

                setQuestionData((prevData) => ({
                  ...prevData,
                  createAnswer: updatedOptions,
                }));
              }}
            />
            <DeleteOutlined
              className="delete-icon"
              onClick={() => deleteOption(index)}
            />
            <Form.Item
              name="Correct Answer"
              rules={[
                {
                  required: false,
                  message: "Please choose one Correct Answer",
                },
              ]}
            >
              <div className="mt-2 ">
                <Radio
                  value={index}
                  checked={option.correct}
                  onChange={() => handleRadioChange(index)}
                >
                  Correct
                </Radio>
              </div>
            </Form.Item>
          </Space>
        ))}
        <div>
          <Form.Item name="moreOptionsDisabled" noStyle initialValue={false}>
            <Button
              disabled={options.length >= 6}
              type="dashed"
              onClick={addOption}
              icon={<PlusOutlined />}
            >
              More Options
            </Button>
          </Form.Item>
        </div>
      </Form.Item>

      <p className="mt-3">Recommended Topic/Module of correct answer</p>

      <Form.Item
        label="Description"
        name="description"
        rules={[{ required: true, message: "Please enter a description" }]}
      >
        <TextArea
          onChange={(e) =>
            handleInputChange({
              target: { name: "description", value: e.target.value },
            })
          }
        />
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit">
          Save
        </Button>
      </Form.Item>
    </Form>
  );
};

export default AddQuestionForm;
