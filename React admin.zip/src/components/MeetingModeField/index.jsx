import React, { useEffect, useState } from "react";
import { Input, Button, Select } from "antd";
import { crud } from "@/redux/crud/actions";
import SelectAsyncFetch from "../SelectAsyncFetch";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { useDispatch, useSelector } from "react-redux";
import { selectMeetingUrlItems } from "@/redux/crud/selectors";
import { advancedCrud } from "@/redux/adavancedCrud/actions";

const { Option } = Select;

const MeetingModeField = ({ trimmedValues, updateTrimmedValues }) => {
  const [selectedMode, setSelectedMode] = useState("");
  const [startMeetingUrl, setStartMeetingUrl] = useState("");
  const [joinMeetingUrl, setJoinMeetingUrl] = useState("");
  const [sessionData, setSessionData] = useState({});
  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);

  const {
    result,
    current: cur,
    isLoading: listIsLoading,
  } = useSelector(selectMeetingUrlItems);

  useEffect(() => {
    setStartMeetingUrl(result?.startUrl);
    setJoinMeetingUrl(result?.meetingUrl);
    const meetdata = {
      mode: selectedMode?.toLowerCase(),
      meetingStartUrl: result?.startUrl,
      meetingUrl: result?.meetingUrl,
    };

    dispatch(
      advancedCrud.currentAction({ actionType: "read", data: meetdata })
    );
  }, [result]);

  const dispatch = useDispatch();

  useEffect(() => {
    setSessionData(trimmedValues);
  }, [trimmedValues]);

  const handleGenerateUrl = () => {
    const startTime = new Date(current?.startTime);
    const endTime = new Date(current?.endTime);

    // Calculate the difference in milliseconds
    const differenceInMilliseconds = endTime - startTime;

    // Convert milliseconds to minutes
    const durationInMinutes = differenceInMilliseconds / (1000 * 60);

    const formattedDate = current?.date.split("T")[0];
    const formattedstartTime = new Date(current?.startTime);

    // Get time string in desired format
    const formattedStartTimes = formattedstartTime.toLocaleTimeString([], {
      hour12: false,
    });

    const authData = JSON.parse(window?.localStorage?.auth);

    const data = {
      topic: current?.title,
      startTime: formattedStartTimes,
      date: formattedDate,
      duration: parseInt(durationInMinutes),
      platform: selectedMode.toLowerCase(),
      timezone: authData?.current?.timezone,
    };

    const customizeUrl = "/meeting" + "/create-meeting";
    const dataObject = data;
    dispatch(crud.meetingurl({ customizeUrl, dataObject }));

    dispatch(
      advancedCrud.currentAction({
        actionType: "delete",
        data: selectedMode,
      })
    );
  };

  const handleMeetingPlatformChange = (selectedValue) => {
    setSelectedMode(selectedValue);
  };

  return (
    <div>
      <SelectAsyncFetch
        entity={"/category/filter/list"}
        displayLabels={["name"]}
        outputValue={"label"}
        asyncOptions={{
          type: "meeting platform",
        }}
        responseInner={"category"}
        placeholder={"Meeting Mode"}
        onChange={handleMeetingPlatformChange}
        topicentity={true}
      ></SelectAsyncFetch>
      <div>
        <Button
          className="meeting-buttons"
          loading={listIsLoading}
          onClick={() => handleGenerateUrl()}
        >
          Generate URL
        </Button>
      </div>
      <div>
        <div className="meeting-buttons">
          <label htmlFor="startMeetingURL">Start Meeting URL:</label>
          <Input
            id="startMeetingURL"
            value={startMeetingUrl}
            disabled
            placeholder="Start Meeting URL"
            className="mt-2"
          />
        </div>
        <div className="meeting-buttons">
          <label htmlFor="joinMeetingURL">Join Meeting URL:</label>
          <Input
            id="joinMeetingURL"
            value={joinMeetingUrl}
            disabled
            placeholder="Join Meeting URL"
            className="mt-2"
          />
        </div>
      </div>
    </div>
  );
};

export default MeetingModeField;
