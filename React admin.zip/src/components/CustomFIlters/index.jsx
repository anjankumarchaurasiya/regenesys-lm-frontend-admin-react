import React from "react";
import { useEffect } from "react";
import { Input, Button, Space, Select, Form } from "antd";
import { DatePicker } from "antd";
import dayjs from "dayjs";
import useLanguage from "@/locale/useLanguage";
import SelectAsyncFetchWithChange from "../SelectAsyncFetchWithChange";
import { disabledExamDate } from "@/utils/helpers";
export const DataTableFilter = ({
  onSearch,
  filterFields,
  customizeConfigParameters,
  onRecordStatusChange,
  onLinkedStatusChange,
  filterRef, // Add filterRef prop
}) => {
  const translate = useLanguage();
  const [form] = Form.useForm(); // Initialize the form
  const [searchTerms, setSearchTerms] = React.useState({});
  const [customizeConfigParameter, setCustomizeConfigParameter] =
    React.useState({
      params: customizeConfigParameters ? customizeConfigParameters : "",
    });
  const [datePickerValue, setDatePickerValue] = React.useState(null);
  const handleInputChange = (fieldName, value) => {
    const fieldConfig = filterFields[fieldName];
    if (fieldConfig.type === "selectMultiple") {
      // Get the previously selected values
      const prevSelectedValues = searchTerms[fieldName] || [];

      // If the user is attempting to deselect all options, reset to previous state
      if (value.length === 0) {
        form.setFieldsValue({
          [fieldName]: prevSelectedValues,
        });
        return;
      }

      // Update the selected values
      setSearchTerms((prevSearchTerms) => ({
        ...prevSearchTerms,
        [fieldName]: value,
      }));
    } else if (filterFields[fieldName].type === "date") {
      const formattedDate = value
        ? dayjs(value, "DD/MM/YYYY").format("DD/MM/YYYY")
        : null;
      setSearchTerms((prevSearchTerms) => ({
        ...prevSearchTerms,
        [fieldName]: formattedDate,
      }));
      setDatePickerValue(formattedDate);
    } else {
      setSearchTerms((prevSearchTerms) => ({
        ...prevSearchTerms,
        [fieldName]: value,
      }));
    }
  };
  const handleSearch = () => {
    // Get form values
    const formValues = form.getFieldsValue();
    const recordStatus =
      formValues.recordStatus !== undefined ? formValues.recordStatus : true;
    onRecordStatusChange(recordStatus);
    const linked = formValues.linked !== undefined ? formValues.linked : true;
    onLinkedStatusChange(linked);
    // onLinkedStatusChange(recordStatus);

    // Filter out undefined values
    const filteredFormValues = Object.fromEntries(
      Object.entries(formValues).map(([key, value]) => {
        if (key === "recordStatus" && value === undefined) {
          return [key, true];
        }
        // if (key === "linked" && value === undefined) {
        //   return [key, true];
        // }

        if (key === "createdAt" && value) {
          const formattedDate = dayjs(value).format("DD/MM/YYYY");
          return [key, formattedDate];
        }

        if (key === "examDate" && value) {
          const formattedDate = dayjs(value).format("YYYY-MM-DD");
          return [key, formattedDate];
        }
        return [key, value];
      })
    );
    const queryString = Object.entries(filteredFormValues)
      .map(([key, value]) => `${key}=${value}`)
      .join("&");
    setCustomizeConfigParameter({
      params: queryString,
    });
    onSearch(filteredFormValues);
  };
  const handleReset = () => {
    form.resetFields(); // Reset the form
  };
  useEffect(() => {
    // Assign the reset function to filterRef.current
    filterRef.current = {
      reset: handleReset,
    };
  }, [filterRef]);
  return (
    <Form form={form} initialValues={{}} className="custome-filter-form">
      <Space style={{ marginBottom: 16 }}>
        {Object.keys(filterFields).map((fieldName) => {
          const fieldConfig = filterFields[fieldName];
          return (
            <Form.Item key={fieldName} name={fieldName}>
              {fieldConfig.type === "string" ||
              fieldConfig.type === "email" ||
              fieldConfig.type === "phone" ? (
                <Input
                  size="default"
                  placeholder={fieldConfig?.placeholder}
                  onChange={(e) => handleInputChange(fieldName, e.target.value)}
                  value={searchTerms[fieldName] || ""}
                />
              ) : fieldConfig.type === "date" ? (
                <DatePicker
                  size="default"
                  format={"DD/MM/YYYY"}
                  placeholder={fieldConfig.placeholder || fieldName}
                  onChange={(date, dateString) =>
                    handleInputChange(fieldName, dateString)
                  }
                  value={
                    datePickerValue
                      ? dayjs(datePickerValue, "DD/MM/YYYY")
                      : undefined
                  }
                />
              ) : fieldConfig.type === "select" ? (
                <Select
                  size="default"
                  className={fieldConfig?.className}
                  placeholder={fieldConfig?.placeholder}
                  onChange={(value) => handleInputChange(fieldName, value)}
                  value={
                    searchTerms[fieldName] !== undefined
                      ? searchTerms[fieldName]
                      : undefined
                  }
                  defaultValue={fieldConfig.defaultValue}
                >
                  {fieldConfig.options.map((option) => (
                    <Select.Option key={option.value} value={option.value}>
                      {option.label}
                    </Select.Option>
                  ))}
                </Select>
              ) : fieldConfig.type === "asyncSelectWithChange" ? (
                <>
                  <SelectAsyncFetchWithChange
                    entity={fieldConfig.entity}
                    displayLabels={fieldConfig.displayLabels}
                    outputValue={fieldConfig.outputValue}
                    loadDefault={fieldConfig.loadDefault}
                    withRedirect={fieldConfig.withRedirect}
                    urlToRedirect={fieldConfig.urlToRedirect}
                    redirectLabel={fieldConfig.redirectLabel}
                    asyncOptions={fieldConfig.asyncOptions}
                    responseInner={fieldConfig.responseInner}
                    placeholder={fieldConfig.placeholder}
                    fieldName={fieldName}
                    selectValue={form.getFieldValue(fieldName)}
                    onChange={handleInputChange}
                    form={form}
                    mode={fieldConfig.mode}
                  ></SelectAsyncFetchWithChange>
                </>
              ) : fieldConfig.type === "selectMultiple" ? (
                <Select
                  onInputKeyDown={(e) => e.preventDefault()}
                  defaultValue={fieldConfig.defaultValue}
                  tokenSeparators={[]}
                  mode={fieldConfig.mode}
                  disabled={fieldConfig.disabled}
                  style={{
                    width: "100%",
                  }}
                  size="default"
                  onChange={(value) => handleInputChange(fieldName, value)}
                  showSearch={false}
                >
                  {fieldConfig?.options?.map((option) => {
                    return (
                      <Select.Option key={option.value} value={option.value}>
                        {option.label}
                      </Select.Option>
                    );
                  })}
                </Select>
              ) : fieldConfig.type === "Examdate" ? (
                <DatePicker
                  size="default"
                  format={"DD/MM/YYYY"}
                  placeholder={fieldConfig.placeholder || fieldName}
                  onChange={(date, dateString) =>
                    handleInputChange(fieldName, dateString)
                  }
                  value={
                    datePickerValue
                      ? dayjs(datePickerValue, "DD/MM/YYYY")
                      : undefined
                  }
                  disabledDate={disabledExamDate}
                />
              ) : null}
            </Form.Item>
          );
        })}
        <Button type="primary" size="default" onClick={handleSearch}>
          {translate("Search")}
        </Button>
        {/* <Button size="default" onClick={handleReset}>
          Reset
        </Button> */}
      </Space>
    </Form>
  );
};
