import { useCrudContext } from "@/context/crud";
import useLanguage from "@/locale/useLanguage";
import { crud } from "@/redux/crud/actions";
import {
  selectCreatedItem,
  selectListItems,
  selectUpdatedItem,
} from "@/redux/crud/selectors";
import { useDate, useMoney } from "@/settings";
import { dataForTable } from "@/utils/dataStructure";
import { PageHeader } from "@ant-design/pro-layout";
import { Checkbox, Table } from "antd";
import { useCallback, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { generate as uniqueId } from "shortid";
import ActionColumn from "../DataTable/DatatableActions/DataTableActionColumn";
import { actionCourseLink } from "../DataTable/DatatableActions/DataTableActionHandlers";
import handleCheckboxChange from "../DataTable/DatatableActions/DataTableCheckboxHandler";
import { getItems } from "../DataTable/DatatableActions/DataTableConfig";
import { handleSaveClick } from "../DataTable/DatatableActions/DataTableCrudUtils";
import DataTableExtraActions from "../DataTable/DatatableActions/DataTableExtraActions";
import DataTableFilterWrapper from "../DataTable/DatatableActions/DataTableFilterWrapper";
import {
  updateAdditionalColumns,
  updateDataTableColumns,
} from "../DataTable/DatatableActions/DataTableUtils";
export default function CourseModuleDataTable({ config, extra = [] }) {
  let {
    dataTableColumns,
    DATATABLE_TITLE,
    fields,
    filterFields,
    listFields,
    customizeConfigParameters,
    inTableCheckBox,
  } = config;
  let { listEntity } = config.entities;
  const { crudContextAction } = useCrudContext();
  const { result: updatedList } = useSelector(selectUpdatedItem);
  const { result: createdList } = useSelector(selectCreatedItem);
  const { isSuccess } = useSelector(selectUpdatedItem);

  const {
    panel,
    collapsedBox,
    modal,
    readBox,
    editBox,
    advancedBox,
    linkmodal,
    quizlinkmodal,
    confirmationModal,
    cancelSessionModal,
    addToBatchModal,
  } = crudContextAction;
  const translate = useLanguage();
  const { moneyFormatter } = useMoney();
  const { dateFormat } = useDate();
  const ViewItemsList = config?.ViewItems ? config?.ViewItems : [];
  const navigate = useNavigate();
  const [selectedrecord, setSelectedRecords] = useState([]);
  const [unselectedRecords, setUnselectedRecords] = useState([]);
  const [enableSaveButton, setEnableSaveButton] = useState(false);
  const [linkStatus, setLinkStatus] = useState(true);
  const [recordStatusValue, setRecordStatusValue] = useState(true);
  const [checkboxKey, setCheckboxKey] = useState(uniqueId());
  const [columns, setColumns] = useState([]);
  const [editedOrders, setEditedOrders] = useState({});
  const [paginationShowTotal, setPaginationShowTotal] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [autoCompleteResetKey, setAutoCompleteResetKey] = useState(0);
  const [paginationParams, setPaginationParams] = useState(
    config.customizeConfigParameters
  );
  const [currentEditingModule, setCurrentEditingModule] = useState(null);
  const [orderChanged, setOrderChanged] = useState(false);
  const isInitialRender = useRef(true);
  const showTotal = (total, range) =>
    `${range[0]}-${range[1]} of ${total} items`;
  const filterRef = useRef();
  const dispatch = useDispatch();
  const { result: listResult, isLoading: listIsLoading } =
    useSelector(selectListItems);
  const { pagination, items: dataSource } = listResult;

  const [courseModuleData, setCourseModuleData] = useState([]);

  const checkboxChangeHandler = (e, record) => {
    if (linkStatus) {
      handleLinkedCourseModules(e, record);
    } else {
      handleUnlinkedCourseModule(e, record);
    }
  };

  const handleLinkedCourseModules = (e, record) => {
    const updatedCourseModuleData = JSON.parse(
      JSON.stringify(courseModuleData)
    );
    const currentModule = updatedCourseModuleData.find(
      (module) => module.id === record.id
    );
    if (e.target.checked) {
      const indexInUnselected = unselectedRecords.findIndex(
        (item) => item.id === record.id
      );
      if (indexInUnselected !== -1) {
        const { order } =
          unselectedRecords[indexInUnselected].course_modules[0];
        let newPosition = null;
        for (let i = 0; i < updatedCourseModuleData.length; i++) {
          if (
            updatedCourseModuleData[i].course_modules[0].order === null ||
            updatedCourseModuleData[i].course_modules[0].order > order
          ) {
            newPosition = updatedCourseModuleData[i].course_modules[0].order;
            break;
          }
        }
        if (newPosition === null) {
          const lastModuleOrder = updatedCourseModuleData.reduce(
            (maxOrder, module) => {
              return module.course_modules[0].order > maxOrder
                ? module.course_modules[0].order
                : maxOrder;
            },
            -Infinity
          );
          newPosition = lastModuleOrder + 1;
        }
        currentModule.course_modules[0].order = newPosition;
        const tempUnselectedRecords = unselectedRecords.filter(
          (item) => item.id !== record.id
        );
        const unselectedRecordsLength = tempUnselectedRecords.length;
        setUnselectedRecords(tempUnselectedRecords);
        if (unselectedRecordsLength === 0 && !orderChanged) {
          updatedCourseModuleData.forEach((module) => {
            module.course_modules[0].order =
              module.course_modules[0].originalOrder;
          });
        } else {
          updatedCourseModuleData.forEach((module) => {
            if (
              module.id !== record.id &&
              module.course_modules[0].order !== null &&
              module.course_modules[0].order >= newPosition
            ) {
              module.course_modules[0].order += 1;
            }
          });
        }
      }
    } else {
      const { order } = currentModule.course_modules[0];
      currentModule.course_modules[0].order = null;

      updatedCourseModuleData.forEach((module) => {
        if (
          module.id !== record.id &&
          module.course_modules[0].order !== null &&
          module.course_modules[0].order > order
        ) {
          module.course_modules[0].order -= 1;
        }
      });
      setUnselectedRecords([...unselectedRecords, record]);
    }

    setCourseModuleData(updatedCourseModuleData);
  };

  const handleUnlinkedCourseModule = (e, record) => {
    if (e.target.checked) {
      setSelectedRecords((prevSelectedRecords) => [
        ...prevSelectedRecords,
        record,
      ]);
    } else {
      setSelectedRecords((prevSelectedRecords) =>
        prevSelectedRecords.filter((item) => item.id !== record.id)
      );
    }
  };

  /** handle deactivate not possible to add in split file */
  function handleDeactivate() {
    const RecordsData = { selectedrecord, recordStatusValue };
    dispatch(crud.currentAction({ actionType: "delete", data: RecordsData }));
    modal.open();
  }
  const handleSave = () => {
    handleSaveClick(
      recordStatusValue,
      linkStatus,
      orderChanged,
      config,
      unselectedRecords,
      selectedrecord,
      setSelectedRecords,
      setUnselectedRecords,
      dispatch,
      crud,
      linkmodal,
      quizlinkmodal,
      courseModuleData
    );
  };

  let dispatchColumns = [];
  if (listFields) {
    dispatchColumns = [
      ...dataForTable({ listFields, translate, moneyFormatter, dateFormat }),
    ];
  } else {
    dispatchColumns = [...dataTableColumns];
  }

  const tablecheck = {
    title: "",
    key: "select",
    fixed: "left",
    render: (_, record) => (
      <Checkbox
        key={checkboxKey}
        defaultChecked={
          config?.ENTITY_NAME === "Viewmodule" && linkStatus ? true : false
        }
        onChange={(e) => checkboxChangeHandler(e, record)}
        disabled={currentEditingModule ? true : false}
      />
    ),
  };

  const items = getItems(
    config,
    courseModuleData,
    translate,
    extra,
    recordStatusValue,
    ViewItemsList
  );

  dataTableColumns = [
    ...[tablecheck],
    ...dispatchColumns.map((column) => {
      return column;
    }),
    ActionColumn({
      config,
      dispatch,
      navigate,
      items,
      recordStatusValue,
      modal,
      advancedBox,
      panel,
      collapsedBox,
      readBox,
      editBox,
      tablecheck,
      dispatchColumns,
      confirmationModal,
      addToBatchModal,
    }),
  ];

  useEffect(() => {
    setPaginationShowTotal(() => showTotal);
  }, [listResult.showTotal]);
  const getOrderValue = (record) => {
    return record?.course_modules?.[0]?.order || null;
  };

  useEffect(() => {
    if (updatedList) {
      handleRefresh();
    }
  }, [updatedList]);
  useEffect(() => {
    if (createdList) {
      handleRefresh();
    }
  }, [createdList]);
  useEffect(() => {
    setSelectedRecords([]);
  }, [recordStatusValue]);

  useEffect(() => {
    const additionalColumns = updateAdditionalColumns(
      courseModuleData,
      linkStatus,
      editedOrders,
      config,
      getOrderValue,
      handleOrderChange
    );

    const updatedDataTableColumns = updateDataTableColumns(
      dataTableColumns,
      additionalColumns
    );

    setColumns(updatedDataTableColumns);
  }, [courseModuleData, linkStatus, editedOrders]);
  useEffect(() => {
    if (config?.ENTITY_NAME === "Viewmodule") {
      // handleRefresh();
      setLinkStatus(true);
      dispatch(crud.resetState());
    }
  }, [isSuccess]);

  const handelDataTableLoad = useCallback(
    (pagination) => {
      const options = {
        pageNo: pagination.current || 1,
        pageSize: pagination.pageSize || 10,
        paginated: true,
      };

      if (recordStatusValue === true) {
        let dataSet = JSON.parse(JSON.stringify(paginationParams));
        dataSet.params = dataSet.params.replace(
          "recordStatus=false",
          "recordStatus=true"
        );

        dispatch(
          crud.list({
            listEntity,
            customizeConfigParameters: dataSet,
            options,
          })
        );
      } else {
        dispatch(
          crud.list({
            listEntity,
            customizeConfigParameters: paginationParams,
            options,
          })
        );
      }
    },
    [paginationParams, recordStatusValue]
  );
  const handleRefresh = useCallback(() => {
    if (filterRef.current && filterRef.current.reset) {
      filterRef.current.reset();
    }
    setRecordStatusValue(true);
    setSelectedRecords([]);
    setUnselectedRecords([]);
    // Call the reset function for AutoCompleteAsync
    setAutoCompleteResetKey((prevKey) => prevKey + 1);

    let match = customizeConfigParameters.params.match(/recordStatus=([^&]*)/);
    let recordStatus = match ? match[1] : null;
    if (recordStatus === "false") {
      customizeConfigParameters.params =
        customizeConfigParameters.params.replace(
          /recordStatus=false/,
          "recordStatus=true"
        );
    }

    dispatch(
      crud.list({
        listEntity,
        customizeConfigParameters,
      })
    );
    setRefreshKey((prevKey) => prevKey + 1);
  });
  const dataTableHandleRefresh = useCallback(() => {
    handleRefresh();
  });
  useEffect(() => {
    if (!isInitialRender.current && recordStatusValue === true) {
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
  }, [recordStatusValue]);
  useEffect(() => {
    if (isInitialRender.current) {
      isInitialRender.current = false;
    }
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    dispatcher();
    return () => {
      controller.abort();
    };
  }, []);
  const handleSearch = useCallback(
    (term) => {
      const filteredTerms = Object.fromEntries(
        Object.entries(term).filter(
          ([key, value]) =>
            value !== "" && value !== null && value !== undefined
        )
      );
      const queryString = Object.entries(filteredTerms)
        .map(([key, value]) => `${key}=${value}`)
        .join("&");
      let customParams = {};
      if (queryString) {
        customParams = {
          ...customizeConfigParameters,
          params: `${customizeConfigParameters.params}&${queryString}`,
        };

        dispatch(
          crud.list({ listEntity, customizeConfigParameters: customParams })
        );
        setPaginationParams(customParams);
      } else {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }
    },
    [customizeConfigParameters, dispatch, setPaginationParams]
  );
  const handleRecordStatusChange = useCallback((value) => {
    setCheckboxKey(uniqueId());
    setRecordStatusValue(value);
    if (config?.onLinkStatusChange) {
      config.onRecordStatusChange(value);
    }
    [];
  });
  const dispatcher = () => {
    dispatch(crud.list({ listEntity, customizeConfigParameters }));
  };
  const handleLinkedStatusChange = (value) => {
    setLinkStatus(value);
    if (config?.onLinkStatusChange) {
      config.onRecordStatusChange(value);
    }
  };

  const handleOrderChange = (recordId, newOrderValue, e) => {
    if (currentEditingModule && recordId !== currentEditingModule.id) {
      return;
    }
    newOrderValue = +newOrderValue;

    // Deep clone the course module data
    const updatedCourseModuleData = JSON.parse(
      JSON.stringify(courseModuleData)
    );

    const currentModule = updatedCourseModuleData.find(
      (record) => record.id === recordId
    );
    if (currentModule) {
      const currentOrderValue = currentEditingModule
        ? currentEditingModule.course_modules[0].order
        : currentModule.course_modules[0].order;
      currentModule.course_modules[0].order = newOrderValue;
      currentModule.course_modules[0].originalOrder = newOrderValue;
      if (newOrderValue) {
        updatedCourseModuleData.forEach((module) => {
          const moduleOrder = module.course_modules[0].order;
          if (module.id !== currentModule.id && moduleOrder !== null) {
            if (
              newOrderValue < currentOrderValue &&
              moduleOrder >= newOrderValue &&
              moduleOrder < currentOrderValue
            ) {
              module.course_modules[0].order++;
              module.course_modules[0].originalOrder++;
            } else if (
              newOrderValue > currentOrderValue &&
              moduleOrder <= newOrderValue &&
              moduleOrder > currentOrderValue
            ) {
              module.course_modules[0].order--;
              module.course_modules[0].originalOrder--;
            }
          }
        });
        setCurrentEditingModule(null);
        setEnableSaveButton(true);
        if (unselectedRecords.length > 0) {
          setOrderChanged(true);
        }
      } else {
        setEnableSaveButton(false);
        setCurrentEditingModule({
          ...currentModule,
          course_modules: [
            {
              ...currentModule.course_modules[0],
              order: currentOrderValue,
            },
          ],
        });
      }
    }

    // Update the course module data
    setCourseModuleData(updatedCourseModuleData);
  };
  useEffect(() => {
    const updatedDataSource = dataSource.map((module) => ({
      ...module,
      course_modules: [
        {
          ...module.course_modules[0],
          originalOrder: module?.course_modules[0]?.order,
        },
      ],
    }));

    setCourseModuleData(updatedDataSource);
  }, [dataSource]);

  return (
    <>
      <PageHeader
        onBack={() => window.history.back()}
        title={DATATABLE_TITLE}
        ghost={false}
        className="datatable-pageheader"
        extra={
          <DataTableExtraActions
            autoCompleteResetKey={autoCompleteResetKey}
            setAutoCompleteResetKey={setAutoCompleteResetKey}
            selectedrecord={selectedrecord}
            translate={translate}
            config={config}
            recordStatusValue={recordStatusValue}
            handleDeactivate={handleDeactivate}
            dataTableHandleRefresh={dataTableHandleRefresh}
            handleSave={handleSave}
            unselectedRecords={unselectedRecords}
            enableSaveButton={enableSaveButton}
          />
        }
      >
        <DataTableFilterWrapper
          handleSearch={handleSearch}
          filterFields={filterFields}
          config={config}
          customizeConfigParameters={customizeConfigParameters}
          handleRecordStatusChange={handleRecordStatusChange}
          filterRef={filterRef}
          onLinkedStatusChange={handleLinkedStatusChange}
        />
      </PageHeader>

      <Table
        key={refreshKey}
        columns={columns}
        rowKey={(item) => item.id}
        dataSource={courseModuleData}
        pagination={{
          ...pagination,
          showTotal: paginationShowTotal,
        }}
        loading={listIsLoading}
        onChange={handelDataTableLoad}
        scroll={{ x: true }}
        className="custom-pagination no-space"
      />
    </>
  );
}
