import React from "react";
import { Select } from "antd";
import { useSelector, useDispatch } from "react-redux";
import { selectListItems } from "@/redux/adavancedCrud/selectors";
import useLanguage from "@/locale/useLanguage";
import { useEffect, useState } from "react";
import { advancedCrud } from "@/redux/adavancedCrud/actions";

const SelectDropdown = ({
  config,
  translate,
  handleCourseLink,
  selectedrecord,
}) => {
  const dispatch = useDispatch();
  const { result: listResult, isLoading: listIsLoading } =
    useSelector(selectListItems);

  const { pagination, items } = listResult;
  const courseData = [...items];

  useEffect(() => {
    const options = {
      pageNo: pagination.current || 1,
      pageSize: pagination.pageSize || 10,
      paginated: true,
    };
    const listEntity = config?.entities.linkedlistEntity;
    const customizeConfigParameters = config?.customizeLinkedConfigParameters;
    dispatch(
      advancedCrud.list({ listEntity, customizeConfigParameters, options })
    );
  }, []);

  return (
    <Select
      disabled={selectedrecord.length > 0 ? false : true}
      size="default"
      className="select-course-set-width"
      key="selectCourse"
      placeholder={
        config?.ENTITY_NAME == "Module"
          ? translate("Add To Course")
          : translate("Add To Module")
      }
      showSearch
      optionFilterProp="children"
      filterOption={(input, option) =>
        (option?.label ?? "").toLowerCase().includes(input.toLowerCase())
      }
      filterSort={(optionA, optionB) =>
        (optionA?.label ?? "")
          .toLowerCase()
          .startsWith((optionB?.label ?? "").toLowerCase())
      }
    >
      {courseData?.map((course) => (
        <Select.Option
          key={course.title}
          value={course.title}
          label={translate(course.title)}
        >
          <span onClick={() => handleCourseLink(course)}>{course.title}</span>
        </Select.Option>
      ))}
    </Select>
  );
};

export default SelectDropdown;
