import React from 'react';
import { Card,Row,Col } from 'antd';

const ReusableCard = ({ contents,image }) => (
    <Row>
   <Col span={12}>
  <Card
  className="small-card"
  size="small"
    
  >
      <img alt='Thumbnail' src={image}></img>
 
      <p>
        {contents}</p>
  </Card>
 </Col>
  </Row>
);

export default ReusableCard;
