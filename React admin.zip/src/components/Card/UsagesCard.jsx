import { useState } from "react";
import { Card, Row, Col, Button } from "antd";
import { InfoCircleOutlined } from "@ant-design/icons";
import UsagesModal from "../UsagesModal";
const UsagesCard = ({ contents, image, description, card }) => {
  const [isUsagesModalVisible, setIsUsagesModalVisible] = useState(false);

  const handleButtonClick = () => {
    setIsUsagesModalVisible(true);
  };

  const handleCloseUsagesModal = () => {
    setIsUsagesModalVisible(false);
  };

  return (
    <>
      <Row>
        <Col span={12} className="border border-light rounded bg-white">
          {card ? (
            <Card className="small-card mb-2" size="small">
              <div className=" d-flex  mb-3">
                <div className="p-2">
                  {image ? (
                    <img
                      alt="Thumbnail"
                      src={image}
                      className="thumnail-usages"
                    ></img>
                  ) : (
                    ""
                  )}
                </div>
                <div className="p-2 bd-highlight">
                  <p className="ml-4">{contents}</p>
                </div>
                <div className=" ml-5 p-2 ">
                  <Button
                    className="usages-button"
                    type=""
                    size="small"
                    icon={<InfoCircleOutlined />}
                    onClick={handleButtonClick}
                  ></Button>

                  <UsagesModal
                    onOpen={isUsagesModalVisible}
                    onClose={handleCloseUsagesModal}
                    description={description}
                  />
                </div>
              </div>
            </Card>
          ) : (
            <div className=" d-flex  mb-3  ">
              <div className="p-2">
                {image ? (
                  <img
                    alt="Thumbnail"
                    src={image}
                    className="thumnail-usages"
                  ></img>
                ) : (
                  ""
                )}
              </div>
              <div className="p-2 bd-highlight">
                <p className="ml-4">{contents}</p>
              </div>
              <div className=" ml-5 p-2 ">
                <Button
                  className="usages-button"
                  type=""
                  size="small"
                  icon={<InfoCircleOutlined />}
                  onClick={handleButtonClick}
                ></Button>

                <UsagesModal
                  onOpen={isUsagesModalVisible}
                  onClose={handleCloseUsagesModal}
                  description={description}
                />
              </div>
            </div>
          )}
        </Col>
      </Row>
    </>
  );
};
export default UsagesCard;
