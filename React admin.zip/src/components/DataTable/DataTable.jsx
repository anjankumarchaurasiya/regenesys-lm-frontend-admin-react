import { useCallback, useEffect, useState, useRef } from "react";
import { Table, Checkbox } from "antd";
import { PageHeader } from "@ant-design/pro-layout";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { selectListItems, selectUpdatedItem } from "@/redux/crud/selectors";
import { selectCreatedItem } from "@/redux/crud/selectors";
import useLanguage from "@/locale/useLanguage";
import { dataForTable } from "@/utils/dataStructure";
import { useMoney, useDate } from "@/settings";
import { useCrudContext } from "@/context/crud";
import DataTableFilterWrapper from "./DatatableActions/DataTableFilterWrapper";
import DataTableExtraActions from "./DatatableActions/DataTableExtraActions";
import handleCheckboxChange from "./DatatableActions/DataTableCheckboxHandler";
import { handleSaveClick } from "./DatatableActions/DataTableCrudUtils";
import {
  updateAdditionalColumns,
  updateDataTableColumns,
} from "./DatatableActions/DataTableUtils";
import DropdownColumn from "./DatatableActions/DataTableDropdownColumn";
import ActionColumn from "./DatatableActions/DataTableActionColumn";
import { actionCourseLink } from "./DatatableActions/DataTableActionHandlers";
import { generate as uniqueId } from "shortid";
import {
  getItems,
  getModuleItems,
  getSessionItems,
} from "./DatatableActions/DataTableConfig";
export default function DataTable({
  config,
  extra = [],
  handleOrderChange,
  onDataReceived,
  updatedData,
}) {
  let {
    dataTableColumns,
    DATATABLE_TITLE,
    fields,
    filterFields,
    listFields,
    customizeConfigParameters,
    inTableCheckBox,
  } = config;
  let { listEntity } = config.entities;
  const { crudContextAction } = useCrudContext();
  const { result: updatedList } = useSelector(selectUpdatedItem);
  const { result: createdList } = useSelector(selectCreatedItem);
  const { isSuccess } = useSelector(selectUpdatedItem);

  const {
    panel,
    collapsedBox,
    modal,
    readBox,
    editBox,
    advancedBox,
    linkmodal,
    quizlinkmodal,
    confirmationModal,
    cancelSessionModal,
    addToBatchModal,
  } = crudContextAction;
  const translate = useLanguage();
  const { moneyFormatter } = useMoney();
  const { dateFormat } = useDate();
  const ViewItemsList = config?.ViewItems ? config?.ViewItems : [];
  const navigate = useNavigate();
  const [selectedrecord, setSelectedRecords] = useState([]);
  const [selectedlinkedRecords, setSelectedLinkedRecords] = useState([]);
  const [unselectedRecords, setUnselectedRecords] = useState([]);
  const [linkStatus, setLinkStatus] = useState(true);
  const [recordStatusValue, setRecordStatusValue] = useState(true);
  const [checkboxKey, setCheckboxKey] = useState(uniqueId());
  const [orderChanged, setOrderChanged] = useState(false);

  const [linkedStatusValue, setLinkedStatusValue] = useState(true);
  const [columns, setColumns] = useState([]);
  const [editedOrders, setEditedOrders] = useState({});
  const [paginationShowTotal, setPaginationShowTotal] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [autoCompleteResetKey, setAutoCompleteResetKey] = useState(0);
  const [paginationParams, setPaginationParams] = useState(
    config.customizeConfigParameters
  );
  const [orderValues, setOrderValues] = useState({});
  const isInitialRender = useRef(true);
  const showTotal = (total, range) =>
    `${range[0]}-${range[1]} of ${total} items`;
  const filterRef = useRef();
  const dispatch = useDispatch();
  const { result: listResult, isLoading: listIsLoading } =
    useSelector(selectListItems);
  const { pagination, items: dataSource } = listResult;
  const moduleItems = getModuleItems();
  const sessionItems = getSessionItems();

  const checkboxChangeHandler = (e, record) => {
    handleCheckboxChange(e, record, setSelectedRecords, setUnselectedRecords);
    const updatedItemIndex = dataSource.findIndex(
      (item) => item.id === record.id
    );
    // for viewmodule only
    if (config?.ENTITY_NAME === "Viewmodule") {
      if (e.target.checked) {
        let currentOrder = 1;
        for (let i = 0; i < updatedItemIndex; i++) {
          if (dataSource[i].course_modules[0]?.order !== null) {
            dataSource[i].course_modules[0].order = currentOrder;
            currentOrder++;
          }
        }
        dataSource[updatedItemIndex].course_modules[0].order = currentOrder;
        for (let i = updatedItemIndex + 1; i < dataSource.length; i++) {
          if (dataSource[i].course_modules[0]?.order !== null) {
            currentOrder++;
            dataSource[i].course_modules[0].order = currentOrder;
          }
        }
      } else {
        if (
          updatedItemIndex !== -1 &&
          dataSource[updatedItemIndex].course_modules[0]?.order !== null
        ) {
          dataSource[updatedItemIndex].course_modules[0].order = null;
          let currentOrder = 1;
          for (let i = 0; i < updatedItemIndex; i++) {
            if (dataSource[i].course_modules[0]?.order !== null) {
              dataSource[i].course_modules[0].order = currentOrder;
              currentOrder++;
            }
          }
          for (let i = updatedItemIndex + 1; i < dataSource.length; i++) {
            if (dataSource[i].course_modules[0]?.order !== null) {
              dataSource[i].course_modules[0].order = currentOrder;
              currentOrder++;
            }
          }
        }
      }
    }
    // for viewtopic only
    if (config?.ENTITY_NAME === "Viewtopic") {
      if (e.target.checked) {
        let currentOrder = 1;
        for (let i = 0; i < updatedItemIndex; i++) {
          if (dataSource[i].module_topics[0]?.order !== null) {
            dataSource[i].module_topics[0].order = currentOrder;
            currentOrder++;
          }
        }
        dataSource[updatedItemIndex].module_topics[0].order = currentOrder;
        for (let i = updatedItemIndex + 1; i < dataSource.length; i++) {
          if (dataSource[i].module_topics[0]?.order !== null) {
            currentOrder++;
            dataSource[i].module_topics[0].order = currentOrder;
          }
        }
      } else {
        if (
          updatedItemIndex !== -1 &&
          dataSource[updatedItemIndex].module_topics[0]?.order !== null
        ) {
          dataSource[updatedItemIndex].module_topics[0].order = null;
          let currentOrder = 1;
          for (let i = 0; i < updatedItemIndex; i++) {
            if (dataSource[i].module_topics[0]?.order !== null) {
              dataSource[i].module_topics[0].order = currentOrder;
              currentOrder++;
            }
          }
          for (let i = updatedItemIndex + 1; i < dataSource.length; i++) {
            if (dataSource[i].module_topics[0]?.order !== null) {
              dataSource[i].module_topics[0].order = currentOrder;
              currentOrder++;
            }
          }
        }
      }
    }
  };

  /** handle deactivate not possible to add in split file */
  function handleDeactivate() {
    const RecordsData = { selectedrecord, recordStatusValue };
    dispatch(crud.currentAction({ actionType: "delete", data: RecordsData }));
    modal.open();
  }

  const handleSave = () => {
    handleSaveClick(
      recordStatusValue,
      linkStatus,
      orderChanged,
      config,
      unselectedRecords,
      selectedrecord,
      setSelectedRecords,
      setUnselectedRecords,
      dispatch,
      crud,
      linkmodal,
      quizlinkmodal,
      dataSource
    );
  };
  function handleCourseLink(record) {
    actionCourseLink(
      record,
      setSelectedRecords,
      setLinkStatus,
      linkmodal,
      quizlinkmodal,
      config,
      dispatch
    );
  }

  let dispatchColumns = [];
  if (listFields) {
    dispatchColumns = [
      ...dataForTable({ listFields, translate, moneyFormatter, dateFormat }),
    ];
  } else {
    dispatchColumns = [...dataTableColumns];
  }

  const tablecheck = {
    title: "",
    key: "select",
    fixed: "left",
    render: (_, record) => (
      <Checkbox
        key={checkboxKey}
        defaultChecked={
          (config?.ENTITY_NAME === "Viewmodule" && linkStatus) ||
          (config?.ENTITY_NAME === "Viewtopic" && linkStatus) ||
          (config?.ENTITY_NAME === "View Session" && !!recordStatusValue) ||
          (config?.ENTITY_NAME === "Studentbatch" && linkStatus) ||
          (config?.ENTITY_NAME === "ViewFeedbackSession" && linkStatus)
            ? true
            : false
        }
        onChange={(e) => checkboxChangeHandler(e, record)}
      />
    ),
  };

  const items = getItems(
    config,
    dataSource,
    translate,
    extra,
    recordStatusValue,
    ViewItemsList
  );
  const truncateData = (description) => {
    const maxLength = 40;
    if (description?.length > maxLength) {
      return `${description?.substring(0, maxLength)} ...`;
    }
    return description;
  };

  dataTableColumns = [
    ...(typeof inTableCheckBox === "undefined" &&
    (config?.ENTITY_NAME === "Batchsession" ||
      config?.ENTITY_NAME === "Session")
      ? [
          DropdownColumn({
            config,
            dispatch,
            navigate,
            items,
            recordStatusValue,
            modal,
            advancedBox,
            panel,
            collapsedBox,
            readBox,
            editBox,
            tablecheck,
            dispatchColumns,
            moduleItems,
            sessionItems,
          }),
        ]
      : []),
    ...(typeof inTableCheckBox === "undefined" &&
    config?.ENTITY_NAME !== "Exam" &&
    config?.ENTITY_NAME !== "Capstone" &&
    config?.PANEL_TITLE !== "Feedback" &&
    config?.ENTITY_NAME !== "Viewfeedbackbatch" &&
    config?.ENTITY_NAME !== "Admin" &&
    config?.ENTITY_NAME !== "Srmuserlist" &&
    config?.ENTITY_NAME !== "Student"
      ? [tablecheck]
      : []),
    ...dispatchColumns.map((column) => {
      if (column.title === "Thumbnail") {
        return {
          ...column,
          render: (_, record) =>
            record.thumbnail ? (
              <img
                src={record.thumbnail}
                alt="Thumbnail"
                style={{ maxWidth: "50px" }}
              />
            ) : null,
        };
      }
      if (column.title === "Description") {
        return {
          ...column,
          render: (_, record) => truncateData(record?.description),
        };
      }
      if (column.title === "Title") {
        return {
          ...column,
          render: (_, record) => truncateData(record?.title),
        };
      }

      return column;
    }),
    ActionColumn({
      config,
      dispatch,
      navigate,
      items,
      recordStatusValue,
      modal,
      advancedBox,
      panel,
      collapsedBox,
      readBox,
      editBox,
      tablecheck,
      dispatchColumns,
      confirmationModal,
      addToBatchModal,
    }),
  ];

  useEffect(() => {
    setPaginationShowTotal(() => showTotal);
  }, [listResult.showTotal]);
  const getOrderValue = (record) => {
    const updatedRecord = updatedData.find(
      (dataObj) => dataObj.id === record.id
    );
    if (config?.ENTITY_NAME === "Viewmodule") {
      if (!!updatedRecord) {
        return updatedRecord.course_modules[0].order;
      } else if (
        record?.course_modules != undefined &&
        record?.course_modules[0]?.order !== undefined
      ) {
        return record?.course_modules[0]?.order;
      }
    } else if (config?.ENTITY_NAME === "Viewtopic") {
      if (!!updatedRecord) {
        return updatedRecord.module_topics[0].order;
      } else if (
        record?.module_topics != undefined &&
        record?.module_topics[0]?.order !== undefined
      ) {
        return record?.module_topics[0]?.order;
      }
    }
    return null;
  };
  useEffect(() => {
    setSelectedRecords([]);
  }, [recordStatusValue, linkedStatusValue, dataSource]);

  useEffect(() => {
    setUnselectedRecords([]);
  }, [linkedStatusValue]);

  useEffect(() => {
    if (updatedList) {
      handleRefresh();
    }
  }, [updatedList]);
  useEffect(() => {
    if (createdList) {
      handleRefresh();
    }
  }, [createdList]);
  useEffect(() => {
    const initialEditedOrders = [{}];
    setSelectedRecords([]);
  }, [recordStatusValue]);

  useEffect(() => {
    const initialEditedOrders = {};
    updatedData?.forEach((record) => {
      const orderId = record.id;
      const initialValue = getOrderValue(record);
      if (initialValue !== undefined) {
        initialEditedOrders[orderId] = initialValue;
      }
    });
    setEditedOrders(initialEditedOrders);
  }, []);
  useEffect(() => {
    if (dataSource) onDataReceived(dataSource);
  }, [dataSource]);
  useEffect(() => {
    const initialSelectedRecords = dataSource?.filter((record) => linkStatus);
    setSelectedLinkedRecords(initialSelectedRecords || []);
  }, [linkStatus, dataSource]);

  useEffect(() => {
    const additionalColumns = updateAdditionalColumns(
      dataSource,
      linkStatus,
      editedOrders,
      config,
      getOrderValue,
      handleOrderChange
    );

    const updatedDataTableColumns = updateDataTableColumns(
      dataTableColumns,
      additionalColumns
    );

    setColumns(updatedDataTableColumns);
  }, [dataSource, linkStatus, editedOrders]);
  useEffect(() => {
    if (
      (isSuccess == true && config?.ENTITY_NAME === "Viewtopic") ||
      config?.ENTITY_NAME === "Viewmodule"
    ) {
      handleRefresh();
      setLinkStatus(true);
      dispatch(crud.resetState());
    }
  }, [isSuccess]);

  const handelDataTableLoad = useCallback(
    (pagination) => {
      const options = {
        pageNo: pagination.current || 1,
        pageSize: pagination.pageSize || 10,
        paginated: true,
      };

      if (recordStatusValue === true) {
        let dataSet = JSON.parse(JSON.stringify(paginationParams));
        dataSet.params = dataSet.params.replace(
          "recordStatus=false",
          "recordStatus=true"
        );

        dispatch(
          crud.list({
            listEntity,
            customizeConfigParameters: dataSet,
            options,
          })
        );
      } else {
        dispatch(
          crud.list({
            listEntity,
            customizeConfigParameters: paginationParams,
            options,
          })
        );
      }
    },
    [paginationParams, recordStatusValue]
  );
  const handleRefresh = useCallback(() => {
    if (filterRef.current && filterRef.current.reset) {
      filterRef.current.reset();
    }
    setRecordStatusValue(true);
    setSelectedRecords([]);
    setUnselectedRecords([]);
    // Call the reset function for AutoCompleteAsync
    setAutoCompleteResetKey((prevKey) => prevKey + 1);

    let match = customizeConfigParameters.params.match(/recordStatus=([^&]*)/);
    let recordStatus = match ? match[1] : null;
    if (recordStatus === "false") {
      customizeConfigParameters.params =
        customizeConfigParameters.params.replace(
          /recordStatus=false/,
          "recordStatus=true"
        );
    }

    dispatch(
      crud.list({
        listEntity,
        customizeConfigParameters,
      })
    );
    setRefreshKey((prevKey) => prevKey + 1);
  });
  const dataTableHandleRefresh = useCallback(() => {
    handleRefresh();
  });
  useEffect(() => {
    if (!isInitialRender.current && recordStatusValue === true) {
      dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
  }, [recordStatusValue]);
  useEffect(() => {
    if (isInitialRender.current) {
      isInitialRender.current = false;
    }
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    dispatcher();
    return () => {
      controller.abort();
    };
  }, []);
  const handleSearch = useCallback(
    (term) => {
      const filteredTerms = Object.fromEntries(
        Object.entries(term).filter(
          ([key, value]) =>
            value !== "" && value !== null && value !== undefined
        )
      );
      const queryString = Object.entries(filteredTerms)
        .map(([key, value]) => `${key}=${value}`)
        .join("&");

      let customParams = {};
      if (queryString) {
        if (queryString.includes("categoryIds")) {
          const querySplit = queryString.split("&");
          let remainingQuery = "";
          let categoryQuery = "";
          querySplit.forEach((elem) => {
            const seprateValue = elem.split("=");
            if (seprateValue[0] == "categoryIds") {
              categoryQuery = seprateValue[1];
            } else {
              remainingQuery += `${seprateValue[0]}=${seprateValue[1]}&`;
            }
          });
          let categoryIDs;

          if (categoryQuery.includes(",")) {
            categoryIDs = categoryQuery.split(",");
            customParams = {
              responseInnerObj: customizeConfigParameters.responseInnerObj,
              params: `${remainingQuery}categoryIds=${categoryIDs[0]}`,
              extraparams: `&categoryIds=${categoryIDs[1]}`,
            };
          } else {
            categoryIDs = [categoryQuery];
            customParams = {
              responseInnerObj: customizeConfigParameters.responseInnerObj,
              params: `${remainingQuery}categoryIds=${categoryIDs}`,
              extraparams: `&categoryIds=${categoryIDs}`,
            };
          }
        } else {
          customParams = {
            ...customizeConfigParameters,
            //  params: queryString,
            params: `${customizeConfigParameters.params}&${queryString}`,
          };
        }

        dispatch(
          crud.list({ listEntity, customizeConfigParameters: customParams })
        );
        setPaginationParams(customParams);
      } else {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }
    },
    [customizeConfigParameters, dispatch, setPaginationParams]
  );
  const handleRecordStatusChange = useCallback((value) => {
    setCheckboxKey(uniqueId());
    setRecordStatusValue(value);
    if (config?.onLinkStatusChange) {
      config.onRecordStatusChange(value);
    }
    [];
  });
  const dispatcher = () => {
    dispatch(crud.list({ listEntity, customizeConfigParameters }));
  };
  const handleLinkedStatusChange = (value) => {
    setLinkStatus(value);
    if (config?.onLinkStatusChange) {
      config.onRecordStatusChange(value);
    }
  };

  return (
    <>
      <PageHeader
        {...(config.ENTITY_NAME === "Viewmodule" ||
        config.ENTITY_NAME === "Viewtopic" ||
        config.ENTITY_NAME === "Studentbatch" ||
        config.ENTITY_NAME === "Batchsession" ||
        config.ENTITY_NAME === "Viewfeedback" ||
        config.ENTITY_NAME === "Viewspamrequest" ||
        config.ENTITY_NAME === "View Session" ||
        config.ENTITY_NAME === "Viewfeedbackbatch" ||
        config.ENTITY_NAME === "ViewFeedbackSession"
          ? { onBack: () => window.history.back() }
          : {})}
        title={DATATABLE_TITLE}
        ghost={false}
        className="datatable-pageheader"
        extra={
          <DataTableExtraActions
            autoCompleteResetKey={autoCompleteResetKey}
            setAutoCompleteResetKey={setAutoCompleteResetKey}
            selectedrecord={selectedrecord}
            handleCourseLink={handleCourseLink}
            translate={translate}
            config={config}
            recordStatusValue={recordStatusValue}
            handleDeactivate={handleDeactivate}
            dataTableHandleRefresh={dataTableHandleRefresh}
            handleSave={handleSave}
            unselectedRecords={unselectedRecords}
          />
        }
      >
        <DataTableFilterWrapper
          handleSearch={handleSearch}
          filterFields={filterFields}
          config={config}
          customizeConfigParameters={customizeConfigParameters}
          handleRecordStatusChange={handleRecordStatusChange}
          filterRef={filterRef}
          onLinkedStatusChange={handleLinkedStatusChange}
        />
      </PageHeader>

      <Table
        key={refreshKey}
        columns={columns}
        rowKey={(item) => item.id}
        dataSource={dataSource}
        pagination={{
          ...pagination,
          showTotal: paginationShowTotal,
        }}
        loading={listIsLoading}
        onChange={handelDataTableLoad}
        scroll={{ x: true }}
        className="custom-pagination no-space"
      />
    </>
  );
}
