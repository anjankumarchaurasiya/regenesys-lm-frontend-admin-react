import { useState, useEffect, useRef } from "react";
import { request } from "@/request";
import useOnFetch from "@/hooks/useOnFetch";
import useDebounce from "@/hooks/useDebounce";
import { Select, Empty } from "antd";
import useLanguage from "@/locale/useLanguage";
import { useSelector, useDispatch } from "react-redux";
import { selectListItems } from "@/redux/adavancedCrud/selectors";

export default function AutoCompleteAsync({
  onReset, // Add this prop for resetting AutoCompleteAsync state
  selectedrecord,
  handleCourseLink,
  translate,
  config,
  entity,
  displayLabels,
  searchFields,
  outputValue = "id",
  value, /// this is for update
  onChange, /// this is for update
  recordStatusValue,
}) {
  const [selectOptions, setOptions] = useState([]);
  const [currentValue, setCurrentValue] = useState(undefined);
  const isUpdating = useRef(true);
  const isSearching = useRef(false);
  const [searching, setSearching] = useState(false);
  const [valToSearch, setValToSearch] = useState("");
  const [debouncedValue, setDebouncedValue] = useState("");
  const { result: listResult, isLoading: listIsLoading } =
    useSelector(selectListItems);
  const { pagination, items } = listResult;

  const [, cancel] = useDebounce(
    () => {
      setDebouncedValue(valToSearch);
    },
    100,
    [valToSearch]
  );

  const asyncSearch = async (options) => {
    const data = await request.search({ entity, options });
    return data;
  };

  let { onFetch, result, isSuccess, isLoading } = useOnFetch();
  const labels = (optionField) => {
    const lables = displayLabels.map((x) => optionField[x]).join(" ");
    return lables;
  };

  useEffect(() => {
    if (debouncedValue != "") {
      const linkedentity = config?.entities.linkedentity;
      let options;
      if (config?.ENTITY_NAME === "Student") {
        options = {
          batchNumber: debouncedValue,
        };
      } else {
        options = {
          title: debouncedValue,
        };
      }

      const callback = asyncSearch(options);
      onFetch(callback, linkedentity);
    }

    return () => {
      cancel();
    };
  }, [debouncedValue]);

  const onSearch = (searchText) => {
    const processedSearchText = searchText.replace(/#/g, "%23");
    setValToSearch(processedSearchText);

    // Always set isSearching to true when typing
    isSearching.current = true;
    setSearching(true);
    setOptions([]);
    setCurrentValue(undefined);
  };

  useEffect(() => {
    if (isSearching.current) {
      if (isSuccess) {
        if (result?.length > 0) {
          setOptions(result);
        } else {
          setSearching(false);
          setCurrentValue(undefined);
          setOptions([]);
        }
      } else {
        setSearching(false);
        setCurrentValue(undefined);
        setOptions([]);
      }
    }
  }, [isSuccess, result]);

  useEffect(() => {
    // this for update Form , it's for setField
    if (value && isUpdating.current) {
      if (!isSearching.current) {
        setOptions([value]);
      }
      setCurrentValue(value[outputValue] || value); // set nested value or value
      onChange(value[outputValue] || value);
      isUpdating.current = false;
    } else {
      // Reset state when onReset is called
      setCurrentValue(undefined);
      setOptions([]);
      setSearching(false);
    }
  }, [value, onReset]);

  useEffect(() => {
    return () => {
      localStorage.removeItem("batchId");
    };
  }, []);

  return (
    <>
      {recordStatusValue == true && (
        <Select
          disabled={
            selectedrecord.length > 0 && recordStatusValue == true
              ? false
              : true
          }
          className="select-course-set-width me-2"
          loading={isLoading}
          showSearch
          allowClear
          virtual
          placeholder={
            config?.ENTITY_NAME === "Module"
              ? translate("Add To Course")
              : config?.ENTITY_NAME === "Quiz"
                ? translate("Add To Session")
                : config?.ENTITY_NAME === "Student"
                  ? translate("Add To Batch")
                  : translate("Add To Module")
          }
          defaultActiveFirstOption={false}
          filterOption={false}
          notFoundContent={searching ? "... Searching" : <Empty />}
          value={currentValue}
          onSearch={onSearch}
          optionFilterProp="children"
          onChange={(newValue) => {
            if (onChange) {
              if (newValue) onChange(newValue[outputValue] || newValue);
            }
          }}
          onSelect={(selectedValue, option) => {
            const selectedOption = option.key;
            const selectedOptionData = selectOptions.find(
              (optionField) => optionField[outputValue] === selectedOption
            );
            localStorage.setItem("batchId", selectedValue);
            handleCourseLink(selectedOptionData);
          }}
          onClear={() => {
            setOptions([]);
            setCurrentValue(undefined);
            setSearching(false);
          }}
        >
          {selectOptions.map((optionField) => (
            <Select.Option
              key={optionField[outputValue] || optionField}
              value={optionField[outputValue] || optionField}
            >
              {labels(optionField)}
            </Select.Option>
          ))}
        </Select>
      )}
    </>
  );
}
