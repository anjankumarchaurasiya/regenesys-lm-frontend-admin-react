import React, { useState, useEffect } from "react";
import { Button, Modal, Menu, Dropdown, Form, Card, List } from "antd";
import UploadPdfPage from "@/forms/UploadPdfForm";
import UploadVideoPage from "@/forms/UploadVideoForm";
import UploadExcelPage from "@/forms/UploadExcelForm";
import {
  DownOutlined,
  DeleteOutlined,
  EditOutlined,
  VideoCameraOutlined,
  FilePdfOutlined,
  FileExcelOutlined,
} from "@ant-design/icons";
import useLanguage from "@/locale/useLanguage";
import { crud } from "@/redux/crud/actions";
import { useDispatch, useSelector } from "react-redux";

const { Meta } = Card;

export default function TrainingResourcesButton({
  onButtonClick,
  entityName,
  uploadedData,
  editData,
  mediaEditFlag = true,
}) {
  const translate = useLanguage();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [record, setRecord] = useState(null);
  const [itemIndex, setItemIndex] = useState(null);
  const [form] = Form.useForm();
  const dispatch = useDispatch();

  const showModal = (option) => {
    setSelectedOption(option);
    setRecord(null);
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
    setSelectedOption(null);
    // form.resetFields();
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setSelectedOption(null);
    // form.resetFields();
  };

  useEffect(() => {
    if (!!editData) {
      let uploadedfiles;
      if (editData?.question_contents != undefined) {
        uploadedfiles = editData?.question_contents?.map((data) => ({
          name: data.content.title,
          type: data.content.type,
        }));
      } else {
        uploadedfiles = uploadedData?.map((data) => ({
          name: data.title,
          type: data.type,
        }));
      }

      setUploadedFiles(uploadedfiles);
    }
  }, [uploadedData]);
  const handleUploadComplete = (fileName, updatedDescription, record) => {
    if (!record) {
      setUploadedFiles([
        ...uploadedFiles,
        { name: fileName, type: selectedOption },
      ]);
    } else {
      const updatedFiles = [...uploadedFiles];
      updatedFiles.splice(itemIndex, 1, {
        name: fileName,
        type: selectedOption,
      });
      setUploadedFiles(updatedFiles);
    }
    handleOk();
  };

  const handleDelete = (index) => {
    const indexValue = { index };

    dispatch(crud.currentAction({ actionType: "read", data: indexValue }));

    const updatedFiles = [...uploadedFiles];
    updatedFiles.splice(index, 1);
    setUploadedFiles(updatedFiles);
  };
  const handleEdit = (item) => {
    setSelectedOption(uploadedData?.[item]?.type);
    setRecord(uploadedData[item]);
    setItemIndex(item);
    setIsModalVisible(true);
  };
  const menu = (
    <Menu>
      <Menu.Item key="pdf" onClick={() => showModal("PDF")}>
        PDF
      </Menu.Item>
      <Menu.Item key="video" onClick={() => showModal("VIDEO")}>
        Video
      </Menu.Item>
      <Menu.Item key="excel" onClick={() => showModal("EXCEL")}>
        Excel
      </Menu.Item>
    </Menu>
  );

  return (
    <>
      <Dropdown overlay={menu} trigger={["click"]}>
        <Button size="default">
          {translate("add_media")} <DownOutlined />
        </Button>
      </Dropdown>
      <Modal
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
      >
        {selectedOption === "PDF" && (
          <UploadPdfPage
            onComplete={handleUploadComplete}
            form={form}
            entityName={entityName}
            record={record}
          />
        )}
        {selectedOption === "VIDEO" && (
          <UploadVideoPage
            onComplete={handleUploadComplete}
            form={form}
            entityName={entityName}
          />
        )}
        {selectedOption === "EXCEL" && (
          <UploadExcelPage
            onComplete={handleUploadComplete}
            form={form}
            entityName={entityName}
          />
        )}
      </Modal>
      {uploadedFiles?.length > 0 && (
        <Card className="mb-2 mt-2" title="Uploaded Files">
          <List
            size="small"
            bordered
            dataSource={uploadedFiles}
            renderItem={(item, index) => (
              <List.Item className="resources-list-item">
                {item?.type == "VIDEO" && (
                  <VideoCameraOutlined style={{ marginRight: "4%" }} />
                )}
                {item?.type == "PDF" && (
                  <FilePdfOutlined style={{ marginRight: "4%" }} />
                )}
                {item?.type == "EXCEL" && (
                  <FileExcelOutlined style={{ marginRight: "4%" }} />
                )}
                {`${index + 1}- ${
                  item?.name.length > 31
                    ? `${item?.name.slice(0, 31)}...`
                    : item?.name
                }`}
                <Button
                  type="text"
                  icon={<DeleteOutlined />}
                  onClick={() => handleDelete(index)}
                  style={{ color: "red" }}
                />
                {mediaEditFlag && entityName === "QUIZ" && (
                  <Button
                    onClick={() => handleEdit(index)}
                    type="text"
                    icon={<EditOutlined />}
                  ></Button>
                )}
              </List.Item>
            )}
          />
        </Card>
      )}
    </>
  );
}
