import React from "react";
import { Collapse, Card, Row, Col } from "antd";
import UsagesCard from "../Card/UsagesCard";
const { Panel } = Collapse;

const Accordion = ({ data }) => {
  return (
    <Collapse accordion className="custom-collapse">
      {data.map((module, moduleIndex) => (
        <Panel
          header={
            <UsagesCard
              key={module.id}
              contents={module.title}
              description={module}
              image={""}
            />
          }
          key={moduleIndex.toString()}
        >
          {module.courses?.map((course, courseIndex) => (
            <Row key={courseIndex.toString()} gutter={[16, 16]}>
              <Col span={24}>
                <UsagesCard
                  key={course.id}
                  contents={course.title}
                  description={course}
                  image={course.thumbnail}
                  card={true}
                />
              </Col>
            </Row>
          ))}
        </Panel>
      ))}
    </Collapse>
  );
};

export default Accordion;
