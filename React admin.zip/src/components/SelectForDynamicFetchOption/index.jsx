import React, { useState, useEffect } from "react";
import { request } from "@/request";
import useFetch from "@/hooks/useFetch";
import { Form, Select, Tag, Tooltip } from "antd";
import { useNavigate } from "react-router-dom";
import { generate as uniqueId } from "shortid";
import color from "@/utils/color";
import SelectAsyncFetch from "../SelectAsyncFetch";
import useLanguage from "@/locale/useLanguage";
import { InfoCircleOutlined } from "@ant-design/icons";

const SelectForDynamicFetchOption = ({
  entity,
  displayLabels = ["name"],
  outputValue = "name",
  redirectLabel = "",
  withRedirect = false,
  urlToRedirect = "/",
  value,
  onChange,
  asyncOptions,
  responseInner = "",
  placeholder = "",
  mode,
  currentItem,
  dropdownFor,
}) => {
  const [selectOptions, setOptions] = useState([]);
  const [newSelectOptions, setNewSelectOptions] = useState([]);
  const [currentValue, setCurrentValue] = useState(undefined);
  const [newVlaue, setNewValue] = useState(undefined);
  const [showAdditionalDropdown, setShowAdditionalDropdown] = useState(false);
  const navigate = useNavigate();

  const asyncList = () => {
    const resp = request.list({ listEntity: entity, options: asyncOptions });
    return resp;
  };

  const translate = useLanguage();
  useEffect(() => {
    if (currentValue) {
      const newEntity = `feedback/filter/list/?categoryId=${currentValue}`;
      const fetchData = async () => {
        try {
          const resp = await request.list({
            listEntity: newEntity,
            options: {},
          });
          setNewSelectOptions(resp?.data?.feedbacks);
        } catch (error) {
          console.error("Failed to fetch new select options", error);
        }
      };
      fetchData();
    }
  }, [currentValue]);

  const {
    result,
    isLoading: fetchIsLoading,
    isSuccess,
  } = useFetch(asyncList, responseInner || "");

  useEffect(() => {
    isSuccess && setOptions(result);
  }, [isSuccess]);
  useEffect(() => {
    if (value) {
      const val = value[outputValue] ?? value;
      setCurrentValue(val);
      onChange(val);
    }
  }, [value]);

  useEffect(() => {
    if (currentItem != undefined) {
      setShowAdditionalDropdown(true);
      setCurrentValue(currentItem?.feedback?.categoryId);
    }
  }, []);

  const handleSelectChange = (newValue) => {
    // const val = newValue[outputValue] ?? newValue;
    setCurrentValue(newValue);
    // onChange(val);
    setShowAdditionalDropdown(true);
  };
  const handleForNewValueChange = (selectedNewValue) => {
    const val = selectedNewValue[outputValue] ?? selectedNewValue;
    setNewValue(selectedNewValue);
    onChange(val);
  };

  const optionsList = () => {
    const list = selectOptions?.map((optionField) => {
      const value = optionField[outputValue] ?? optionField;
      const label = displayLabels.map((x) => optionField[x]).join(" ");
      const currentColor =
        optionField[outputValue]?.color ?? optionField?.color;
      const labelColor = color.find((x) => x.color === currentColor);
      return { value, label, color: labelColor?.color };
    });

    const filteredListForBatch = list?.filter(
      (item) => item.value.name === "FINAL"
    );
    const filteredListForSession = list?.filter(
      (item) => item.value.name === "PRIMARY" || item.value.name === "REGULAR"
    );
    if (dropdownFor == "batch") {
      return filteredListForBatch;
    } else if (dropdownFor == "Session") {
      return filteredListForSession;
    } else {
      return list;
    }
  };

  const newOptionList = () => {
    const list =
      newSelectOptions &&
      newSelectOptions?.map((optionField) => {
        const value = optionField[outputValue] ?? optionField;
        const label = displayLabels.map((x) => optionField[x]).join(" ");
        const currentColor =
          optionField[outputValue]?.color ?? optionField?.color;
        const labelColor = color.find((x) => x.color === currentColor);
        return { value, label, color: labelColor?.color };
      });

    return list;
  };
  console.log("new option list ", newOptionList());
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center" }}>
        <Select
          defaultValue={currentItem?.feedback?.categoryId}
          loading={fetchIsLoading}
          disabled={fetchIsLoading}
          onChange={handleSelectChange}
          placeholder={translate(placeholder)}
          style={{ flex: 1, marginRight: 8 }} // Adjust the style as needed
        >
          {optionsList()?.map((option) => (
            <Select.Option key={`${uniqueId()}`} value={option.value.id}>
              <Tag bordered={false}>{option.label}</Tag>
            </Select.Option>
          ))}
        </Select>
        {dropdownFor == "Session" && (
          <Tooltip
            title="Primary Feedback: First Session 
    Regular Feedback : Second Session Onwards"
          >
            <InfoCircleOutlined className="infoicon" />
          </Tooltip>
        )}
      </div>
      {showAdditionalDropdown && (
        <Form.Item label="Feedback " style={{ marginTop: 16 }} required>
          <Select
            defaultValue={currentItem?.feedback?.id}
            loading={fetchIsLoading}
            disabled={fetchIsLoading}
            value={newVlaue}
            placeholder={translate("feedback")}
            onChange={handleForNewValueChange}
            mode={mode ? mode : ""}
          >
            {newOptionList()?.map((option) => (
              <Select.Option key={`${uniqueId()}`} value={option.value.id}>
                <Tag bordered={false}>{option.value.title}</Tag>
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
      )}
    </div>
  );
};

export default SelectForDynamicFetchOption;
