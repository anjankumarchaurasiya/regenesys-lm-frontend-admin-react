import { Modal } from "antd";
import UsagesPage from "@/pages/Usages";

export default function UsagesModal({ onOpen, onClose, description }) {
  const handleOk = () => {};

  const handleCancel = () => {
    onClose();
  };

  return (
    <Modal open={onOpen} onOk={handleOk} onCancel={handleCancel} footer={null}>
      <>
        <UsagesPage description={description} />
      </>
    </Modal>
  );
}
