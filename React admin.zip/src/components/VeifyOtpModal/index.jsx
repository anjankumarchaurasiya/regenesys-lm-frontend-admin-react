import { useEffect, useState } from "react";
import { Modal } from "antd";
import VerifyOtpPage from "@/pages/VerifyOtp";

export default function VerifyOtpModal({ openModal, close, loginFormData }) {
  const handleOk = () => {
    // Handle OK action
  };

  const handleCancel = () => {
    // Handle Cancel action
    close(); // Close the modal using the provided close function
  };
  return (
    <Modal
      open={!openModal}
      onOk={handleOk}
      onCancel={handleCancel}
      footer={null}
    >
      <>
        <VerifyOtpPage loginFormData={loginFormData} />
      </>
    </Modal>
  );
}
