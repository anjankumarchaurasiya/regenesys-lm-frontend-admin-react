import { useEffect, useState } from "react";
import { Modal } from "antd";

import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { useAppContext } from "@/context/appContext";
import { selectDeletedItem } from "@/redux/crud/selectors";
import { valueByString } from "@/utils/helpers";

import useLanguage from "@/locale/useLanguage";

export default function DeleteModal({ config }) {
  const translate = useLanguage();
  let {
    customizeConfigParameters,
    deletedentity,
    activateEntity,
    entity,
    deleteModalLabels,
    deleteMessage = translate("are_you_sure_you_want_to_deactivate"),
    deletemodalTitle = translate("deactivate_confirmation"),
    activateMessage = translate("are_you_sure_you_want_to_activate"),
    activateModalTitle = translate("activate_confirmation"),
    batchRemoveTitle = translate("batch_remove_confirmation"),
    batchremoveMessage = translate(
      "are_you_sure_you_want_to_remove_this_batch_from_exam"
    ),
    capstoneRemoveTitle = translate("Capstone Remove Confirmation"),
    capstoneRemoveMessage = translate(
      "Are you Sure you want to remove this Batch from Capstone"
    ),
  } = config;

  let { listEntity } = config.entities;

  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectDeletedItem);
  const { state, crudContextAction } = useCrudContext();
  const { appContextAction } = useAppContext();
  const { panel, readBox } = crudContextAction;
  const { navMenu } = appContextAction;
  const { isModalOpen } = state;
  const { modal } = crudContextAction;
  const [displayItem, setDisplayItem] = useState("");
  const deleteEntityName = deletedentity?.entityname;
  const bulkentity = deletedentity?.bulkentityname;
  const updateEntity = activateEntity?.entityname;

  useEffect(() => {
    if (isSuccess) {
      modal.close();

      dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
    if (current) {
      let labels = deleteModalLabels
        .map((x) => valueByString(current, x))
        .join(" ");

      setDisplayItem(labels);
    }
  }, [isSuccess, current]);

  const handleOk = () => {
    const id = current?.record?.id;

    const bulKIds =
      current?.selectedrecord?.length > 0
        ? current.selectedrecord
            .filter((item) => item && item.id !== undefined)
            .map((item) => item.id)
        : [];
    let dataObject = {};

    if (config?.ENTITY_NAME == "Exam") {
      const quizId = current?.id;
      const batchId = current?.batch_quizzes[0]?.batchId;

      const customizeUrl = "batch/" + batchId + "/" + "quiz/" + quizId;

      dispatch(crud.delete({ customizeUrl }));
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    if (config?.ENTITY_NAME == "Capstone") {
      const quizId = current?.id;
      const batchId = current?.batch_quizzes[0]?.batchId;

      const customizeUrl = "batch/" + batchId + "/" + "quiz/" + quizId;

      dispatch(crud.delete({ customizeUrl }));
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    if (
      (current?.recordStatus == true ||
        current?.recordStatusValue == true ||
        current[0]?.recordStatus == true) &&
      config?.ENTITY_NAME !== "Exam" &&
      config?.ENTITY_NAME !== "Capstone"
    ) {
      dataObject[bulkentity] = bulKIds;
      const BulkData = { bulKIds, dataObject };
      dispatch(crud.delete({ entity, deleteEntityName, id, BulkData }));
      customizeConfigParameters.params =
        customizeConfigParameters.params.replace(
          "recordStatus=false",
          "recordStatus=true"
        );

      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 500);
    }
    if (
      current?.recordStatusValue == false &&
      config?.ENTITY_NAME !== "Exam" &&
      config?.ENTITY_NAME !== "Capstone"
    ) {
      if (bulKIds.length >= 1) {
        if (config?.ENTITY_NAME == "Batchsession") {
          const customizeUrl = deleteEntityName + "/bulk/activate";
          dataObject[bulkentity] = bulKIds;
          dispatch(
            crud.update({ customizeUrl, dataObject, withUpload: false })
          );
        } else {
          const customizeUrl = deleteEntityName + "/bulk/activate";
          dataObject[bulkentity] = bulKIds;
          dispatch(
            crud.update({ customizeUrl, dataObject, withUpload: false })
          );
        }
      } else {
        dataObject["recordStatus"] = true;
        const status = current?.recordStatusValue;
        const id = current?.record?.id;

        dispatch(
          crud.update({
            updateEntity,
            dataObject,
            status,
            id,
            withUpload: false,
          })
        );
      }

      customizeConfigParameters.params =
        customizeConfigParameters.params.replace(
          "recordStatus=true",
          "recordStatus=false"
        );
      setTimeout(() => {
        dispatch(crud.list({ listEntity, customizeConfigParameters }));
      }, 100);
    }

    readBox.close();
    modal.close();
    panel.close();
    // navMenu.collapse();
  };
  const handleCancel = () => {
    if (!isLoading) modal.close();
  };
  return (
    <Modal
      title={
        config?.ENTITY_NAME == "Exam"
          ? batchRemoveTitle
          : config?.ENTITY_NAME == "Capstone"
            ? capstoneRemoveTitle
            : current?.recordStatusValue == true ||
                current?.recordStatusValue == undefined
              ? deletemodalTitle
              : activateModalTitle
      }
      open={isModalOpen}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={isLoading}
    >
      <p>
        {config?.ENTITY_NAME == "Exam"
          ? batchremoveMessage
          : config?.ENTITY_NAME == "Capstone"
            ? capstoneRemoveMessage
            : current?.recordStatusValue == true ||
                current?.recordStatusValue == undefined
              ? deleteMessage
              : activateMessage}
        {displayItem}
      </p>
    </Modal>
  );
}
