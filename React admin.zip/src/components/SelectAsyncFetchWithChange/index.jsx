import { useState, useEffect } from "react";
import { request } from "@/request";
import useFetch from "@/hooks/useFetch";
import { Select, Tag } from "antd";
import { useNavigate } from "react-router-dom";
import { generate as uniqueId } from "shortid";
import color from "@/utils/color";

const SelectAsyncFetchWithChange = ({
  entity,
  displayLabels = ["name"],
  outputValue = "name",
  redirectLabel = "",
  withRedirect = false,
  urlToRedirect = "/",
  selectValue,
  fieldName,
  onChange,
  asyncOptions = {},
  responseInner = "",
  placeholder = "",
  mode,
  form,
}) => {
  const [selectOptions, setOptions] = useState([]);
  const navigate = useNavigate();

  const asyncList = () => {
    const resp = request.list({ listEntity: entity, options: asyncOptions });
    return resp;
  };
  const {
    result,
    isLoading: fetchIsLoading,
    isSuccess,
  } = useFetch(asyncList, responseInner || "");

  useEffect(() => {
    isSuccess && setOptions(result);
  }, [isSuccess]);

  const labels = (optionField) => {
    return displayLabels.map((x) => optionField[x]).join(" ");
  };

  const handleSelectChange = (newValue) => {
    onChange(fieldName, newValue);
    if (form && form.setFieldsValue) {
      form.setFieldsValue({ [fieldName]: newValue });
    }
  };

  const optionsList = () => {
    const list = [];

    // if (selectOptions?.length === 0 && withRedirect) {
    //   const value = 'redirectURL';
    //   const label = `+ ${redirectLabel}`;
    //   list.push({ value, label });
    // }
    selectOptions?.map((optionField) => {
      const value = optionField[outputValue] ?? optionField;
      const label = labels(optionField);
      const currentColor =
        optionField[outputValue]?.color ?? optionField?.color;
      const labelColor = color.find((x) => x.color === currentColor);
      list.push({ value, label, color: labelColor?.color });
    });
    return list;
  };

  return (
    <Select
      loading={fetchIsLoading}
      disabled={fetchIsLoading}
      value={selectValue}
      onChange={handleSelectChange}
      placeholder={placeholder}
      mode={mode || ""}
      className="batch-filter-select"
    >
      {optionsList()?.map((option) => {
        return (
          <Select.Option key={`${uniqueId()}`} value={option.value.id}>
            <Tag bordered={false}>{option.label}</Tag>
          </Select.Option>
        );
      })}
    </Select>
  );
};

export default SelectAsyncFetchWithChange;
