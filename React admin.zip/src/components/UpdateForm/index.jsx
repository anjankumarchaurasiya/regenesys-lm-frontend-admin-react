import { useEffect } from "react";
import dayjs from "dayjs";
import { useDispatch, useSelector } from "react-redux";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { selectUpdatedItem } from "@/redux/crud/selectors";
import useLanguage from "@/locale/useLanguage";
import { Button, Form, message } from "antd";
import Loading from "@/components/Loading";
import ct from "countries-and-timezones";
import moment from "moment-timezone"; // Import timezone library
import isMobilePhone from "@/utils/isMobilePhone";

export default function UpdateForm({
  config,
  formElements,
  withUpload = false,
}) {
  let { customizeConfigParameters } = config;
  let { listEntity, updateEntity, createEntity } = config.entities;
  const translate = useLanguage();
  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);
  const { state, crudContextAction } = useCrudContext();
  const { panel, collapsedBox, readBox } = crudContextAction;
  const [form] = Form.useForm();

  const onSubmit = (fieldsValue) => {
    const id = current.id;

    if (fieldsValue.file && withUpload) {
      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }
    const changedFields = Object.keys(fieldsValue).filter((key) => {
      /** start - this code is used only for if any changes happen in mobile or country code */
      if (key === "dialCode" || key === "mobile") {
        return (
          fieldsValue["dialCode"] !== current["dialCode"] ||
          fieldsValue["mobile"] !== current["mobile"]
        );
      }
      /** end - this code is used only for if any changes happen in mobile or country code */
      return fieldsValue[key] !== current[key];
    });
    const jsonData = changedFields.reduce((acc, key) => {
      acc[key] =
        typeof fieldsValue[key] === "string"
          ? fieldsValue[key].trim()
          : fieldsValue[key];
      return acc;
    }, {});
    const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
      acc[key] =
        typeof fieldsValue[key] === "string"
          ? fieldsValue[key].trim()
          : fieldsValue[key];
      return acc;
    }, {});
    if (trimmedValues.timeZone != "") {
      // const countryCode = moment.tz(trimmedValues.timeZone).zoneAbbr();
      if (trimmedValues.mobile) {
        const timezoneInfo = ct.getTimezone(trimmedValues.timeZone);
        const countryCode = timezoneInfo?.countries[0];
        trimmedValues.countryCode = "IN";
        trimmedValues.timezone = trimmedValues.timeZone;
        const mobileNumberWithDialCode =
          trimmedValues?.dialCode + trimmedValues?.mobile;
        const isPhoneNumberCorrect = isMobilePhone(mobileNumberWithDialCode);
        if (!isPhoneNumberCorrect) {
          message.error("Phone Number is Invalid");
        } else {
          dispatch(
            crud.update({
              listEntity,
              updateEntity,
              id,
              jsonData: trimmedValues,
              withUpload,
              customizeConfigParameters,
            })
          );
        }
      } else {
        dispatch(
          crud.update({
            listEntity,
            updateEntity,
            id,
            jsonData: trimmedValues,
            withUpload,
            customizeConfigParameters,
          })
        );
      }

      setTimeout(() => {
        if (current?.recordStatus == false) {
          customizeConfigParameters.params =
            customizeConfigParameters.params.replace(
              "recordStatus=true",
              "recordStatus=false"
            );
          dispatch(crud.list({ listEntity, customizeConfigParameters }));
        } else {
          dispatch(crud.list({ listEntity, customizeConfigParameters }));
        }
      }, 200);
    } else {
      dispatch(
        crud.update({
          listEntity,
          updateEntity,
          id,
          jsonData: updateEntity == "/course" ? trimmedValues : jsonData,
          withUpload,
          customizeConfigParameters,
        })
      );
      setTimeout(() => {
        if (current?.recordStatus == false) {
          customizeConfigParameters.params =
            customizeConfigParameters.params.replace(
              "recordStatus=true",
              "recordStatus=false"
            );
          dispatch(crud.list({ listEntity, customizeConfigParameters }));
        } else {
          dispatch(crud.list({ listEntity, customizeConfigParameters }));
        }
      }, 200);
    }
  };

  useEffect(() => {
    if (current) {
      let newValues = { ...current };

      if (newValues.course_module && newValues.course_module.order) {
        newValues = {
          ...newValues,
          order: newValues.course_module.order,
        };
      }

      if (newValues.birthday) {
        newValues = {
          ...newValues,
          birthday: dayjs(newValues["birthday"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.date) {
        newValues = {
          ...newValues,
          date: dayjs(newValues["date"]).format("YYYY-MM-DDTHH:mm:ss.SSSZ"),
        };
      }
      if (newValues.expiredDate) {
        newValues = {
          ...newValues,
          expiredDate: dayjs(newValues["expiredDate"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.created) {
        newValues = {
          ...newValues,
          created: dayjs(newValues["created"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }
      if (newValues.updated) {
        newValues = {
          ...newValues,
          updated: dayjs(newValues["updated"]).format(
            "YYYY-MM-DDTHH:mm:ss.SSSZ"
          ),
        };
      }

      form.resetFields();
      form.setFieldsValue(newValues);
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      // readBox.open();
      collapsedBox.open();
      panel.close();
      form.resetFields();
      dispatch(crud.resetAction({ actionType: "update" }));
      // dispatch(crud.list({ listEntity, customizeConfigParameters }));
    }
  }, [isSuccess]);

  const { isEditBoxOpen } = state;

  const show = isEditBoxOpen
    ? { display: "block", opacity: 1 }
    : { display: "none", opacity: 0 };
  return (
    <div style={show}>
      <Loading isLoading={isLoading}>
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          {formElements}
          <Form.Item
            style={{
              display: "inline-block",
              paddingRight: "5px",
            }}
          >
            <Button
              type="primary"
              htmlType="submit"
              disabled={config.ENTITY_NAME === "Studentbatch"}
            >
              {translate("Save")}
            </Button>
          </Form.Item>
        </Form>
      </Loading>
    </div>
  );
}
