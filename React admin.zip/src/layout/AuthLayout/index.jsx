import React from "react";
import { Layout, Row, Col } from "antd";
import DefaultLayout from "../DefaultLayout";

const ContentBox = ({ sideContent, children }) => {
  return (
    <>
      <Layout>
        <Row justify="center">
          <Col
            xs={{ span: 24, order: 1 }}
            sm={{ span: 24, order: 1 }}
            md={{ span: 13, order: 2 }}
            lg={{ span: 12, order: 2 }}
            style={{ background: "#FFF", minHeight: "calc(100vh - 22px)" }}
          >
            {children}
          </Col>
        </Row>
      </Layout>
    </>
  );
};

export default function AuthLayout({ children, sideContent }) {
  return (
    <>
      <DefaultLayout>
        <ContentBox sideContent={sideContent} children={children} />
      </DefaultLayout>
    </>
  );
}
