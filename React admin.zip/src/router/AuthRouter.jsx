import { Routes, Route, Navigate } from "react-router-dom";

import Login from "@/pages/Login";
import NotFound from "@/pages/NotFound";
import Register from "@/pages/Register";
import Verify from "@/pages/Verify";
import ForgetPassword from "@/pages/ForgetPassword";
import ResetPassword from "@/pages/ResetPassword";
import LoginWithMobile from "@/pages/LoginWithMobile";
import VerifyOtpPage from "@/pages/VerifyOtp";

export default function AuthRouter() {
  return (
    <Routes>
      <Route element={<Login />} path="/" />
      <Route element={<Login />} path="/email-login" />
      <Route element={<LoginWithMobile />} path="/mobile-login" />
      <Route element={<Navigate to="/email-login" replace />} path="/logout" />
      {/* <Route element={<Register />} path="/register" /> */}
      {/* <Route element={<ForgetPassword />} path="/forgetpassword" /> */}
      {/* <Route element={<Verify />} path="/verify/:userId/:emailToken" /> */}
      {/* <Route
        element={<ResetPassword />}
        path="/resetpassword/:userId/:resetToken"
      /> */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
