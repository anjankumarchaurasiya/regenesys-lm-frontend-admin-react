import { useLayoutEffect, useEffect, useState } from "react";
import { Row, Col, Button } from "antd";
import { PlusOutlined, EditOutlined, DeleteOutlined } from "@ant-design/icons";
import CreateForm from "@/components/CreateForm";
import UpdateForm from "@/components/UpdateForm";
import TopicUpdateForm from "@/components/TopicUpdateForm";
import DeleteModal from "@/components/DeleteModal";
import LinkModal from "@/components/LinkModal";
import ReadItem from "@/components/ReadItem";
import SearchItem from "@/components/SearchItem";
import DataTable from "@/components/DataTable/DataTable";
import { useDispatch, useSelector } from "react-redux";
import { selectCurrentItem } from "@/redux/crud/selectors";
import useLanguage from "@/locale/useLanguage";
import { crud } from "@/redux/crud/actions";
import { useCrudContext } from "@/context/crud";
import { CrudLayout } from "@/layout";
import QuizLinkModal from "@/components/LinkModal/QuizLinkModal";
import CancelSessionModal from "@/components/LinkModal/CancelSessionModal";
import ViewBatchModal from "@/components/LinkModal/ViewBatchModal";
import ConfirmationModal from "@/components/LinkModal/ConfirmationModal";
import AddToBatchModal from "@/components/LinkModal/AddToBatchModal";
import MeetingModeField from "@/components/MeetingModeField";

function SidePanelTopContent({ config, formElements, withUpload }) {
  const translate = useLanguage();
  const { crudContextAction, state } = useCrudContext();
  const { deleteModalLabels } = config;
  const { modal, editBox } = crudContextAction;

  const { isReadBoxOpen, isEditBoxOpen } = state;
  const { result: currentItem } = useSelector(selectCurrentItem);
  const dispatch = useDispatch();

  const [labels, setLabels] = useState("");
  useEffect(() => {
    if (currentItem) {
      const currentlabels = deleteModalLabels
        .map((x) => currentItem[x])
        .join(" ");

      setLabels(currentlabels);
    }
  }, [currentItem]);

  const removeItem = () => {
    dispatch(crud.currentAction({ actionType: "delete", data: currentItem }));
    modal.open();
  };
  const editItem = () => {
    dispatch(crud.currentAction({ actionType: "update", data: currentItem }));
    editBox.open();
  };

  const show = isReadBoxOpen || isEditBoxOpen ? { opacity: 1 } : { opacity: 0 };
  return (
    <>
      <Row style={show} gutter={(24, 24)}>
        <Col span={10}></Col>
        <Col span={14}></Col>

        <Col span={24}>
          <div className="line"></div>
        </Col>
        <div className="space10"></div>
      </Row>
      <ReadItem config={config} />
      {config?.ENTITY_NAME == "Topic" && (
        <TopicUpdateForm
          config={config}
          formElements={formElements}
          withUpload={withUpload}
        />
      )}

      {config?.ENTITY_NAME != "Topic" && (
        <UpdateForm
          config={config}
          formElements={formElements}
          withUpload={withUpload}
        />
      )}
    </>
  );
}

function FixHeaderPanel({ config }) {
  const { crudContextAction } = useCrudContext();

  const { collapsedBox } = crudContextAction;

  const addNewItem = () => {
    collapsedBox.close();
  };

  return (
    <Row gutter={8}>
      <Col className="gutter-row" span={21}>
        <SearchItem config={config} />
      </Col>
      <Col className="gutter-row" span={3}>
        <Button
          onClick={addNewItem}
          block={true}
          icon={<PlusOutlined />}
        ></Button>
      </Col>
    </Row>
  );
}

function CrudModule({
  config,
  createForm,
  updateForm,
  customTable,
  withUpload = false,
}) {
  const dispatch = useDispatch();
  const [editedOrders, setEditedOrders] = useState([]);
  const [courseModuleOrderData, setCourseModuleOrderData] = useState();
  const [updatedData, setUpdatedData] = useState([]);
  const [trimmedValues, setTrimmedValues] = useState({});

  const updateTrimmedValues = (values) => {
    setTrimmedValues(values);
  };

  useEffect(() => {
    const trimmedValuesCopy = { ...trimmedValues }; // Create a copy to avoid mutating the original object
    if (
      Object.keys(trimmedValuesCopy).length > 0 &&
      config?.PANEL_TITLE == "Create Session"
    ) {
      if (
        trimmedValuesCopy.startTime != "" &&
        trimmedValuesCopy.startTime != null
      ) {
        trimmedValuesCopy.startTime = trimmedValuesCopy.startTime.toISOString();
      }
      if (
        trimmedValuesCopy.endTime != "" &&
        trimmedValuesCopy.endTime != null
      ) {
        trimmedValuesCopy.endTime = trimmedValuesCopy?.endTime.toISOString();
      }
      if (trimmedValuesCopy.date != "" && trimmedValuesCopy.date != null) {
        trimmedValuesCopy.date = trimmedValuesCopy?.date.toISOString();
      }

      dispatch(
        crud.currentAction({ actionType: "delete", data: trimmedValuesCopy })
      );
    }
  }, [trimmedValues]);

  const handleDataFromDataTable = (data) => {
    setCourseModuleOrderData(data);
  };
  useLayoutEffect(() => {
    dispatch(crud.resetState());
  }, []);

  useEffect(() => {
    // for Viewmodule only
    if (
      config.ENTITY_NAME === "Viewmodule" &&
      courseModuleOrderData &&
      editedOrders
    ) {
      const updatedData = courseModuleOrderData.map((dataObj) => {
        const editedOrder = editedOrders.find(
          (editedObj) => editedObj.recordId === dataObj.id
        );
        if (editedOrder) {
          return {
            ...dataObj,
            course_modules: {
              ...dataObj.course_modules,
              order: Number(editedOrder.orderValue),
            },
          };
        }
        return dataObj;
      });
      editedOrders.forEach((editedOrder) => {
        if (editedOrder.orderValue === 0) {
          return;
        }
        const index = updatedData.findIndex(
          (dataObj) =>
            dataObj.id === editedOrder.recordId && editedOrder.orderValue !== 0
        );
        if (index !== -1) {
          const temp = courseModuleOrderData[index]?.course_modules[0].order;
          if (!editedOrder.orderValue) {
            updatedData[index].course_modules[0].previousOrder =
              updatedData[index].course_modules[0].order;
          }
          if (
            updatedData[index].course_modules[0].previousOrder &&
            editedOrder.orderValue
          ) {
            const previousOrder =
              updatedData[index].course_modules[0].previousOrder;
            const swapIndex = updatedData.findIndex(
              (dataObj) =>
                Number(dataObj.course_modules[0].order) ==
                editedOrder.orderValue
            );
            if (
              swapIndex !== -1 &&
              updatedData[swapIndex].course_modules[0].order !== 0 &&
              updatedData[swapIndex].course_modules[0].order !== null &&
              editedOrder.orderValue !== null
            ) {
              if (swapIndex !== -1) {
                updatedData[swapIndex].course_modules[0].order = previousOrder;
                delete updatedData[index].course_modules[0].previousOrder;
              }
            }
          }
          if (
            updatedData[index].course_modules[0].order !== null &&
            temp !== null
          ) {
            updatedData[index].course_modules[0].order = editedOrder.orderValue;
          }
        }
      });
      setUpdatedData(updatedData);
    }
    // for viewtopic only
    if (
      config.ENTITY_NAME === "Viewtopic" &&
      courseModuleOrderData &&
      editedOrders
    ) {
      const updatedData = courseModuleOrderData.map((dataObj) => {
        const editedOrder = editedOrders.find(
          (editedObj) => editedObj.recordId === dataObj.id
        );
        if (editedOrder) {
          return {
            ...dataObj,
            module_topics: {
              ...dataObj.module_topics,
              order: Number(editedOrder.orderValue),
            },
          };
        }
        return dataObj;
      });
      editedOrders.forEach((editedOrder) => {
        console.log("calling if consition");
        if (editedOrder.orderValue === 0) {
          return;
        }
        const index = updatedData.findIndex(
          (dataObj) =>
            dataObj.id === editedOrder.recordId && editedOrder.orderValue !== 0
        );
        if (index !== -1) {
          const temp = courseModuleOrderData[index]?.module_topics[0].order;
          if (!editedOrder.orderValue) {
            updatedData[index].module_topics[0].previousOrder =
              updatedData[index].module_topics[0].order;
          }
          if (
            updatedData[index].module_topics[0].previousOrder &&
            editedOrder.orderValue
          ) {
            const previousOrder =
              updatedData[index].module_topics[0].previousOrder;
            const swapIndex = updatedData.findIndex(
              (dataObj) =>
                Number(dataObj.module_topics[0].order) == editedOrder.orderValue
            );
            if (
              swapIndex !== -1 &&
              updatedData[swapIndex].module_topics[0].order !== 0 &&
              updatedData[swapIndex].module_topics[0].order !== null &&
              editedOrder.orderValue !== null
            ) {
              if (swapIndex !== -1) {
                updatedData[swapIndex].module_topics[0].order = previousOrder;
                delete updatedData[index].module_topics[0].previousOrder;
              }
            }
          }

          if (
            updatedData[index].module_topics[0].order !== null &&
            temp !== null
          ) {
            updatedData[index].module_topics[0].order = editedOrder.orderValue;
          }
        }
      });
      setUpdatedData(updatedData);
    }
  }, [config.ENTITY_NAME, courseModuleOrderData, editedOrders]);
  const handleOrderChange = (recordId, newOrderValue, e) => {
    const re = /^[0-9\b]+$/;
    if (e.target.value === "" || re.test(newOrderValue)) {
      setEditedOrders((prevOrders) => {
        const updatedOrders = prevOrders.map((order) => {
          if (order.recordId === recordId && order.orderValue !== "") {
            return { ...order, orderValue: newOrderValue };
          }
          return order;
        });
        const filteredOrders = updatedOrders.filter(
          (order) => order.orderValue !== ""
        );
        if (filteredOrders.orderValue === "" && order.orderValue !== "") {
          filteredOrders.shift();
        }
        if (!filteredOrders.some((order) => order.recordId === recordId)) {
          filteredOrders.push({
            recordId: recordId,
            orderValue: newOrderValue,
          });
        }
        return filteredOrders;
      });
    }
  };

  return (
    <CrudLayout
      config={config}
      fixHeaderPanel={<FixHeaderPanel config={config} />}
      sidePanelBottomContent={
        <CreateForm
          config={config}
          formElements={createForm}
          withUpload={withUpload}
          onUpdateFormValues={updateTrimmedValues}
        />
      }
      sidePanelTopContent={
        <SidePanelTopContent
          config={config}
          formElements={updateForm}
          withUpload={withUpload}
        />
      }
    >
      {customTable ? (
        <> {customTable}</>
      ) : (
        <DataTable
          config={config}
          handleOrderChange={handleOrderChange}
          onDataReceived={handleDataFromDataTable}
          updatedData={updatedData}
        />
      )}

      <DeleteModal config={config} />
      <LinkModal config={config} editedOrders={editedOrders} />
      <QuizLinkModal config={config} />
      <CancelSessionModal config={config} />
      <ViewBatchModal config={config} />
      <ConfirmationModal config={config} />
      <AddToBatchModal config={config} />
      <div className="session-modal-display ">
        {config?.PANEL_TITLE == "Create Session" && (
          <MeetingModeField
            trimmedValues={trimmedValues}
            updateTrimmedValues={updateTrimmedValues}
          />
        )}
      </div>
    </CrudLayout>
  );
}

export default CrudModule;
